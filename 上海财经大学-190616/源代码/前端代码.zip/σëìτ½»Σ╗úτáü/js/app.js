$('#runner').runner({

milliseconds: false,
format: function millisecondsToString(milliseconds) {
            var oneHour = 3600000;
            var oneMinute = 60000;
            var oneSecond = 1000;
            var seconds = 0;
            var minutes = 0;
            var hours = 0;
            var result;

            if (milliseconds >= oneHour) {
                hours = Math.floor(milliseconds / oneHour);
            }

            milliseconds = hours > 0 ? (milliseconds - hours * oneHour) : milliseconds;

            if (milliseconds >= oneMinute) {
                minutes = Math.floor(milliseconds / oneMinute);
            }

            milliseconds = minutes > 0 ? (milliseconds - minutes * oneMinute) : milliseconds;

            if (milliseconds >= oneSecond) {
                seconds = Math.floor(milliseconds / oneSecond);
            }

            milliseconds = seconds > 0 ? (milliseconds - seconds * oneSecond) : milliseconds;

            if (hours > 0) {
                result = (hours > 9 ? hours : "0" + hours) + ":";
            } else {
                result = "00:";
            }

            if (minutes > 0) {
                result += (minutes > 9 ? minutes : "0" + minutes) + ":";
            } else {
                result += "00:";
            }

            if (seconds > 0) {
                result += (seconds > 9 ? seconds : "0" + seconds);
            } else {
                result += "00";
            }
           
            return result;
        }  
       
   });

//buttons

$('#startBtn').click(function() {
    $('#runner').runner('start');
    $(this).addClass('activeBtn');
    $('#stopBtn').removeClass('activeBtn');

});

$('#stopBtn').click(function() {
    $('#runner').runner('stop');
    $(this).addClass('activeBtn');
    $('#startBtn').removeClass('activeBtn');
});

$('#resetBtn').click(function() {
    $('#runner').runner('reset');
    $('#stopBtn').removeClass('activeBtn');
    $('#startBtn').removeClass('activeBtn');
});