<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:80:"D:\thinkphp_5.0.24_with_extend\public/../application/index\view\index\demo2.html";i:1551009621;}*/ ?>
<!DOCTYPE html> 
<html lang="en">
<head> 
<meta charset="UTF-8"> 
<meta name="viewport" content="width=device-width, initial-scale=1.0"> 
<meta http-equiv="X-UA-Compatible" content="ie=edge"> 
<title>Document</title> 
</head> 
<body> 名字：<input type="text" id="name" name="name"> <button type="button" onclick="load()">点击</button> 
<div id="myDiv"></div> 
    <script>

        function load() {
            var name = document.getElementById("name").value;

            // 1.创建XMLHttpRequest对象
            var xhr = new XMLHttpRequest();

            // 2.请求行
            xhr.open("POST", "./info.php");

            // 3.请求头
            xhr.setRequestHeader('Content-Type',' application/x-www-form-urlencoded');

            // 4.设置数据
            xhr.send("name="+name);

            // 5.监听服务器响应
            xhr.onreadystatechange = function(){
                if (xhr.readyState==4 && xhr.status==200){
                    document.getElementById("myDiv").innerHTML=xhr.responseText;
                }
            }
        }

    </script> </body> </html>