<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:80:"D:\thinkphp_5.0.24_with_extend\public/../application/index\view\index\index.html";i:1550758736;}*/ ?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width">
  <title></title>
<!--   <script src="https://code.jquery.com/jquery-3.1.0.js"></script>
  <script type="text/javascript" src="/static/js/index.js?v=1.0"></script> -->

</head>
<body>
    <input type="text" name="" id="input">
    <button id="btn">发送</button>
</body>
</html>