<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:81:"D:\thinkphp_5.0.24_with_extend\public/../application/index\view\index\gepang.html";i:1550756593;}*/ ?>
<!DOCTYPE html>
<!--STATUS OK-->
<html>
<head>
<meta http-equiv="X-UA-Compatible" content="IE=Edge" />
<meta http-equiv="content-type" content="text/html;charset=gbk" />
<meta property="wb:webmaster" content="3aababe5ed22e23c" />
<meta name="referrer" content="always" />
<title><?php echo $title; ?></title>
<link rel="shortcut icon" href="//www.baidu.com/favicon.ico?t=20171027" type="image/x-icon" />
<link rel="icon" sizes="any" mask href="//www.baidu.com/img/baidu.svg" />

<script>
    window.alogObjectConfig = {
        product: '102',
        page: '102_3', 
        monkey_page: 'zhidao-ques',
        speed_page: '3',
        speed: {
            sample: '0.02'
        },
        monkey: {
            sample: '0.01'
        },
        exception: { 
            sample: '0.01'
        },
        feature: {
            sample: '0.01'
        },
        cus: {
            sample: '0.01',
            custom_metrics: ['c_sbox', 'c_menu', 'c_ask', 'c_best']
        },
        csp: {
            sample: '0.02',
            'default-src': [
                {match: '*bae.baidu.com', target: 'Accept,Warn'},
                {match: '*.baidu.com,*.bdstatic.com,*.bdimg.com,localhost,*.hao123.com,*.hao123img.com', target: 'Accept'},
                {match: /^(127|172|192|10)(\.\d+){3}$/, target: 'Accept'},
                {match: '*', target: 'Accept,Warn'}
            ]
        }
    };
 
    void function(a,b,c,d,e,f,g){a.alogObjectName=e,a[e]=a[e]||function(){(a[e].q=a[e].q||[]).push(arguments)},a[e].l=a[e].l||+new Date,d="https:"===a.location.protocol?"https://fex.bdstatic.com"+d:"http://fex.bdstatic.com"+d;var h=!0;if(a.alogObjectConfig&&a.alogObjectConfig.sample){var i=Math.random();a.alogObjectConfig.rand=i,i>a.alogObjectConfig.sample&&(h=!1)}h&&(f=b.createElement(c),f.async=!0,f.src=d+"?v="+~(new Date/864e5)+~(new Date/864e5),g=b.getElementsByTagName(c)[0],g.parentNode.insertBefore(f,g))}(window,document,"script","/hunter/alog/alog.min.js","alog"),void function(){function a(){}window.PDC={mark:function(a,b){alog("speed.set",a,b||+new Date),alog.fire&&alog.fire("mark")},init:function(a){alog("speed.set","options",a)},view_start:a,tti:a,page_ready:a}}();
    void function(n){var o=!1;n.onerror=function(n,e,t,c){var i=!0;return!e&&/^script error/i.test(n)&&(o?i=!1:o=!0),i&&alog("exception.send","exception",{msg:n,js:e,ln:t,col:c}),!1},alog("exception.on","catch",function(n){alog("exception.send","exception",{msg:n.msg,js:n.path,ln:n.ln,method:n.method,flag:"catch"})})}(window);
</script>

<script>
	!function(document, window){
		var log = {
			list: [],
			host: 'https://' + location.host + '/api/httpscheck',
			log: function(param) {
				var a = [];
		    	for(var k in param) {
		    		a.push(k + '=' + param[k]);
		    	}
		    	var msg = a.join('&');
		    	if(~this.list.indexOf(msg)){
		    		return;
		    	}
		    	this.list.push(msg);
		  		var img = new Image();
		    	var key = '_ik_log_' + (Math.random()*2147483648 ^ 0).toString(36);
		    	window[key] = img;
		    		img.onload = img.onerror = img.onabort = function() {
		        		img.onload = img.onerror = img.onabort = null;
		        		window[key] = null;
			    		img = null;
		    	};
		  		img.src = this.host + '?' + msg;
			}
		};

		function HTTPSWarningLog(){
			this.selector = [
				'link',
				'script',
				'img',
				'embed',
				'iframe'
			];
			this.warningCounter = 0;
			this.init();
		};

		HTTPSWarningLog.prototype = {
			init: function(){
				this.fetch();
			},

			fetch: function(){
				for(var tags = this.selector, i =0, len = tags.length; i < len;i++) {
					this.getTag(tags[i]);
				}
			},

			getTag: function(tag) {
				var domList = document.getElementsByTagName(tag);
				if(!domList.length) {
					return;
				}
				for(var i = 0,len = domList.length;i<len;i++) {
					var el = domList[i];
					var url = el.getAttribute(el.tagName==='LINK' ? 'href' : 'src');
                    if(el.getAttribute('rel') === 'canonical') {
                        continue;
                    }
					if(url && 'https:' === location.protocol && !url.indexOf('http:')){
						this.sendLog(el, el.tagName.toLowerCase(),url);
						this.warningCounter++;
					}
				}
			},
			
			sendLog: function(el, type, url){
				log.log({
					url: location.href,
					wtype: type,
					wurl: url
				});
			}
		};

		function domReady(fn){
		    if(document.addEventListener) {
		        document.addEventListener('DOMContentLoaded', function() {
		            document.removeEventListener('DOMContentLoaded',arguments.callee, false);
		            fn();
		        }, false);
		    }else if(document.attachEvent) {
		        document.attachEvent('onreadystatechange', function() {
		            if(document.readyState == 'complete') {
		                document.detachEvent('onreadystatechange', arguments.callee);
		                fn();
		            }
		        });
		    }
		};

		domReady(function(){
			new HTTPSWarningLog();
			for(var i=1; i<6; i++) {
				!function(i){
					setTimeout(function(){
						new HTTPSWarningLog();
					}, i*i*i*1000);
				}(i);
			}
		});
	}(document, window);
</script>

<meta itemprop="dateUpdate" content="2017-11-21 22:48:17" />
<meta itemprop="datePublished" content="2015-12-12 09:37:26" />
<meta itemprop="dateLatestReply" content="2017-11-21 22:48:17" />

<script data-app="eyJhcHBfa2V5IjoiMTMxNiIsImFwcF92aWV3IjoicHJvbW90ZSIsImZvcm1fZGVzYyI6IiIsInNlbmRfaW50ZXJ2YWwiOjUwLCJzZW5kX21ldGhvZCI6MywiYnJvd3Nlcl91cmwiOiJodHRwczovL3NvZmlyZS5iYWlkdS5jb20vZGF0YS91YS9hYi5qc29uIn0="
				src="//sofire.bdstatic.com/js/xaf.js">
		</script>
<script type="text/javascript">
			!function(){var n={},t={};n.context=function(n,e){var i=arguments.length;if(i>1)t[n]=e;else if(1==i){if("object"!=typeof n)return t[n];for(var o in n)n.hasOwnProperty(o)&&(t[o]=n[o])}},"F"in window||(window.F=n)}();;
			
            
																																																												
			F.context('user', {"isLogin":"1","isRealName":"2","stoken":"81312438f35e3e3d1f138fc9b1b58936","name":"geyumusufe","imId":"40f8676579756d75737566658ba2","id":"2727082048","euid":"40f84069236f25705e798ba2","wealth":"5","gradeIndex":"1","isMavin":"","encryptedBDUSS":"ad61uiC0ajt2HOaTEX3EujuMuuLoFU1O6m9YUeCBlxNL+87sWnJVeGKxOHOYPbVtPLlKE8q\/YDSsos3Z9MTQjjx2h83Js1iTvC58NtkJq+d\/QbF5cApwB1vveRDWD9kf84HAo8xT5b0Mji8CzCAmoEN8xnaFusdJAvDy3mWE1dWjNW\/KqcTk4WoVvocshb\/8SIra4Q\/9OEHFMfSkhrtzeuM7dGoCqKLB+LM9NpEfMHZ4Y1KBK38t\/rIu7w2ddj6K2nRbsehJSGz8cgdmN7hmTp9cVyqsFc2\/s9SqOw4","ECBD":"N5lg5NbCnRtTicq+yWgggLQ6As++oCpi0DLuSuwALetKZ8qo9tXrp4LhGcLn4o4Gbhp9lV2BElOB5uljfRIROpMf6JIrMCrxZQsuxVN4EzKXPpNgc4zuAruOfeX5jh84\/7Rp8BOWBLiKS9t\/KJLKsGjw+yXTaiJ2OYf80r3ePhB1ScSZZ9yu656l0nmHdEh4Uk+rflq4THXu3zOIeBSS3z0OQ7CtesiulIwXDJQidgvWjUTec56IQ1EdQY8MaEa2wt0uQJlU0vq\/H+WFIPIHZw==","experience":"53"});
			F.context('user')['internalAdmin'] = null;

							F.context('defaultQuery', '{"title":"","value":""}');
									
					        		        		            		        		            		        
		        F.context({
		            'sign-in' : {
		                'isSignIn' : '0',
		                'signinDays' : '[]',
		                'dayNum': '0',
		                'wealth': '',
		                'signCardCanUsed': '2',
		                'reSignItemId': '70',
                        'signBoxId': '0',
                        'futureSignBoxId': '128',
                        'futureBoxDay': '7'
		            }
		        });
		                F.context('isQuality', false);
            F.context('now', 1550753382);
		</script>
<script>F.context('sysTaskAutoInit', 1);</script>

<script type="text/javascript">
    	var dontTriggerPrompt = true;
        F.context('page',{
        	isAdopted: '1'
            ,adsAll:{
                adsEids: [87001]
            }
            ,misAsk: '0'
            ,delAsk: '0'
            ,isLocked: '0'
            ,isReplyLocked: '0'
            ,isFromWap: "0"
            ,cid: '1069'
            ,cidTop: '74'
            ,cidMid: '1069'
            ,qid: '649247327024278045'
            ,encodeQid: '649247327024278045'
            ,tags: '操作系统'
            ,title: 'wampserver 怎么配置路径'
            ,giveScore: '0'
            ,encodeUid: 'db8d4069236f25705e79501d'
                        ,uid: '491818459'
            ,createTime: '1449884246'
            ,imId: 'db8d6675435a3931323937501d'
            ,passPhoto: '0'
            ,rpRecommand: 'false'                        ,rankFile: '0'
                        ,userName: 'fuCZ91297'
            ,user : {
                sex: '1'
                ,iconType: '6'
                ,gradeIndex: '4'
                ,gradeIndexC: '四'
                                ,grAnswerNum: '71'
                                                                                                                                                                ,goodRate: '66'
                            }
                                    ,con: ''
                                    ,answerNum: ''
            ,isView: '1'
            ,isGetWealth:'1'
                        ,pgcArr: [790,791,792,794,795]
            ,isCompanyIask: '0'
            ,bdplayer:'mozilla\/5.0 (windows nt 10.0; win64; x64; rv:65.0) gecko\/20100101 firefox\/65.0'
                    });

        F.context('user')['internalAdmin'] = null;

                	F.context('user')['isAsker'] = '0';
        	F.context('user')['isReplyer'] = '0';
            F.context('user')['uid'] = '2727082048';
            F.context('user')['imId'] = '40f8676579756d75737566658ba2';
            F.context('user')['answerNumber'] = '0';
            // 用户是否展示答题领奖励弹窗 目前没有调用点，先保留
            F.context('user')['showfirstReplyTipModal'] = '1';
            F.context('user')['isNew'] = '0';
            F.context('user')['isHaveCid'] = '0';
            F.context('user')['stoken'] = '81312438f35e3e3d1f138fc9b1b58936';
            F.context('user')['isMavin'] = '0';
            F.context('user')['isRealName'] = '2';
            F.context('businessToken', '');
            F.context('user')['replyBold'] = '0';
            F.context('user')['replyRed'] = '0';
            F.context('user')['delSelfReply'] = '0';
            F.context('user')['delSelfQuestion'] = '0';
            F.context('privilege', {
                                                    'replyBold': {
                        'is_card': '0',
                        'remain_time': '',
                        'number': '0',
                        'days': ''
                    },
                                                                    'replyRed': {
                        'is_card': '0',
                        'remain_time': '',
                        'number': '0',
                        'days': ''
                    }
                                            });
                            F.context('answers', {});
                F.context('newbest', '1');
                
        F.context('isExpandAnswer', '0');

    </script>

<!--[if lte IE 8]>
<script>
                (function(){
                    var e="abbr,article,aside,audio,canvas,datalist,details,dialog,eventsource,figure,footer,header,hgroup,mark,menu,meter,nav,output,progress,section,time,video".split(","),
                    i=e.length;
                    while(i--){document.createElement(e[i])}
                 })();
            </script>
<![endif]-->
<link rel="stylesheet" type="text/css" href="https://iknowpc.bdimg.com/static/common/pkg/common.63c21d1.css" /><link rel="stylesheet" type="text/css" href="https://iknowpc.bdimg.com/static/common/widget/header-metis/header.4b73688.css" /><link rel="stylesheet" type="text/css" href="https://iknowpc.bdimg.com/static/question-new/pkg/aio.a6b89eb.css" /><link rel="stylesheet" type="text/css" href="https://iknowpc.bdimg.com/static/question-new/pkg/editor.9a07820.css" /><link rel="stylesheet" type="text/css" href="https://iknowpc.bdimg.com/static/common/widget/upgrade-tips/upgrade-tips.f217a81.css" /></head>

<script> alog('speed.set', 'ht', +new Date()); </script>

<body class="layout-center has-menu">

<div id="userbar" class="userbar userbar-renew" data="">
<ul class="aside-list">
<li>
<a href="http://www.baidu.com/" class="toindex">百度首页</a>
</li>
<li>
<a href="/ihome" class="user-name" target="_blank" id="user-name">geyumusufe<i class="i-arrow-down"></i></a></li>
</li>
<li alog-alias="userbar-msg" id="userbar-msg"><a class="userbar-msg-a" href="/ihome/notice/center" target="_blank" target="_self">消息<span class="orange-num"><i></i></span></a></li>
<li alog-alias="baidu-msg" id="baidu-msg"><a href="/ichat/chatlist">私信<i class="bd-msg"></i></a></li>
<li class="shop-entrance">
<a href="/shop" title="知道商城">商城<i class="i-house" style="display: none;"></i></a>
<span class="lucky-try"></span>
</li>
</ul>
<div class="sublist-container username-sublist" style="display:none" id="username-sublist">
<div class="sublist-arrow-up"></div>
<ul class="sub-list">
<li><a id="userbar-myinfo" href="/ihome/homepage/recommendquestion" target="_blank">我的主页</a></li>
<li><a id="userbar-my-ask" href="https://zhidao.baidu.com/ihome/homepage/myask" target="_blank">我的提问</a></li>
<li><a id="userbar-my-answer" href="https://zhidao.baidu.com/ihome/homepage/myanwser" target="_blank">我的回答</a></li>
<li><a id="userbar-my-task" href="https://zhidao.baidu.com/ihome/homepage/mytask" target="_blank">我的任务</a></li>
<li><a id="userbar-account" href="http://passport.baidu.com/center" target="_blank">帐号设置</a></li>
<li class="last"><a href="http://passport.baidu.com/?logout&amp;aid=7&amp;u=http%3A//zhidao.baidu.com" id="userbar-logout">退出帐号</a></li>
</ul>
</div>
</div>


<div class="head-wrap">
<hr class="divider">
<header id="header" class="container">
<a log="page:question,action:click,pos:fyb-word" href="#" target="_blank" class="adTopImg from-fyb"></a>


<div id="search-box" class="search-box-new line">
<ul class="channel grid">
<li><a log="sc_pos:c_baidu" data-type='baidu' rel="nofollow" href="http://www.baidu.com/s?cl=3&wd=wampsever%20%C5%E4%D6%C3PHP%C2%B7%BE%B6">网页</a></li>
<li><a log="sc_pos:c_news" data-type='news' rel="nofollow" href="https://www.baidu.com/s?rtt=1&bsst=1&cl=2&tn=news&word=wampsever%20%C5%E4%D6%C3PHP%C2%B7%BE%B6&fr=zhidao">资讯</a></li>
<li><a log="sc_pos:c_tieba" data-type='tieba' rel="nofollow" href="http://tieba.baidu.com/f?kw=wampsever%20%C5%E4%D6%C3PHP%C2%B7%BE%B6&t=4">贴吧</a></li><li><strong>知道</strong></li>
<li><a log="sc_pos:c_video" data-type='video' rel="nofollow" href="https://www.baidu.com/sf/vsearch?pd=video&tn=vsearch&wd=wampsever%20%C5%E4%D6%C3PHP%C2%B7%BE%B6&rsv_spt=16">视频</a></li>
<li><a log="sc_pos:c_mp3" data-type='music' rel="nofollow" href="http://music.baidu.com/search?fr=zhidao&key=wampsever%20%C5%E4%D6%C3PHP%C2%B7%BE%B6">音乐</a></li><li><a log="sc_pos:c_pic" data-type='image' rel="nofollow" href="http://image.baidu.com/search/index?tn=baiduimage&ct=201326592&lm=-1&cl=2&word=wampsever%20%C5%E4%D6%C3PHP%C2%B7%BE%B6&t=3&ie=gbk">图片</a></li>
<li><a log="sc_pos:c_map" data-type='map' rel="nofollow" href="http://map.baidu.com/m?word=wampsever%20%C5%E4%D6%C3PHP%C2%B7%BE%B6&fr=map007">地图</a></li><li><a log="sc_pos:c_doc" data-type='wenku' rel="nofollow" href="http://wenku.baidu.com/search?word=wampsever%20%C5%E4%D6%C3PHP%C2%B7%BE%B6&lm=0&od=0">文库</a></li>
<li><a log="sc_pos:c_more" data-type="more" href="http://www.baidu.com/more/">更多&raquo;</a></li>
</ul>
<div class="search-block clearfix">
<div class="search-cont clearfix">
<a class="logo" href="/" title="百度知道"></a>
<form action="/search" name="search-form" method="get" id="search-form-new" class="search-form">
<input class="hdi" id="kw" maxlength="256" tabindex="1" size="46" name="word" value="wampsever 配置PHP路径" autocomplete="off" placeholder="" />
<button alog-action="g-search-anwser" type="submit" id="search-btn" hidefocus="true"  tabindex="2" class="btn-global">搜索答案</button>
<a href="#" alog-action="g-i-ask" class="i-ask-link" id="ask-btn-new">我要提问</a>
</form>
</div>
</div>
</div>
<script>
                    // 搜索框可用时间打点
                    alog && alog('speed.set', 'c_sbox', +new Date); alog.fire && alog.fire("mark");
                </script>

<div class="wgt-header-title">
<div class="wgt-header-title-content">
<h1 class="wgt-header-title-text">wampserver 怎么配置路径</h1>
<span  class="iknow-icons wgt-header-title-btn">&#xe768; 我来答</span>
</div>
</div>

</header>
</div>

<div class="nav-menu-container" id="j-nav-menu-container">
<div class="nav-show-control">
<div class="nav-menu-layout">
<div class="nav-menu line">
<div class="nav-menu-content container">
<div class="content-box">
<div class="menu-item menu-item-index">
<a class="menu-title " href="/">
首页</a>
</div>
<div class="menu-item-box">
<div class="menu-item menu-item-cat">
<a class="menu-title " href="/list?fr=daohang" target="_blank">
问题</a>
<div class="menu-content">
<ul class="menu-sub-list">
<li class="menu-sub-item-wp">
<a class="menu-sub-item" href="/list?fr=daohang" target="_blank" target="_blank">
全部问题</a>
</li>
<li class="menu-sub-item-wp">
<a class="menu-sub-item" href="/list?cid=101&fr=daohang" target="_blank" target="_blank">
经济金融</a>
</li>
<li class="menu-sub-item-wp">
<a class="menu-sub-item" href="/list?cid=102&fr=daohang" target="_blank" target="_blank">
企业管理</a>
</li>
<li class="menu-sub-item-wp">
<a class="menu-sub-item" href="/list?cid=103&fr=daohang" target="_blank" target="_blank">
法律法规</a>
</li>
<li class="menu-sub-item-wp">
<a class="menu-sub-item" href="/list?cid=104&fr=daohang" target="_blank" target="_blank">
社会民生</a>
</li>
<li class="menu-sub-item-wp">
<a class="menu-sub-item" href="/list?cid=105&fr=daohang" target="_blank" target="_blank">
科学教育</a>
</li>
<li class="menu-sub-item-wp">
<a class="menu-sub-item" href="/list?cid=106&fr=daohang" target="_blank" target="_blank">
健康生活</a>
</li>
<li class="menu-sub-item-wp">
<a class="menu-sub-item" href="/list?cid=107&fr=daohang" target="_blank" target="_blank">
体育运动</a>
</li>
<li class="menu-sub-item-wp">
<a class="menu-sub-item" href="/list?cid=108&fr=daohang" target="_blank" target="_blank">
文化艺术</a>
</li>
<li class="menu-sub-item-wp">
<a class="menu-sub-item" href="/list?cid=109&fr=daohang" target="_blank" target="_blank">
电子数码</a>
</li>
<li class="menu-sub-item-wp">
<a class="menu-sub-item" href="/list?cid=110&fr=daohang" target="_blank" target="_blank">
电脑网络</a>
</li>
<li class="menu-sub-item-wp">
<a class="menu-sub-item" href="/list?cid=111&fr=daohang" target="_blank" target="_blank">
娱乐休闲</a>
</li>
<li class="menu-sub-item-wp">
<a class="menu-sub-item" href="/list?cid=113&fr=daohang" target="_blank" target="_blank">
行政地区</a>
</li>
<li class="menu-sub-item-wp">
<a class="menu-sub-item" href="/list?cid=114&fr=daohang" target="_blank" target="_blank">
心理分析</a>
</li>
<li class="menu-sub-item-wp">
<a class="menu-sub-item" href="/list?cid=115&fr=daohang" target="_blank" target="_blank">
医疗卫生</a>
</li>
</ul>
</div>
</div>
<div class="menu-item menu-item-lanmu">
<a class="menu-title" href="javascript:;">
精选</a>
<div class="menu-content">
<ul class="menu-sub-list">
<li class="menu-sub-item-wp">
<a class="menu-sub-item column-sub-item" href="/special/column?fr=daohang" target="_blank">
知道专栏</a>
</li>
<li class="menu-sub-item-wp">
<a class="menu-sub-item" href="/daily?fr=daohang" target="_blank">
知道日报</a>
</li>
<li class="menu-sub-item-wp">
<a class="menu-sub-item" href="/bigdata/view" target="_blank">
知道大数据</a>
</li>
<li class="menu-sub-item-wp">
<a class="menu-sub-item" href="/culture/index?fr=daohang" target="_blank">
知道非遗</a>
</li>
</ul>
</div>
</div>
<div class="menu-item menu-item-user">
<a class="menu-title" href="javascript:;">
用户<div class="menu-title-icon">
<i class="iknow-icons">&#xe715;</i>
</div>
</a>
<div class="menu-content">
<ul class="menu-sub-list">
<li class="menu-sub-itemline-wp">
<a class="menu-sub-item metis-sub-item" href="/home/partnerhome?fr=daohang" target="_blank">
知道合伙人<div class="menu-title-icon">
<i class="iknow-icons">&#xe715;</i>
</div>
</a>
</li>
<li class="menu-sub-item-wp">
<a class="menu-sub-item" href="/uteam?fr=daohang" target="_blank">
芝麻团</a>
</li>
<li class="menu-sub-item-wp">
<a class="menu-sub-item" href="/user/admin?fr=daohang" target="_blank">
芝麻将</a>
</li>
<li class="menu-sub-item-wp">
<a class="menu-sub-item" href="/daily/authorcenter?fr=daohang" target="_blank">
日报作者</a>
</li>
<li class="menu-sub-item-wp">
<a class="menu-sub-item" href="/misc/nowshowstar?fr=daohang" target="_blank">
知道之星</a>
</li>
<div class="menu-item-user-list">机构合作<div class="line-bar"></div></div>
<li class="menu-sub-item-wp">
<a class="menu-sub-item" href="/opendev?fr=daohang" target="_blank">
开放平台</a>
</li>
<li class="menu-sub-item-wp">
<a class="menu-sub-item" href="/special/view/cooperation?fr=daohang" target="_blank">
品牌合作</a>
</li>
<div class="menu-item-user-list">知道福利<div class="line-bar"></div></div>
<li class="menu-sub-item-wp">
<a class="menu-sub-item" href="/shop?fr=daohang" target="_blank">
财富商城</a>
</li>
</ul>
</div>
</div>
<div class="menu-item menu-item-expert">
<a class="menu-title" href="javascript:;">
特色</a>
<div class="menu-content">
<ul class="menu-sub-list">
<li class="menu-sub-item-wp">
<a class="menu-sub-item menu-sub-item-expert" href="http://jingyan.baidu.com/" target="_blank">
<span class="expert-icon expert-icon-jy"></span>
<span>经验</span>
</a>
</li>
<li class="menu-sub-item-wp">
<a class="menu-sub-item menu-sub-item-expert" href="https://baobao.baidu.com" target="_blank">
<span class="expert-icon expert-icon-baby"></span>
<span>宝宝知道</span>
</a>
</li>
<li class="menu-sub-item-wp">
<a class="menu-sub-item menu-sub-item-expert" href="https://www.zybang.com" target="_blank">
<span class="expert-icon expert-icon-zuoye"></span>
<span>作业帮</span>
</a>
</li>
</ul>
</div>
</div>
</div>
<div class="menu-right-section">
<ul class="menu-right-list">
<li class="menu-right-list-item zhidao-app">
<a href="/activity/simpleindexact?tplName=nareplace&type=pc" class="menu-right-list-link" target="_blank">
<span class="item-icon">
</span>
<span class="item-name">
手机版</span>
</a>
<span class="right-list-item-devide">
</span>
</li>
<li class="menu-right-list-item user-center">
<a href="/ihome" class="menu-right-list-link" target="_blank">
<span class="item-icon">
</span>
<span class="item-name">
我的知道</span>
</a>
</li>
</ul>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<script>
        // 导航可用时间
        alog && alog('speed.set', 'c_menu', +new Date); alog.fire && alog.fire("mark");
    </script>

<div id="body" class="container">

<div class="layout-wrap">
<div style="display:none">
<nav class="wgt-nav f-12" alog-group="qb-cate-nav">
<a href="/">百度知道</a>
&gt;<a href="/browse/74">电脑/网络</a>
&gt;<a href="/browse/1069">常见软件</a>
</nav>
</div>
<section class="line qb-section">
<article class="grid qb-content" id="qb-content">
<div class="wgt-ask accuse-response line " id="wgt-ask">
<h1 accuse="qTitle">
<span class="ask-title">wampserver 怎么配置路径</span>
</h1>
<div class="line f-aid ask-info ff-arial" id="ask-info">
<div class="line wgt-replyer-line">
<span  class="iknow-icons" alog-alias="qb-answer-bar" id="answer-bar">&#xe768;&nbsp;我来答</span>
<ins class="share-area cannotanswer"></ins>
<ins class="accuse-area cannotanswer"></ins>
<span id="v-times"></span>
</div>
<div class="line " id="answer-editor" data-realName="2"></div>
<script type="text/html" id="replyer-addtags-tmpl">
<div class="addtags-box">
    <div class="addtags-mask"></div>
    <div class="addtags-content">
        <i class="iknow-qb_replyer_icons i-ask-close addtags-close"></i>
        <div class="addtags-head"><div class="addtags-head-img"></div><span>回答提交成功！</span></div>
        <div class="addtags-subhead">选择擅长的领域继续答题？</div>
        <div class="tags-box">
            {@each tagList as item}
            <li class="{@if item.isQuesTag && item.isQuesTag == 1}selected{@/if}">${item.tagName}</li>
            {@/each}
        </div>
        <div class="addtags-bottom">
            <div class="addtags-sub">继续回答</div><div class="addtags-notip ml-10">不再提示</div>
        </div>
    </div>
</div>
</script>
<script type="text/html" id="replyer-tags-tmpl">
<div class="tags-box">
    <div class="tags-mask"></div>
    <div class="tags-content">
        <i class="iknow-qb_replyer_icons i-ask-close tags-close"></i>
        <div class="tags-head">回答提交成功！</div>
        <div class="tags-subhead">是否继续回答问题？</div>
        <div class="tags-bottom">
            <div class="tags-sub">继续回答</div><div class="tags-notip ml-10">不再提示</div>
        </div>
    </div>
</div>
</script>
<script type="text/html" id="answer-for-lottery">
    <div class="affairs-box answer-for-lottery">
        <div class="affairs-mask"></div>
        <div class="affairs-content">
            <i class="iknow-qb_replyer_icons i-ask-close affairs-close"></i>
            <a log="pos:government-affairs-act,action:click" href="https://zhidao.baidu.com/shop/lottery?from=datichoujiang" class="affairs-img">
                <img src="https://gss0.bdstatic.com/7051cy89RcgCncy6lo7D0j9wexYrbOWh7c50/answer-for-lottery.png">
            </a>
        </div>
    </div>
</script>
<script type="text/html" id="visit-join-model-template">
    <p class="visit-join-model-title">加入团队，和一群志同道合之人相结识，一起帮助更多人</p>
    <div class="visit-join-model-content" id="visit-join-model-content">
        <div class="carousel-misc"><a href="javascript:void(0);" data-action="left" class="visit-join-control visit-join-control-left visit-join-control-left-disable"></a><a href="javascript:void(0);" data-action="right" class="visit-join-control visit-join-control-right"></a></div>
    </div>
    <div class="visit-join-model-warn" id="visit-join-warn">请先选择一个要加入的团队</div>
</script>
</div>
</div>
<script>
    // 提问区域可用时间
    alog && alog('speed.set', 'c_ask', +new Date); alog.fire && alog.fire("mark");
</script>
<div class="question-all-answers-number">
<span class="question-all-answers-line"></span>
<span class="question-all-answers-title" style="font-weight: 700;">1个回答</span>
<div class="question-number-text-chain">
<a href="https://zhidao.baidu.com/question/333560791569803845.html?entry=hottopic" target="_blank" log="module:question,page:question,action:click,area:question_text_chain" class="text-chain-wrapper">
<span class="text-chain-title">#热议#</span>
<span class="text-chain-content">支付宝还信用卡将收费，你会继续使用该服务吗？</span>
</a>
</div>
</div>
<script type="text/javascript">
        F.context('answers')['2383726729'] = {uid:"32118001",imId:"f1147a7a6c31333134353230ea01",isBest:"1",passPhoto:"1",id:"2383726729",userName:"zzl1314520",userNameEnc:"zzl1314520",user:{sex:"1",iconType:"6",gradeIndex:"17",grAnswerNum:"8288",carefield: [{cid:"761",cname:"历史话题"},{cid:"96",cname:"电影"},{cid:"206",cname:"民俗传统"},{cid:"1284",cname:"Windows"},{cid:"1097",cname:"文学"}],isFromTeam:"1",teamName:"编程编织出世界",teamId:"77777",isAuth:"0",authTitle:"",isUserAdmin:"0",userAdminLevel:"4",userAdminTitle:"初级芝麻将",userAdminType:"1",isFamous:"0",isMaster:"0",goodRate:"92",applyExcType:"4"},isAnonymous:"0",isCurrentUser:"0",mapUrl:"",refer:"",replyAskNum:"",threadId:"9534906917",hasComment:"0",qid:"649247327024278045",raid:"",recommendCanceled:"0"};
        F.context('answers')['2383726729'].user && F.context('answers')['2383726729'].user.business && (F.context('answers')['2383726729'].user.business.insType = 0);
        F.context('answers')['2383726729'].encodeUid = 'f1144069236f25705e79ea01';
                    F.context('answers')['2383726729'].ext_pack = {"reply_entry":"qb_ihome_tag","mode_qtype":"0","mode_begintime":"0","op_uid":"0","anony_good_value":"2","reason_2_2":"1","recTime":"1511275697","anony_bad_value":"3","reason_2_1":"1"};
                            F.context('answers')['2383726729'].bit_pack = {"is_recommend":"0","wap_flag":"0","is_pic_contained":"0","media_flag":"0","help_flag":"0","anonymous":"0","is_really_anonymous":"0","level_new":"1","comment_flag":"0","in_mis":"0","auto_recommend":"0","content_rich_flag":"1","prior_flag":"1","hidden_flag":"0","rec_canceled_flag":"0","mis_flag":"0","file_flag":"0","read_flag":"0","is_challenge":"0","ikaudio_flag":"0","mavin_flag":"0","authentic_state":"0","is_compulsory_best":"0","dynamic_stick_flag":"0"};
            </script>
<div class="wgt-best
        " id="best-answer-2383726729">
<div id="wgt-replyer-all-2383726729" class="wgt-replyer-all">
<img class="wgt-replyer-all-avatar" src ="https://gss0.bdstatic.com/7Ls0a8Sm1A5BphGlnYG/sys/portrait/item/f1147a7a6c31333134353230ea01.jpg" data-href="https://zhidao.baidu.com/usercenter?uid=f1144069236f25705e79ea01&amp;teamType=1">
<span class="wgt-replyer-all-v ikonw-qb-new-icon
        "></span>
<span class="wgt-replyer-all-uname 
        " data-href="https://zhidao.baidu.com/usercenter?uid=f1144069236f25705e79ea01&amp;teamType=1">zzl1314520</span>
<br />
<span class="wgt-replyer-all-box">
<span class="wgt-replyer-all-slogan">来自电脑网络类芝麻团</span>
<span class="wgt-replyer-all-time">
推荐于2017-11-21
</span>
</span>
<div class="wgt-replyer-all-card">
<div class="wgt-replyer-all-triangle1"></div><div class="wgt-replyer-all-triangle2"></div>
<div class="wgt-replyer-all-card-avatar-wrap">
<img class="wgt-replyer-all-card-avatar wgt-replyer-all-card-avatars" 
                src ="https://gss0.bdstatic.com/7Ls0a8Sm1A5BphGlnYG/sys/portrait/item/f1147a7a6c31333134353230ea01.jpg"
                data-href="https://zhidao.baidu.com/usercenter?uid=f1144069236f25705e79ea01&amp;teamType=1">
</div>
<span class="wgt-replyer-all-v wgt-replyer-all-card-v  ikonw-qb-new-icon"></span>
<span class="wgt-replyer-all-card-name3 wgt-replyer-all-card-names" data-href="https://zhidao.baidu.com/usercenter?uid=f1144069236f25705e79ea01&amp;teamType=1">zzl1314520</span>
<br />
<span class="wgt-replyer-all-card-accept">采纳数：<span class="wgt-replyer-all-card-green">8288</span></span>
<span class="wgt-replyer-all-card-praise">获赞数：<span class="wgt-replyer-all-card-green">20185</span></span>
<span class="wgt-replyer-all-card-level">LV17</span>
<br />
<span class="wgt-replyer-all-card-good">擅长：<a class="wgt-replyer-all-card-black" href="/browse/761" target="_blank">历史话题</a>
<a class="wgt-replyer-all-card-black" href="/browse/96" target="_blank">电影</a>
<a class="wgt-replyer-all-card-black" href="/browse/206" target="_blank">民俗传统</a>
<a class="wgt-replyer-all-card-black" href="/browse/1284" target="_blank">Windows</a>
<a class="wgt-replyer-all-card-black" href="/browse/1097" target="_blank">文学</a>
</span>
<br />
<span class="wgt-replyer-all-card-team">参与团队：<a class="wgt-replyer-all-card-black" href="/uteam/view?fr=qb&teamId=77777" rel="noopener" target="_blank">编程编织出世界</a></span>
<br />
<a href="/new?fix=zzl1314520" target="_blank" class="wgt-replyer-all-card-ask">向TA提问</a>
<a href="/ichat/chatlist?concats=zzl1314520" target="_blank" class="wgt-replyer-all-card-letter">私信TA</a>
</div>
</div>
<div class="bd answer" id="answer-2383726729">
<div class="line info f-aid">
</div>
<div class="line content">
<div id="best-content-2383726729" accuse="aContent" class="best-text mb-10">
<div class="wgt-best-mask">
<div class="wgt-best-showbtn">
展开全部<span class="wgt-best-arrowdown"></span>
</div>
</div>
<p>对于初做PHP网站的朋友来说，第一步肯定是希望在自己电脑是搭建PHP环境，省去空间和上传的麻烦！但搭建环境也不是件容易的事情，因此在这里跟大家介绍我作为一名新手在使用的方便好用的PHP服务器架设软件，那就是wampserver，这款软件在安装的过程中就已经把Apache、MySQL、PHP继承好了，而且也做好了相应的配置，除此之外，还加上了SQLitemanagerPhpmyadmin，省去了很多复杂的配置过程，能把更多的时间放在程序开发上。</p><p><br /></p><p><br /></p><p>一、安装wampserver&nbsp;&nbsp;</p><ol><li><p>安装wampserver的过程很简单，只要一直点击next就可以完成安装了：依次操作了</p></li><li><p>选择默认浏览工具：安装过程中会提示要选择默认浏览工具，不过要注意哦，这个浏览工具指的可不是浏览器哦，它指的是windows的浏览器，也就是explorer.exe，默认的就是这个，直接点击“打开”就可以了。</p></li><li><p>会提示一个输入管理员邮箱以及邮箱SMTP服务器的窗口，这个如果大家愿意填写，可以填一下，不过一般情况下直接点击next就可以了，不会影响安装。</p></li><li><p>OK，安装顺利结束！很简单吧！</p></li><li><p>安装完之后屏幕右下角就会出来一个标记，</p></li><li><p>右键单击，然后依次选择Language—Chinese，</p></li><li><p>左键单击右下角图标，再点击“www 目录”会打开安装wampserver默认存放网页文件夹，但是很多时候，存放网页的文件夹并不是在那个目录下的，怎么才能改掉这个目录。当然有办法，打开wampserver的安装目录，在打开里面的“script”文件夹，用记事本打开里面的config.inc.php，找到“$wwwDir = $c_installDir.&#39;/www&#39;;”，改成大家希望的目录就行了，比如改D:\website，对应的代码就是$wwwDir = ‘D:/website’;（注意，windows下表示路径的“\”在这里必须改为“/”）。然后关闭wampserver，然后再打开，www目录就变成设定的D:\website了。</p></li></ol>
</div>
<div class="quality-content-view-more mb-15">
</div>
<div class="newbest-content-meta line ff-arial">
<div class="wgt-best-operator clearfix f-aid ">
<img src="data:image/jpeg;base64,/9j/4QPBRXhpZgAATU0AKgAAAAgABwESAAMAAAABAAEAAAEaAAUAAAABAAAAYgEbAAUAAAABAAAAagEoAAMAAAABAAIAAAExAAIAAAAkAAAAcgEyAAIAAAAUAAAAlodpAAQAAAABAAAArAAAANgACvyAAAAnEAAK/IAAACcQQWRvYmUgUGhvdG9zaG9wIENDIDIwMTUgKE1hY2ludG9zaCkAMjAxODowNjoyOCAyMDowMDoxOQAAAAADoAEAAwAAAAH//wAAoAIABAAAAAEAAAX6oAMABAAAAAEAAAAQAAAAAAAAAAYBAwADAAAAAQAGAAABGgAFAAAAAQAAASYBGwAFAAAAAQAAAS4BKAADAAAAAQACAAACAQAEAAAAAQAAATYCAgAEAAAAAQAAAoMAAAAAAAAASAAAAAEAAABIAAAAAf/Y/+0ADEFkb2JlX0NNAAL/7gAOQWRvYmUAZIAAAAAB/9sAhAAMCAgICQgMCQkMEQsKCxEVDwwMDxUYExMVExMYEQwMDAwMDBEMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMAQ0LCw0ODRAODhAUDg4OFBQODg4OFBEMDAwMDBERDAwMDAwMEQwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAz/wAARCAACAKADASIAAhEBAxEB/90ABAAK/8QBPwAAAQUBAQEBAQEAAAAAAAAAAwABAgQFBgcICQoLAQABBQEBAQEBAQAAAAAAAAABAAIDBAUGBwgJCgsQAAEEAQMCBAIFBwYIBQMMMwEAAhEDBCESMQVBUWETInGBMgYUkaGxQiMkFVLBYjM0coLRQwclklPw4fFjczUWorKDJkSTVGRFwqN0NhfSVeJl8rOEw9N14/NGJ5SkhbSVxNTk9KW1xdXl9VZmdoaWprbG1ub2N0dXZ3eHl6e3x9fn9xEAAgIBAgQEAwQFBgcHBgU1AQACEQMhMRIEQVFhcSITBTKBkRShsUIjwVLR8DMkYuFygpJDUxVjczTxJQYWorKDByY1wtJEk1SjF2RFVTZ0ZeLys4TD03Xj80aUpIW0lcTU5PSltcXV5fVWZnaGlqa2xtbm9ic3R1dnd4eXp7fH/9oADAMBAAIRAxEAPwD1L/OS/wA5fLCSSn6n/wA5L/OXywkkp+p/85L/ADl8sJJKfqf/ADkv85fLCSSn6n/zkv8AOXywkkp+p/8AOS/zl8sJJKfqf/OS/wA5fLCSSn6n/wA5L/OXywkkp+p/85L/ADl8sJJKfqf/ADkv85fLCSSn/9n/7QvKUGhvdG9zaG9wIDMuMAA4QklNBCUAAAAAABAAAAAAAAAAAAAAAAAAAAAAOEJJTQQ6AAAAAADXAAAAEAAAAAEAAAAAAAtwcmludE91dHB1dAAAAAUAAAAAUHN0U2Jvb2wBAAAAAEludGVlbnVtAAAAAEludGUAAAAASW1nIAAAAA9wcmludFNpeHRlZW5CaXRib29sAAAAAAtwcmludGVyTmFtZVRFWFQAAAABAAAAAAAPcHJpbnRQcm9vZlNldHVwT2JqYwAAAAVoIWg3i75/bgAAAAAACnByb29mU2V0dXAAAAABAAAAAEJsdG5lbnVtAAAADGJ1aWx0aW5Qcm9vZgAAAAlwcm9vZkNNWUsAOEJJTQQ7AAAAAAItAAAAEAAAAAEAAAAAABJwcmludE91dHB1dE9wdGlvbnMAAAAXAAAAAENwdG5ib29sAAAAAABDbGJyYm9vbAAAAAAAUmdzTWJvb2wAAAAAAENybkNib29sAAAAAABDbnRDYm9vbAAAAAAATGJsc2Jvb2wAAAAAAE5ndHZib29sAAAAAABFbWxEYm9vbAAAAAAASW50cmJvb2wAAAAAAEJja2dPYmpjAAAAAQAAAAAAAFJHQkMAAAADAAAAAFJkICBkb3ViQG/gAAAAAAAAAAAAR3JuIGRvdWJAb+AAAAAAAAAAAABCbCAgZG91YkBv4AAAAAAAAAAAAEJyZFRVbnRGI1JsdAAAAAAAAAAAAAAAAEJsZCBVbnRGI1JsdAAAAAAAAAAAAAAAAFJzbHRVbnRGI1B4bEBSAAAAAAAAAAAACnZlY3RvckRhdGFib29sAQAAAABQZ1BzZW51bQAAAABQZ1BzAAAAAFBnUEMAAAAATGVmdFVudEYjUmx0AAAAAAAAAAAAAAAAVG9wIFVudEYjUmx0AAAAAAAAAAAAAAAAU2NsIFVudEYjUHJjQFkAAAAAAAAAAAAQY3JvcFdoZW5QcmludGluZ2Jvb2wAAAAADmNyb3BSZWN0Qm90dG9tbG9uZwAAAAAAAAAMY3JvcFJlY3RMZWZ0bG9uZwAAAAAAAAANY3JvcFJlY3RSaWdodGxvbmcAAAAAAAAAC2Nyb3BSZWN0VG9wbG9uZwAAAAAAOEJJTQPtAAAAAAAQAEgAAAABAAIASAAAAAEAAjhCSU0EJgAAAAAADgAAAAAAAAAAAAA/gAAAOEJJTQQNAAAAAAAEAAAAHjhCSU0EGQAAAAAABAAAAB44QklNA/MAAAAAAAkAAAAAAAAAAAEAOEJJTScQAAAAAAAKAAEAAAAAAAAAAjhCSU0D9QAAAAAASAAvZmYAAQBsZmYABgAAAAAAAQAvZmYAAQChmZoABgAAAAAAAQAyAAAAAQBaAAAABgAAAAAAAQA1AAAAAQAtAAAABgAAAAAAAThCSU0D+AAAAAAAcAAA/////////////////////////////wPoAAAAAP////////////////////////////8D6AAAAAD/////////////////////////////A+gAAAAA/////////////////////////////wPoAAA4QklNBAAAAAAAAAIAAThCSU0EAgAAAAAABAAAAAA4QklNBDAAAAAAAAIBAThCSU0ELQAAAAAABgABAAAABDhCSU0ECAAAAAAAEAAAAAEAAAJAAAACQAAAAAA4QklNBB4AAAAAAAQAAAAAOEJJTQQaAAAAAANXAAAABgAAAAAAAAAAAAAAEAAABfoAAAARAFIAZQBjAHQAYQBuAGcAbABlACAAMQA3ACAAQwBvAHAAeQAAAAEAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAAAAAAAAAAF+gAAABAAAAAAAAAAAAAAAAAAAAAAAQAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAAQAAAAAAAG51bGwAAAACAAAABmJvdW5kc09iamMAAAABAAAAAAAAUmN0MQAAAAQAAAAAVG9wIGxvbmcAAAAAAAAAAExlZnRsb25nAAAAAAAAAABCdG9tbG9uZwAAABAAAAAAUmdodGxvbmcAAAX6AAAABnNsaWNlc1ZsTHMAAAABT2JqYwAAAAEAAAAAAAVzbGljZQAAABIAAAAHc2xpY2VJRGxvbmcAAAAAAAAAB2dyb3VwSURsb25nAAAAAAAAAAZvcmlnaW5lbnVtAAAADEVTbGljZU9yaWdpbgAAAA1hdXRvR2VuZXJhdGVkAAAAAFR5cGVlbnVtAAAACkVTbGljZVR5cGUAAAAASW1nIAAAAAZib3VuZHNPYmpjAAAAAQAAAAAAAFJjdDEAAAAEAAAAAFRvcCBsb25nAAAAAAAAAABMZWZ0bG9uZwAAAAAAAAAAQnRvbWxvbmcAAAAQAAAAAFJnaHRsb25nAAAF+gAAAAN1cmxURVhUAAAAAQAAAAAAAG51bGxURVhUAAAAAQAAAAAAAE1zZ2VURVhUAAAAAQAAAAAABmFsdFRhZ1RFWFQAAAABAAAAAAAOY2VsbFRleHRJc0hUTUxib29sAQAAAAhjZWxsVGV4dFRFWFQAAAABAAAAAAAJaG9yekFsaWduZW51bQAAAA9FU2xpY2VIb3J6QWxpZ24AAAAHZGVmYXVsdAAAAAl2ZXJ0QWxpZ25lbnVtAAAAD0VTbGljZVZlcnRBbGlnbgAAAAdkZWZhdWx0AAAAC2JnQ29sb3JUeXBlZW51bQAAABFFU2xpY2VCR0NvbG9yVHlwZQAAAABOb25lAAAACXRvcE91dHNldGxvbmcAAAAAAAAACmxlZnRPdXRzZXRsb25nAAAAAAAAAAxib3R0b21PdXRzZXRsb25nAAAAAAAAAAtyaWdodE91dHNldGxvbmcAAAAAADhCSU0EKAAAAAAADAAAAAI/8AAAAAAAADhCSU0EEQAAAAAAAQEAOEJJTQQUAAAAAAAEAAAABjhCSU0EDAAAAAACnwAAAAEAAACgAAAAAgAAAeAAAAPAAAACgwAYAAH/2P/tAAxBZG9iZV9DTQAC/+4ADkFkb2JlAGSAAAAAAf/bAIQADAgICAkIDAkJDBELCgsRFQ8MDA8VGBMTFRMTGBEMDAwMDAwRDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAENCwsNDg0QDg4QFA4ODhQUDg4ODhQRDAwMDAwREQwMDAwMDBEMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwM/8AAEQgAAgCgAwEiAAIRAQMRAf/dAAQACv/EAT8AAAEFAQEBAQEBAAAAAAAAAAMAAQIEBQYHCAkKCwEAAQUBAQEBAQEAAAAAAAAAAQACAwQFBgcICQoLEAABBAEDAgQCBQcGCAUDDDMBAAIRAwQhEjEFQVFhEyJxgTIGFJGhsUIjJBVSwWIzNHKC0UMHJZJT8OHxY3M1FqKygyZEk1RkRcKjdDYX0lXiZfKzhMPTdePzRieUpIW0lcTU5PSltcXV5fVWZnaGlqa2xtbm9jdHV2d3h5ent8fX5/cRAAICAQIEBAMEBQYHBwYFNQEAAhEDITESBEFRYXEiEwUygZEUobFCI8FS0fAzJGLhcoKSQ1MVY3M08SUGFqKygwcmNcLSRJNUoxdkRVU2dGXi8rOEw9N14/NGlKSFtJXE1OT0pbXF1eX1VmZ2hpamtsbW5vYnN0dXZ3eHl6e3x//aAAwDAQACEQMRAD8A9S/zkv8AOXywkkp+p/8AOS/zl8sJJKfqf/OS/wA5fLCSSn6n/wA5L/OXywkkp+p/85L/ADl8sJJKfqf/ADkv85fLCSSn6n/zkv8AOXywkkp+p/8AOS/zl8sJJKfqf/OS/wA5fLCSSn6n/wA5L/OXywkkp//ZADhCSU0EIQAAAAAAXQAAAAEBAAAADwBBAGQAbwBiAGUAIABQAGgAbwB0AG8AcwBoAG8AcAAAABcAQQBkAG8AYgBlACAAUABoAG8AdABvAHMAaABvAHAAIABDAEMAIAAyADAAMQA1AAAAAQA4QklNBAYAAAAAAAcACAEBAAEBAP/hDjRodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMDY3IDc5LjE1Nzc0NywgMjAxNS8wMy8zMC0yMzo0MDo0MiAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczpkYz0iaHR0cDovL3B1cmwub3JnL2RjL2VsZW1lbnRzLzEuMS8iIHhtbG5zOnBob3Rvc2hvcD0iaHR0cDovL25zLmFkb2JlLmNvbS9waG90b3Nob3AvMS4wLyIgeG1sbnM6eG1wTU09Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9tbS8iIHhtbG5zOnN0RXZ0PSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvc1R5cGUvUmVzb3VyY2VFdmVudCMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTUgKE1hY2ludG9zaCkiIHhtcDpDcmVhdGVEYXRlPSIyMDE4LTA2LTI4VDE5OjUzOjAzKzA4OjAwIiB4bXA6TW9kaWZ5RGF0ZT0iMjAxOC0wNi0yOFQyMDowMDoxOSswODowMCIgeG1wOk1ldGFkYXRhRGF0ZT0iMjAxOC0wNi0yOFQyMDowMDoxOSswODowMCIgZGM6Zm9ybWF0PSJpbWFnZS9qcGVnIiBwaG90b3Nob3A6Q29sb3JNb2RlPSIzIiB4bXBNTTpJbnN0YW5jZUlEPSJ4bXAuaWlkOjM2ZDUyMDlmLTk0Y2EtNGM5Mi1iMTIyLTBmODg3MjQ5OTAzZSIgeG1wTU06RG9jdW1lbnRJRD0iYWRvYmU6ZG9jaWQ6cGhvdG9zaG9wOjMwYjIxN2FlLWJiNTktMTE3Yi05MTU2LWE1Y2QxNDQzZTdhYiIgeG1wTU06T3JpZ2luYWxEb2N1bWVudElEPSJ4bXAuZGlkOjkzYjIxMWM0LWJlYWItNGIxZi1iY2YwLTlmNjA5NTNmNjIxZiI+IDx4bXBNTTpIaXN0b3J5PiA8cmRmOlNlcT4gPHJkZjpsaSBzdEV2dDphY3Rpb249ImNyZWF0ZWQiIHN0RXZ0Omluc3RhbmNlSUQ9InhtcC5paWQ6OTNiMjExYzQtYmVhYi00YjFmLWJjZjAtOWY2MDk1M2Y2MjFmIiBzdEV2dDp3aGVuPSIyMDE4LTA2LTI4VDE5OjUzOjAzKzA4OjAwIiBzdEV2dDpzb2Z0d2FyZUFnZW50PSJBZG9iZSBQaG90b3Nob3AgQ0MgMjAxNSAoTWFjaW50b3NoKSIvPiA8cmRmOmxpIHN0RXZ0OmFjdGlvbj0iY29udmVydGVkIiBzdEV2dDpwYXJhbWV0ZXJzPSJmcm9tIGltYWdlL3BuZyB0byBpbWFnZS9qcGVnIi8+IDxyZGY6bGkgc3RFdnQ6YWN0aW9uPSJzYXZlZCIgc3RFdnQ6aW5zdGFuY2VJRD0ieG1wLmlpZDozNmQ1MjA5Zi05NGNhLTRjOTItYjEyMi0wZjg4NzI0OTkwM2UiIHN0RXZ0OndoZW49IjIwMTgtMDYtMjhUMjA6MDA6MTkrMDg6MDAiIHN0RXZ0OnNvZnR3YXJlQWdlbnQ9IkFkb2JlIFBob3Rvc2hvcCBDQyAyMDE1IChNYWNpbnRvc2gpIiBzdEV2dDpjaGFuZ2VkPSIvIi8+IDwvcmRmOlNlcT4gPC94bXBNTTpIaXN0b3J5PiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8P3hwYWNrZXQgZW5kPSJ3Ij8+/+4AIUFkb2JlAGRAAAAAAQMAEAMCAwYAAAAAAAAAAAAAAAD/2wCEAAEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQECAQEBAQEBAgICAgICAgICAgICAgIDAwMDAwMDAwMDAwMDAwMBAQEBAQEBAgEBAgMCAgIDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDA//CABEIABAF+gMBEQACEQEDEQH/xABmAAEBAQAAAAAAAAAAAAAAAAAABgoBAQAAAAAAAAAAAAAAAAAAAAAQAAMBAQAAAAAAAAAAAAAAAAACExWAEQACAwAAAAAAAAAAAAAAAAAAMqGxAhIBAAAAAAAAAAAAAAAAAAAAgP/aAAwDAQECEQMRAAAA30AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAkQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAf/9oACAECAAEFAOgP/9oACAEDAAEFAOgP/9oACAEBAAEFALqXUupdS6l1LqXUupdS6l1LqXUupdS6l1LqXUupdS6l1LqXUupdS6l1LqXUupdS6l1LqXUupdS6l1LqXUupdS6l1LqXUupdS6l1LqXUupdS6l1LqXUupdS6l1LqXUupdS6l1LqXUupdS6l1LqXUupdS6l1LqXUupdS6l1LqXUupdS6l1LqXUupdS6l1LqXUupdS6l1LqXUupdS6l1LqXUupdS6l1LqXUupdS6l1LqXUupdS6l1LqXUupdS6l1LqXUupdS6l1LqXUupdS6l1LqXUupdS6l1LqXUupdS6l1LqXUupdS6l1LqXUupdS6l1LqXUupdS6l1LqXUupdS6l1LqXUupdS6l1NVTVU1VNVTVU1VNVTVU1VNVTVU1VNVTVU1VNVTVU1VNVTVU1VNVTVU1VNVTVU1VNVTVU1VNVTVU1VNVTVU1VNVTVU1VNVTVU1VNVTVU1VNVTVU1VNVTVU1VNVTVU1VNVTVU1VNVTVU1VNVTVU1VNVTVU1VNVTVU1VNVTVU1VNVTVU1VNVTVU1VNVTVU1VNVTVU1VNVTVU1VNVTVU1VNVTVU1VNVTVU1VNVTVU1VNVTVU1VNVTVU1VNVTVU1VNVTVU1VNVTVU1VNVTVU1VNVTVU1VNVTVU1VNVTVU1VNVTVU1VNVTVU1VNVTVU1VNVTVU1VNVTVU1VNVTVU1VNVTVU1VNVTVU1VNVTVU1VNVTVU1VNVTVU1VNVTVU1VNVTVU1VNVTVU1VNVTVU1VNVTVU1VNVTVU1VNVTVU1VNVTVU1VNVTVU1VNVTVU1VNVTVU1VP/aAAgBAgIGPwBAf//aAAgBAwIGPwBAf//aAAgBAQEGPwBsyNmRsyNmRsyNmRsyNmRsyNmRsyNmRsyNmRsyNmRsyNmRsyNmRsyNmRsyNmRsyNmRsyNmRsyNmRsyNmRsyNmRsyNmRsyNmRsyNmRsyNmRsyNmRsyNmRsyNmRsyNmRsyNmRsyNmRsyNmRsyNmRsyNmRsyNmRsyNmRsyNmRsyNmRsyNmRsyNmRsyNmRsyNmRsyNmRsyNmRsyNmRsyNmRsyNmRsyNmRsyNmRsyNmRsyNmRsyNmRsyNmRsyNmRsyNmRsyNmRsyNmRsyNmRsyNmRsyNmRsyNmRsyNmRsyNmRsyNmRsyNmRsyNmRsyNmRsyNmRsyNmRsyNmRsyNmRsyNmRsyNmRsyNmRsyNmRsyNmRsyNmRsyNmRsyNmRsyNmRsyNmRsyNmRsyNmRsyNmRsyNmRsyNmRsyNmRsyNmRsyNmRsyNmRsyNmRsyNmRsyNmRsyNmRsyNmRsyNmRsyNmRsyNmRsyNmRsyNmR7Hsex7Hsex7Hsex7Hsex7Hsex7Hsex7Hsex7Hsex7Hsex7Hsex7Hsex7Hsex7Hsex7Hsex7Hsex7Hsex7Hsex7Hsex7Hsex7Hsex7Hsex7Hsex7Hsex7Hsex7Hsex7Hsex7Hsex7Hsex7Hsex7Hsex7Hsex7Hsex7Hsex7Hsex7Hsex7Hsex7Hsex7Hsex7Hsex7Hsex7Hsex7Hsex7Hsex7Hsex7Hsex7Hsex7Hsex7Hsex7Hsex7Hsex7Hsex7Hsex7Hsex7Hsex7Hsex7Hsex7Hsex7Hsex7Hsex7Hsex7Hsex7Hsex7Hsex7Hsez/2Q==" class="wgt-best-operator-shadow">
<div id="wgt-eva-2383726729" class="wgt-eva ">
<span
        alog-action="qb-zan-btnbestbox"
        class="evaluate evaluate-32  evaluate-good-2 "
        id="evaluate-2383726729"
        data-evaluate="2">
<i class="ikonw-qb-new-icon icon-evaluate "></i>
<b class="evaluate-num"></b>
</span>
<span class="wgt-eva-pipe"></span>
<span
        alog-action="qb-evaluate-outer"
        class="evaluate-bad evaluate-32 "
        id="evaluate-bad-2383726729"
        data-evaluate="7">
<i class="ikonw-qb-new-icon icon-evaluate-bad "></i>
<b class="evaluate-num"></b>
</span>
<span class="wgt-eva-hasgood"><i class="ikonw-qb-new-icon icon-evaluated"></i><b class="evaluate-text">已赞过</b></span>
<span class="wgt-eva-hasbad"><i class="ikonw-qb-new-icon icon-evaluated-bad"></i><b class="evaluate-text">已踩过</b><</span>
<div class="eva_tooltip">
<div class="eva_tooltip_arrow">
<div class="eva_tooltip_arrow_inner"></div>
</div>
<div class="eva_tooltip_context">
你对这个回答的评价是？</div>
</div>
</div>
<span alog-action="qb-comment-btnbestbox" class="comment " id="comment-2383726729"><i class="ikonw-qb-new-icon qb-comment-icon"></i>评论</span>
<ins class="share-area"></ins>
<ins class="accuse-area" alog-alias="qb-accuse-link-best" data-rid="2383726729"></ins>
<span class="wgt-best-hidebtn">收起<i class="wgt-best-arrowup"></i></span>
</div>
</div>
</div>
</div>
</div><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAABXgAAAAGCAMAAABOxQYTAAAABGdBTUEAALGPC/xhBQAAAAFzUkdCAK7OHOkAAAMAUExURQAAANvh5f///////9rh5dvh5P///9vh5drh5Nrh5P///9rg5drg5dvg5dzg6N3h5Nrh5dzh5N///9rh5dv//93j5t7i5tvk5Nvh5Nzg5ePj/93g59vh5d3j59vg5ubm5t7i5trg5ujo6Orq6tvh5Nvi5tvh5dzi5Nvg5tvi5tvg5dvh5dzk59vi5drh5trh5dvh5Nzh5t7j59zg5Nvi5dzh5tvh5tzi5Nzi5trh5N3i59vj59vg5Nvh59zj59vg5tvg5evr69vh5d3u7tvi5tvi5eDg6////9vl5dzg5dvi5dvi5Nvg5P///9vh5Nrh5drj5tvh5dvh5t7j6dvh5Nzj6tzh5dvj59vg5tvg5dvh5dri5d3i5tvh5drh5Nzi5dvh5Nzg5dzh59/v79zi5Nzh5tzl5drh5dvg5dvg5Nvg5Nvh5Nrh5Nzj5tvi5trg5d3h5tzh5dvk6Nvg5tri5Nrg5tzi5uHh8Nvi5Nrh5N3j6Nri5tvh5d3h5dvh5dvg5tvg5drh5Nrh5Nrh5dvk7d/q6tzi5dzh5t/n5+Tk5ODm5tvn59vg5dvh5Nrh5dzj5trh5eDg6Nvh5dvh59/m5tvg5dvh5dvg5drg5Nrg5d/k5Nzh5Nrh5dzh5dvh5tzg5dvh5drg5N3j6tvg5dvh5drg5N/j6Nvh5dvh5drh5Nvh5d7p6dzi6OLi69vg5Obm5trg5OHh6dvh5dvh5trh5trg5dvh5Nrh5Nvh5dzh5trg5N3k5Nvh5trh5dvh5dvh5dvi5dvh5N7k6drg5Nrh5drh5dvh5Nvg5Nrg5dvg5dvi5d3i5dvi5drg5dvh5Nvh5ePj7Nvh5dvg5dvh5dri5d3m5tvh5Nvh5Nrh5dvt7dvh5dvg5dvg5dvh5drh5Nrh5dvg5Nvh5Nvg5dvi6d7m5tzo6Nvh59vg5dvg5N7l5dvh5dvh5dvg5OPj8dvg5dvh5Nvg5Nrg5dvg5Nvg5dvh5Nvh5drh5drg5drh5dvh5Nvh5drg5Nzh5tvh5drg5Nrg5Jmd+oAAAAD/dFJOUwDiBAP04wH15eQC3/LhQkPzkAjeB1I9Oe46CUt3SowUPlMLDNtHf3MyRuCIQU9vklZmNnxObnh7gt01P4VUSZaVDYAPcZQZBjF1amnvBdpFWtV5LoYkbUCN2YGLNE1MV49sXhBgZx2Ka/COVZhRetY8OzhbaIRQEXKZLYPFRIdkY8ntkRwYWJcgEykVztJ2SJ8hpCoo583xrdcwX+uJcHR+fSXGsbU3sNS0mxcsGr4KyCK5XaDY3OapM9EmXMKozJOsL9C8waHAp+piWZzP07obxKWaYR69o+wOuJ63y8q7v6rpIx8WK6/HJ7OythKdq/im9+j2/MOu+6L++mX9+QBSHAEAAAkNSURBVGje7ZhlVFfZAsV/5tioCCZ2ISq2WCgmiIkIFioWCraIInZht44J2J3Y3d3d3TmOjo4675054XXE53qzXLPWe1/+58P+4EK5e3nP3r99wXZsx3Zsx3Zsx3Zs50dO4mRKEyRQGj+++oPaNZSmS6c0bVqlmTJJTZYzp9JcuZR6eKi/VKVKYqmtWyvt1Utq/BcjlWbLpnT0aPlP136wXOmwYVJrVK8uf02Nlaelphs6VGm7dvJXpr1wX+mIEVIzTZxYW+rae1JXN2woHyXnvHlKt22TD5RryhSlo0bJx/KYPFnpwxXy4a706SO1SoMGq6XunSm1taenfNxe+fPLx32xpZnUkWXLyofOVqzYFamLuksdnT59FXiQMWNrWN6tay8Y5ugotXr27C+klis3ElYWLJgNTqdKJXWond1oaNev7gO44Oy8HO7nyTMMRox3rw4TnZxWwtrMmU/DveYBQ6FhiRLtYF6hQlK3hXW6AE8cHO7DlBw5RsCoCiETYXKRImvhYYsW92DF8OENoU+9evOgQY8e22Dv9u1PYGarVlPAc9asUZC/TZvJsOX80YfQbODAFVB2wIA+UOyPog1gUdu2e6F7aOhMSO9d0xMytm+fH7oGBm4BR7+SzSB74cJloVxUVDHwr9p7ERTMl687pIqOTg92Xl4ZoV+WLN2gbqlSXcHZx8cR8nQunR3cixcvB05z5/pD5pi8BaF55cqpIKBJEzso5BbRD8J69qwLncqXdwYH3/55IIeLy3ioMGeOE4QENc0MRbJmbQ4tGjUKgOHBwSXgWJo0haDekCFhsN3VtRPE7q7mAK0qVcoBsypWrADnIzuGwNHwcIoqs+nbhkqzGb29pdluNZVZx/aB0mx2Pz9ptlxJZdZfm01Vtao0a9dbme2nzTpHe0mzecaNk2bHa7PupXykWafOnaXZ5qVLS5sBxZXNEjEx0mZY3rzSZqfKyqaDm5u0WSEiQtoM6alsFvH1lTZb9O8vbR5zcXGXRoKCpNkeTZXZ7dpsbKNgaXZWy5bSbBtt9vwQZXPg7t3S5oBq1aTNPyopm0UjI6XN0I4di4B3+LkWUHPZsuHQ/vjxY+D38lo9KDlhQg8ovH59LEQdPNgKql66NAt6T5rUBqLPnj0PXocPH4VxO3cOhCybNw+AUndeFYXOe/a0hdLTp4dC8fePvGHu4sU1Ie+CBe2h8rOngdBk6dKS4LZwYWGIeH49CspfvVoVfNet6w0up27lgzn793tB0MWL4yDrqlVZoNGhQ6Ug+MABH2i5Y0dnSPPuTHEY0rfvXHCdPz8Gdj9ekxcqDRpUGSrevOkGkTd2RUDHadN6wrkxY8rDshP7fOHl1q0ucG3s2Dkw4eSSIFhfv35TONilSyP4MGNGMExq3LglnK1TJw28zp3bFQ5vLLMbNtvbV4M7yZNXglcFUlaE6fHidYT3iRKFw6OkSc7Bgk2bjsOzqVNfwtM3d6/B0iNHJsDz2bMPwvXLgz/A1QwZLsGpWrUmwa0OHV7D/hQpDsOq1Kl3wu2ECe/AobdvX8GOX3/dA+9++WU69P33p0cw//ffF8Pj335bAGv+9fEpDBJiKdwQYiHsEuI6TBPiKowRYh2cEOIU7BNiP2wV4iKcFGIVLBHiNtQX4hB0EeIAzBDiHWwQ4gw0FqIv1BFiPuQW4rHWNbBRiEFQRoibYC/EDUguxC4ooDWlENMgnhBjIJEQJ7Tug6RCbIUkQoy1dJMQJ2GqEEu01oc3Wu8K0UXrDDiidbYQGyy9LERjrXVgsKW5Lc0gxMavtIyltSy1t7SDEMnj6s+WFoirKSxNGVdTWxovrib8niay9Ke/06T/WJP8bzXh9zTpDyo/8sNJ/k5/+n/oP/kv+y+vRMK4+s2rlfp7mvJ7r2uKr17mb17y5P9xHezjXpZaX12lb65Y7q8u4Jcr+eWSNo57eY9Yl7qLdc3Nlf8SAkusWNhkBYUJDRMg+6xIMfFiosbETnIdRPZWKJmAMmFlgmu+jrK+OtbO6Ih7p+NuhxV9JgZNJJp4HKsDU8bmLStCTZxO0wErY/a5Fbkmftd8/PjMimUT0X0/fXoPZ3R0mxg/8PbtHR3vm62ov6hj/9bPHc5adbBOV8P1wZcP6spYDwt1fTy9++aarpXjumKWweIkqm5M9cgaioQ9KVUlmXoyVbWzTBlXXWFDrDoz1fZhw4xGuvKyWvU3YcnJIF2LLroi+8u63HfC16rOcF2jkbtuuOl6bWJVbbU1qnZNBcs6lqWc5syZ0lZNm8o29Z31tqryphcveumKj5Z1f+uUrPv+uvoNBvS8/rywxoOSGhX8JDY8fRZoIUSMxonijxRaSMxoq5FDgofPq1d/SAjRKGKwxCBK9GuFK/k0ukiMkTAT9eFgrMab7Rbq+F17KbEnUCOQwSHvc+EtLExqGxmpwKmiYkWJUg4aqyRcHXV1DbNwy6BXq2CFYbEayQyeGVQ7Nkdh23CNcAbnQsorjpWYJ2Evh5ubAr8minUlCkogLBQTI+EwYK7iYYmLko0za3R091HMbJDS4KWzl0LNuho7DYIaHC0YpdDUX2OqQVbHQM3qGmW7aaxNH6p5vmhRwsOlzfMdFQC30TBswDhWmzXA3EPDcz1tdnhLBdUSsJtr2JY2Q5oqmxLC3S0gd+ivbBpQN9BeKEKRbQkN8wbsM2uzBvgN/I/XZs0oMAPBjAW7cWo4mBFhBoV/76qLrKFhRodjSb9m1hjppodJxprensqmGizd9XgpptnejBozcLYcVWPHDJ/8egR56kG0N1aNIzOUzGhacUwNKDOmzLAaFVJhojW4zPja1insgjXK5EBTMy0g4LQebmq+OTmpKeeuBt0IPe7M0GtXV40+MwDNGJTDUM1DfzUSzWA043F5126trVFpBma27ouu6OHpYY3QF83UIJXjNKc1VKvMVKPVDFgzZj1WqGFrRq4ZvGb85nyihrAZxWYgZ7q3trY1nM2ITnv/QnxrXJuhXeP0ygTWADdjvPZyNczNSP882EeO/DLkP496PfCTXfH4a/jrjwCJV2f66+OA+VBQo/aXDwifPyYkS2z7uGI7tmM7tmM7tmM7P3T+BKwSUZupONeyAAAAAElFTkSuQmCC" class="bottom-dashed-line" style="margin-top: -10px;">
<script>
                    // 高质or满意or特型or推荐答案打点时间
                    alog && alog('speed.set', 'c_best', +new Date); alog.fire && alog.fire("mark");
                </script>
<script>
                    // 首屏时间打点
                    void function(e,t){for(var n=t.getElementsByTagName("img"),a=+new Date,i=[],o=function(){this.removeEventListener&&this.removeEventListener("load",o,!1),i.push({img:this,time:+new Date})},s=0;s< n.length;s++)!function(){var e=n[s];e.addEventListener?!e.complete&&e.addEventListener("load",o,!1):e.attachEvent&&e.attachEvent("onreadystatechange",function(){"complete"==e.readyState&&o.call(e,o)})}();alog("speed.set",{fsItems:i,fs:a})}(window,document);
                </script>
<table id="qbleftdown-container" class="mod-shadow mod-merger-push last wgt-asp-top"><tr><td>
<i class="iknow-qb_home_icons ad-leftdown-icon"></i>
<style>
                            .ec-ui-tip{margin-left:5px}.c-icon{background:url(https://ss1.bdstatic.com/5eN1bjq8AAUYm2zgoY3K/r/www/cache/biz/ecom/common/api/img/ns-credit/icons.png) no-repeat 0 0;_background-image:url(https://ss1.bdstatic.com/5eN1bjq8AAUYm2zgoY3K/r/www/cache/biz/ecom/common/api/img/ns-credit/icons.gif)}.c-frame{margin-bottom:18px}.c-offset{padding-left:10px}.c-gray{color:#666}.c-gap-top-small{margin-top:5px}.c-gap-top{margin-top:10px}.c-gap-bottom-small{margin-bottom:5px}.c-gap-bottom{margin-bottom:10px}.c-gap-left{margin-left:12px}.c-gap-left-small{margin-left:6px}.c-gap-right{margin-right:12px}.c-gap-right-small{margin-right:6px}.c-gap-icon-right-small{margin-right:5px}.c-gap-icon-right{margin-right:10px}.c-gap-icon-left-small{margin-left:5px}.c-gap-icon-left{margin-left:10px}.c-container{width:538px;font-size:13px;line-height:1.54;word-wrap:break-word;word-break:break-all}.c-container .c-container{width:auto}.c-container table{border-collapse:collapse;border-spacing:0}.c-container td{font-size:13px;line-height:1.54}.c-default{font-size:13px;line-height:1.54;word-wrap:break-word;word-break:break-all}.c-container .t,.c-default .t{line-height:1.54}.c-default .t{margin-bottom:0}.cr-content{width:259px;font-size:13px;line-height:1.54;color:#333}.cr-content table{border-collapse:collapse;border-spacing:0}.cr-content td{font-size:13px;line-height:1.54;vertical-align:top}.cr-offset{padding-left:17px}.container_l .cr-content{width:351px}.container_l .cr-content-narrow{width:259px}.cr-title{font-size:14px;line-height:1.29;font-weight:700}.cr-title-sub{float:right;font-size:13px;font-weight:400}.c-row{*zoom:1}.c-row:after{display:block;height:0;content:"";clear:both;visibility:hidden}.c-span2{width:29px}.c-span3{width:52px}.c-span4{width:75px}.c-span5{width:98px}.c-span6{width:121px}.c-span7{width:144px}.c-span8{width:167px}.c-span9{width:190px}.c-span10{width:213px}.c-span11{width:236px}.c-span12{width:259px}.c-span13{width:282px}.c-span14{width:305px}.c-span15{width:328px}.c-span16{width:351px}.c-span17{width:374px}.c-span18{width:397px}.c-span19{width:420px}.c-span20{width:443px}.c-span21{width:466px}.c-span22{width:489px}.c-span23{width:512px}.c-span24{width:535px}.c-span2,.c-span3,.c-span4,.c-span5,.c-span6,.c-span7,.c-span8,.c-span9,.c-span10,.c-span11,.c-span12,.c-span13,.c-span14,.c-span15,.c-span16,.c-span17,.c-span18,.c-span19,.c-span20,.c-span21,.c-span22,.c-span23,.c-span24{float:left;_display:inline;margin-right:17px;list-style:none}.c-span-last{margin-right:0}.c-span-last-s{margin-right:0}.container_l .c-span-last-s{margin-right:17px}.cr-content-narrow .c-span-last-s{margin-right:0}.c-border{width:518px;padding:9px;border:1px solid #e3e3e3;border-bottom-color:#e0e0e0;border-right-color:#ececec;box-shadow:1px 2px 1px rgba(0,0,0,.072);-webkit-box-shadow:1px 2px 1px rgba(0,0,0,.072);-moz-box-shadow:1px 2px 1px rgba(0,0,0,.072);-o-box-shadow:1px 2px 1px rgba(0,0,0,.072)}.c-border .c-gap-left{margin-left:10px}.c-border .c-gap-left-small{margin-left:5px}.c-border .c-gap-right{margin-right:10px}.c-border .c-gap-right-small{margin-right:5px}.c-border .c-border{width:auto;padding:0;border:0;box-shadow:none;-webkit-box-shadow:none;-moz-box-shadow:none;-o-box-shadow:none}.c-border .c-span2{width:34px}.c-border .c-span3{width:56px}.c-border .c-span4{width:78px}.c-border .c-span5{width:100px}.c-border .c-span6{width:122px}.c-border .c-span7{width:144px}.c-border .c-span8{width:166px}.c-border .c-span9{width:188px}.c-border .c-span10{width:210px}.c-border .c-span11{width:232px}.c-border .c-span12{width:254px}.c-border .c-span13{width:276px}.c-border .c-span14{width:298px}.c-border .c-span15{width:320px}.c-border .c-span16{width:342px}.c-border .c-span17{width:364px}.c-border .c-span18{width:386px}.c-border .c-span19{width:408px}.c-border .c-span20{width:430px}.c-border .c-span21{width:452px}.c-border .c-span22{width:474px}.c-border .c-span23{width:496px}.c-border .c-span24{width:518px}.c-border .c-span2,.c-border .c-span3,.c-border .c-span4,.c-border .c-span5,.c-border .c-span6,.c-border .c-span7,.c-border .c-span8,.c-border .c-span9,.c-border .c-span10,.c-border .c-span11,.c-border .c-span12,.c-border .c-span13,.c-border .c-span14,.c-border .c-span15,.c-border .c-span16,.c-border .c-span17,.c-border .c-span18,.c-border .c-span19,.c-border .c-span20,.c-border .c-span21,.c-border .c-span22,.c-border .c-span23,.c-border .c-span24{margin-right:10px}.c-border .c-span-last{margin-right:0}.c-border .c-span-last-s{margin-right:0}.c-border .container_l .c-span-last-s{margin-right:10px}.c-loading{display:block;width:50px;height:50px;background:url(http://www.baidu.com/aladdin/img/tools/loading.gif) no-repeat 0 0}.c-vline{display:inline-block;margin:0 3px;border-left:1px solid #ddd;width:0;height:12px;_vertical-align:middle;_overflow:hidden}.c-icon{display:inline-block;width:14px;height:14px;vertical-align:text-bottom;font-style:normal;overflow:hidden}.c-icon-unfold,.c-icon-fold,.c-icon-chevron-unfold,.c-icon-chevron-fold{width:12px;height:12px}.c-icon-star,.c-icon-star-gray{width:60px}.c-icon-qa-empty,.c-icon-safeguard,.c-icon-register-empty,.c-icon-zan,.c-icon-location,.c-icon-warning,.c-icon-doc,.c-icon-xls,.c-icon-ppt,.c-icon-pdf,.c-icon-txt,.c-icon-play-black,.c-icon-gift,.c-icon-baidu-share,.c-icon-bear,.c-icon-sfda,.c-icon-bear-border,.c-icon-location-blue,.c-icon-hotAirBall,.c-icon-moon,.c-icon-streetMap,.c-icon-mv{width:16px;height:16px}.c-icon-bear-circle,.c-icon-warning-circle,.c-icon-warning-triangle{width:18px;height:18px}.c-icon-tieba,.c-icon-zhidao,.c-icon-bear-p,.c-icon-bear-pn{width:24px;height:24px}.c-icon-ball-blue,.c-icon-ball-red{width:38px;height:38px}.c-icon-unfold:hover,.c-icon-fold:hover,.c-icon-chevron-unfold:hover,.c-icon-chevron-fold:hover,.c-icon-download:hover,.c-icon-lyric:hover,.c-icon-v:hover,.c-icon-hui:hover,.c-icon-bao:hover,.c-icon-person:hover,.c-icon-high-v:hover,.c-icon-phone:hover,.c-icon-nuo:hover,.c-icon-med:hover,.c-icon-air:hover,.c-icon-share2:hover,.c-icon-v1:hover,.c-icon-v2:hover,.c-icon-v3:hover{border-color:#388bff}.c-icon-unfold:active,.c-icon-fold:active,.c-icon-chevron-unfold:active,.c-icon-chevron-fold:active,.c-icon-download:active,.c-icon-lyric:active,.c-icon-v:active,.c-icon-hui:active,.c-icon-bao:active,.c-icon-person:active,.c-icon-high-v:active,.c-icon-phone:active,.c-icon-nuo:active,.c-icon-med:active,.c-icon-air:active,.c-icon-share2:active,.c-icon-v1:active,.c-icon-v2:active,.c-icon-v3:active{border-color:#a2a6ab;background-color:#f0f0f0;box-shadow:inset 1px 1px 1px #c7c7c7;-webkit-box-shadow:inset 1px 1px 1px #c7c7c7;-moz-box-shadow:inset 1px 1px 1px #c7c7c7;-o-box-shadow:inset 1px 1px 1px #c7c7c7}.c-icon-unfold,.c-icon-fold,.c-icon-chevron-unfold,.c-icon-chevron-fold,.c-icon-download,.c-icon-lyric{border:1px solid #d8d8d8;cursor:pointer}.c-icon-v,.c-icon-hui,.c-icon-bao,.c-icon-person,.c-icon-high-v,.c-icon-phone,.c-icon-nuo,.c-icon-med,.c-icon-air,.c-icon-share2,.c-icon-v1,.c-icon-v2,.c-icon-v3{border:1px solid #d8d8d8;cursor:pointer;border-color:transparent;_border-color:tomato;_filter:chroma(color=#ff6347)}.c-icon-v1,.c-icon-v2,.c-icon-v3,.c-icon-v1-noborder,.c-icon-v2-noborder,.c-icon-v3-noborder,.c-icon-v1-noborder-disable,.c-icon-v2-noborder-disable,.c-icon-v3-noborder-disable{width:19px}.c-icon-download,.c-icon-lyric{width:16px;height:16px}.c-icon-play-circle,.c-icon-stop-circle{width:18px;height:18px}.c-icon-play-circle-middle,.c-icon-stop-circle-middle{width:24px;height:24px}.c-icon-play-black-large,.c-icon-stop-black-large{width:38px;height:38px}.c-icon-flag{background-position:0 -144px}.c-icon-bus{background-position:-24px -144px}.c-icon-calendar{background-position:-48px -144px}.c-icon-street{background-position:-72px -144px}.c-icon-map{background-position:-96px -144px}.c-icon-bag{background-position:-120px -144px}.c-icon-money{background-position:-144px -144px}.c-icon-game{background-position:-168px -144px}.c-icon-user{background-position:-192px -144px}.c-icon-globe{background-position:-216px -144px}.c-icon-lock{background-position:-240px -144px}.c-icon-plane{background-position:-264px -144px}.c-icon-list{background-position:-288px -144px}.c-icon-star-gray{background-position:-312px -144px}.c-icon-circle-gray{background-position:-384px -144px}.c-icon-triangle-down{background-position:-408px -144px}.c-icon-triangle-up{background-position:-432px -144px}.c-icon-triangle-up-empty{background-position:-456px -144px}.c-icon-sort-gray{background-position:-480px -144px}.c-icon-sort-up{background-position:-504px -144px}.c-icon-sort-down{background-position:-528px -144px}.c-icon-down-gray{background-position:-552px -144px}.c-icon-up-gray{background-position:-576px -144px}.c-icon-download-noborder{background-position:-600px -144px}.c-icon-lyric-noborder{background-position:-624px -144px}.c-icon-download-white{background-position:-648px -144px}.c-icon-close{background-position:-672px -144px}.c-icon-fail{background-position:-696px -144px}.c-icon-success{background-position:-720px -144px}.c-icon-triangle-down-g{background-position:-744px -144px}.c-icon-fullscreen{background-position:0 -168px}.c-icon-safe{background-position:-24px -168px}.c-icon-exchange{background-position:-48px -168px}.c-icon-chevron-bottom{background-position:-72px -168px}.c-icon-chevron-top{background-position:-96px -168px}.c-icon-unfold{background-position:-120px -168px}.c-icon-fold{background-position:-144px -168px}.c-icon-chevron-unfold{background-position:-168px -168px}.c-icon-qa{background-position:-192px -168px}.c-icon-register{background-position:-216px -168px}.c-icon-star{background-position:-240px -168px}.c-icon-star-gray{position:relative}.c-icon-star-gray .c-icon-star{position:absolute;top:0;left:0}.c-icon-play-blue{background-position:-312px -168px}.c-icon-pic{width:16px;background-position:-336px -168px}.c-icon-chevron-fold{background-position:-360px -168px}.c-icon-video{width:18px;background-position:-384px -168px}.c-icon-circle-blue{background-position:-408px -168px}.c-icon-circle-yellow{background-position:-432px -168px}.c-icon-play-white{background-position:-456px -168px}.c-icon-triangle-down-blue{background-position:-480px -168px}.c-icon-chevron-unfold2{background-position:-504px -168px}.c-icon-right{background-position:-528px -168px}.c-icon-right-empty{background-position:-552px -168px}.c-icon-new-corner{width:15px;background-position:-576px -168px}.c-icon-horn{background-position:-600px -168px}.c-icon-right-large{width:18px;background-position:-624px -168px}.c-icon-wrong-large{background-position:-648px -168px}.c-icon-circle-blue-s{background-position:-672px -168px}.c-icon-play-gray{background-position:-696px -168px}.c-icon-up{background-position:-720px -168px}.c-icon-down{background-position:-744px -168px}.c-icon-stable{background-position:-768px -168px}.c-icon-calendar-blue{background-position:-792px -168px}.c-icon-triangle-down-blue2{background-position:-816px -168px}.c-icon-triangle-up-blue2{background-position:-840px -168px}.c-icon-down-blue{background-position:-864px -168px}.c-icon-up-blue{background-position:-888px -168px}.c-icon-ting{background-position:-912px -168px}.c-icon-v,.c-icon-v-noborder{background-position:0 -192px}.c-icon-hui{background-position:-24px -192px}.c-icon-bao{background-position:-48px -192px}.c-icon-phone{background-position:-72px -192px}.c-icon-qa-empty{background-position:-96px -192px}.c-icon-safeguard{background-position:-120px -192px}.c-icon-register-empty{background-position:-144px -192px}.c-icon-zan{background-position:-168px -192px}.c-icon-location{background-position:-240px -192px}.c-icon-warning{background-position:-264px -192px}.c-icon-doc{background-position:-288px -192px}.c-icon-xls{background-position:-312px -192px}.c-icon-ppt{background-position:-336px -192px}.c-icon-pdf{background-position:-360px -192px}.c-icon-txt{background-position:-384px -192px}.c-icon-play-black{background-position:-408px -192px}.c-icon-play-black:hover{background-position:-432px -192px}.c-icon-gift{background-position:-456px -192px}.c-icon-baidu-share{background-position:-480px -192px}.c-icon-bear{background-position:-504px -192px}.c-icon-sfda{width:31px;background-position:-528px -192px}.c-icon-bear-border{background-position:-576px -192px}.c-icon-person,.c-icon-person-noborder{background-position:-600px -192px}.c-icon-location-blue{background-position:-624px -192px}.c-icon-hotAirBall{background-position:-648px -192px}.c-icon-moon{background-position:-672px -192px}.c-icon-streetMap{background-position:-696px -192px}.c-icon-high-v,.c-icon-high-v-noborder{background-position:-720px -192px}.c-icon-nuo{background-position:-744px -192px}.c-icon-mv{background-position:-768px -192px}.c-icon-med{background-position:-816px -192px}.c-icon-air{background-position:-840px -192px}.c-icon-share2{background-position:-864px -192px}.c-icon-v1,.c-icon-v1-noborder{background-position:-888px -192px}.c-icon-v2,.c-icon-v2-noborder{background-position:-912px -192px}.c-icon-v3,.c-icon-v3-noborder{background-position:-936px -192px}.c-icon-v1-noborder-disable{background-position:-960px -192px}.c-icon-v2-noborder-disable{background-position:-984px -192px}.c-icon-v3-noborder-disable{background-position:-1008px -192px}.c-icon-bear-circle{background-position:0 -216px}.c-icon-warning-circle{background-position:-24px -216px}.c-icon-warning-triangle{width:24px;background-position:-48px -216px}.c-icon-ball-red{background-position:0 -240px}.c-icon-ball-blue{background-position:-48px -240px}.c-icon-tieba{background-position:0 -288px}.c-icon-zhidao{background-position:-48px -288px}.c-icon-bear-p{background-position:-96px -288px}.c-icon-bear-pn{background-position:-144px -288px}.c-icon-download{background-position:0 -336px}.c-icon-lyric{background-position:-24px -336px}.c-icon-play-circle{background-position:-48px -336px}.c-icon-play-circle:hover{background-position:-72px -336px}.c-icon-stop-circle{background-position:-96px -336px}.c-icon-stop-circle:hover{background-position:-120px -336px}.c-icon-play-circle-middle{background-position:0 -360px}.c-icon-play-circle-middle:hover{background-position:-48px -360px}.c-icon-stop-circle-middle{background-position:-96px -360px}.c-icon-stop-circle-middle:hover{background-position:-144px -360px}.c-icon-play-black-large{background-position:0 -408px}.c-icon-play-black-large:hover{background-position:-48px -408px}.c-icon-stop-black-large{background-position:-96px -408px}.c-icon-stop-black-large:hover{background-position:-144px -408px}.c-text{display:inline-block;padding:2px;text-align:center;vertical-align:text-bottom;font-size:12px;line-height:100%;font-style:normal;color:#fff;overflow:hidden}a.c-text{text-decoration:none}.c-text-new{background-color:#f13f40}.c-text-info{padding-left:0;padding-right:0;font-weight:700;color:#2b99ff;*vertical-align:baseline;_position:relative;_top:2px}.c-text-info b{_position:relative;_top:-1px}.c-text-info span{padding:0 2px;font-weight:400}.c-text-important{background-color:#1cb7fd}.c-text-public{background-color:#2b99ff}.c-text-warning{background-color:#ff830f}.c-text-prompt{background-color:#f5c537}.c-text-danger{background-color:#f13f40}.c-text-safe{background-color:#52c277}.c-text-empty{padding-top:1px;padding-bottom:1px;border:1px solid #d8d8d8;cursor:pointer;color:#23b9fd;background-color:#fff}.c-text-empty:hover{border-color:#388bff}.c-text-empty:active{border-color:#a2a6ab;background-color:#f0f0f0;box-shadow:inset 1px 1px 1px #c7c7c7;-webkit-box-shadow:inset 1px 1px 1px #c7c7c7;-moz-box-shadow:inset 1px 1px 1px #c7c7c7;-o-box-shadow:inset 1px 1px 1px #c7c7c7}.c-text-mult{padding-left:5px;padding-right:5px}.c-container .vd_newest_main{width:auto}.c-customicon{display:inline-block;width:16px;height:16px;vertical-align:text-bottom;font-style:normal;overflow:hidden}.c-tip-icon i{display:inline-block;cursor:pointer}.c-tip-con{position:absolute;z-index:1;top:22px;left:-35px;background:#fff;border:1px solid #dcdcdc;border:1px solid rgba(0,0,0,.2);-webkit-transition:opacity .218s;transition:opacity .218s;-webkit-box-shadow:0 2px 4px rgba(0,0,0,.2);box-shadow:0 2px 4px rgba(0,0,0,.2);padding:5px 0;display:none;font-size:12px;line-height:20px;text-align:left}.c-tip-arrow{width:0;height:0;font-size:0;line-height:0;display:block;position:absolute;top:-16px}.c-tip-arrow em,.c-tip-arrow ins{width:0;height:0;font-size:0;line-height:0;display:block;position:absolute;border:8px solid #000;border-style:dashed dashed solid}.c-tip-arrow em{border-color:transparent transparent #d8d8d8}.c-tip-arrow ins{border-color:transparent transparent #fff;top:2px}.c-tip-con h3{font-size:12px}.c-tip-con .c-tip-title{margin:0 10px;display:inline-block;width:239px}.c-tip-con .c-tip-info{color:#666;margin:0 10px 1px;width:239px}.c-tip-con .c-tip-cer{width:354px;color:#666;margin:0 10px 1px}.c-tip-con .c-tip-cer ul{margin:0;padding:0;list-style:none}.c-tip-con .c-tip-title{width:auto;_width:354px}.c-tip-con .c-tip-item-i{padding:3px 0 3px 20px;line-height:14px}.c-tip-con .c-tip-item-i .c-tip-item-icon{margin-left:-20px}.c-tip-con .c-tip-menu ul{width:74px}.c-tip-con .c-tip-menu ul{text-align:center}.c-tip-con .c-tip-menu li a{display:block;text-decoration:none;cursor:pointer;background-color:#fff;padding:3px 0;color:#0000d0}.c-tip-con .c-tip-menu li a:hover{display:block;background-color:#ebebeb}.c-tip-con .c-tip-notice{width:239px;padding:0 10px}.c-tip-con .c-tip-notice .c-tip-notice-succ{color:#4cbd37}.c-tip-con .c-tip-notice .c-tip-notice-fail{color:#f13f40}.c-tip-con .c-tip-notice .c-tip-item-succ{color:#444}.c-tip-con .c-tip-notice .c-tip-item-fail{color:#aaa}.c-tip-con .c-tip-notice .c-tip-item-faila{color:#aaa}.c-tip-close{right:10px;position:absolute;cursor:pointer}.c-tools{display:inline}.c-tools-share{width:239px;padding:0 10px}.icp_info{color:#666;margin-top:2px;font-size:13px}.icon-gw,.icon-unsafe-icon{background:#2c99ff;vertical-align:text-bottom;*vertical-align:baseline;height:16px;padding-top:0;padding-bottom:0;padding-left:6px;padding-right:6px;line-height:16px;_padding-top:2px;_height:14px;_line-height:14px;font-size:12px;font-family:simsun;margin-left:10px;overflow:hidden;display:inline-block;-moz-border-radius:1px;-webkit-border-radius:1px;border-radius:1px;color:#fff}a.icon-gw{color:#fff;background:#2196ff;text-decoration:none;cursor:pointer}a.icon-gw:hover{background:#1e87ef}a.icon-gw:active{height:15px;_height:13px;line-height:15px;_line-height:13px;padding-left:5px;background:#1c80d9;border-left:1px solid #145997;border-top:1px solid #145997}.icon-unsafe-icon{background:#e54d4b}#con-at{margin-bottom:15px}#con-ar{margin-bottom:40px}#con-at .result-op{margin-bottom:15px;font-size:13px;line-height:1.52em}#con-ar .result-op{margin-bottom:28px;font-size:13px;line-height:1.52em}#content_left .result-op,#content_left .result{margin-bottom:14px;border-collapse:collapse}#content_left .c-border .result-op,#content_left .c-border .result{margin-bottom:25px}#content_left .c-border .result-op:last-child,#content_left .c-border .result:last-child{margin-bottom:12px}#content_left .result .f,#content_left .result-op .f{padding:0}.subLink_factory{border-collapse:collapse}.subLink_factory td{padding:0}.subLink_factory td.middle,.subLink_factory td.last{color:#666}.subLink_factory td a{text-decoration:underline}.subLink_factory td.rightTd{text-align:right}.subLink_factory_right{width:100%}.subLink_factory_left td{padding-right:26px}.subLink_factory_left td.last{padding:0}.subLink_factory_left td.first{padding-right:75px}.subLink_factory_right td{width:90px}.subLink_factory_right td.first{width:auto}.general_image_pic{margin-top:2px}.general_image_pic a{background:#fff no-repeat center center;text-decoration:none;display:block;overflow:hidden;text-align:center}.c-icon-v1,.c-icon-v2,.c-icon-v3{border:1px solid #d8d8d8;cursor:pointer;border-color:transparent;_border-color:tomato;_filter:chroma(color=#ff6347)}.c-icon-v1:active,.c-icon-v2:active,.c-icon-v3:active{border-color:#a2a6ab;background-color:#f0f0f0;box-shadow:inset 1px 1px 1px #c7c7c7;-webkit-box-shadow:inset 1px 1px 1px #c7c7c7;-moz-box-shadow:inset 1px 1px 1px #c7c7c7;-o-box-shadow:inset 1px 1px 1px #c7c7c7}.c-icon-v1:hover,.c-icon-v2:hover,.c-icon-v3:hover{border-color:#388bff}.opui-honourCard{font-size:12px;color:#666;line-height:1.5em;width:354px}.opui-honourCard-score{width:60px;padding:4px 2px;text-align:center;float:left}.opui-honourCard-score em{width:63px;display:block;font-size:37px;line-height:37px;color:#8e8d8d;font-family:arial;font-style:normal}.opui-honourCard-info{background:#f5f5f5;overflow:hidden;zoom:1}.opui-honourCard-title a{*font-family:Microsoft YaHei}.opui-honourCard-title a i{position:relative;left:-65px;*left:-68px}.opui-honourCard ol{list-style:none;margin:0;padding:0;float:left;_padding-top:5px}.opui-honourCard li{height:20px;line-height:20px;padding-left:20px;_vertical-align:bottom}.opui-honourCard li i{vertical-align:middle;_vertical-align:bottom}.opui-honourCard-selected{color:#2b2a2a;font-weight:700;background:url(https://ss1.bdstatic.com/5eN1bjq8AAUYm2zgoY3K/r/www/cache/biz/ecom/common/api/img/ns-credit/honourCard.png) no-repeat 3px 5px;*background-position:3px 2px}.c-tip-con .c-tip-menu li a{display:block;text-decoration:none;cursor:pointer;background-color:#fff;padding:3px 0;color:#000}
                        </style>
<div class="wgt-ads qbleftdown">
<style>.EC_ads_list .EC_ads_answer a,.EC_ads_list .EC_ad_title{color:#2D64B3;text-decoration:none}.EC_ads_listborder{padding:10px 32px 19px 29px;border:1px solid #D6D6D6;background-color:#fff;position:relative;zoom:1;margin-bottom:10px}.EC_ads_container{white-space:nowrap;overflow:hidden;padding-left:1px;line-height:20px}.EC_ads_listborder .EC_ads_list a{padding:0;margin:0;font-size:14px}.EC_ads_list li{border-bottom:1px dashed #E3E3E3;height:34px;line-height:34px;white-space:nowrap;overflow:hidden}.EC_ads_listborder .EC_ads_list li a,.EC_ads_listborder .EC_ads_list li font{text-decoration:none}.EC_ads_listtitle{line-height:30px}.EC_ads_list a{float:left}.EC_ads_listborder .EC_ads_list .EC_ads_listurl,.EC_ads_list .EC_ads_listurl:visited{color:green;font-family:arial;font-size:12px;float:right}.EC_ads_listborder .EC_ads_list .EC_ads_v{padding:0 0 0 8px;float:right;+padding:0 0 0 8px;_padding:7px 0 0 8px}.EC_ads_list .EC_ads_answer{font-size:12px;color:#666;float:left}.EC_ads_listborder .EC_ads_list .EC_ads_answer a{float:none;font-size:12px}.EC_ads_listborder a.EC_ad_title{text-decoration:none}.EC_ads_listborder a.EC_ad_title font{text-decoration:none}.EC_ads_listborder a.EC_ad_title:hover{text-decoration:underline}.EC_ads_listborder .EC_ads_list a.EC_ads_tg,.ec_ik220_title .EC_ads_tg{float:right;color:#666;text-decoration:none;font-size:13px;margin-left:8px}.ec_ik220_title .EC_ads_tg{color:#666;text-decoration:none}.ec_ik220_title .EC_ads_tg:hover{text-decoration:none}.ec_ik220_title h2{display:inline}.ec_ik220_fright{float:right}.ec_ik220_clearfix{overflow:hidden;*zoom:1}.ec_ik220_clearfix:after{content:" ";display:block;height:0;clear:both;visibility:hidden}.EC_ads_listborder .EC_ads_list font{color:#34b458}.wgt-ads .ec_ik220_ads .ec_ik220_aditem a,.ec_ik220_ads .ec_ik220_aditem a,.wgt-ads .EC_ads_list .EC_ads_answer a,.wgt-ads .EC_ads_list .EC_ad_title,.EC_ads_list .EC_ads_container .EC_ads_answer a,.EC_ads_list .EC_ads_container .EC_ad_title{color:#333;text-decoration:none}.wgt-ads .ec_ik220_ads .ec_ik220_aditem .ec_ik220_desc,.ec_ik220_ads .ec_ik220_aditem .ec_ik220_desc{color:#888;font-size:12px}.wgt-ads .ec_ik220_ads .ec_ik220_aditem a:hover,.ec_ik220_ads .ec_ik220_aditem a:hover,.wgt-ads .EC_ads_list .EC_ad_title:hover,.EC_ads_list .EC_ads_container .EC_ads_answer a:hover,.EC_ads_list .EC_ads_container .EC_ad_title:hover{color:#34b458;text-decoration:underline}.wgt-ads .ec_ik220_ads .ec_ik220_aditem .ec_ik220_desc:hover,.ec_ik220_desc:hover{color:#888}</style><div class="EC_ads_listborder EC_result"><div class="EC_ads_container ec_im_container"><div class="ec_ik220_clearfix ec_ik220_title"><a class="EC_ads_tg ec_ik220_fright" href="http://e.baidu.com/?id=1" target="_blank">广告</a><h2 class="EC_ads_listtitle">您可能关注的内容</h2></div><style>.EC_ads_listborder{padding:25px 30px 20px 30px;margin: 0;border: none;}.ec_ik220_adliststyle2{margin: 4px 0 0 0;}.EC_ads_container .ec_ik220_adliststyle2 li{height: 30px;line-height: 30px;*height: 26px;*line-height: 26px;}.wgt-ads .EC_ads_listborder .EC_ads_container .ec_ik220_adliststyle2 li .EC_ads_listurl:hover,.EC_ads_listborder .EC_ads_container .ec_ik220_adliststyle2 li .EC_ads_listurl:hover,.EC_ads_listurl:hover {text-decoration: underline;}.EC_ads_listborder .EC_ads_list .EC_ads_listurl,.EC_ads_list .EC_ads_listurl:visited {color: #9eadb6;}.EC_ads_listborder .ec_ik220_adliststyle2 li a {font-family: "Microsoft YaHei";}.EC_ads_listborder .EC_ads_list font {color: #333;}.wgt-ads .EC_ads_list .EC_ad_title:hover font {color:#34b458;}</style><ul id='ec_zwd_ctner' class="EC_ads_list ec_ik220_adliststyle2"><li><a href="http://www.baidu.com/baidu.php?url=0f0000jeTx0mG_-ZTrRs4EIQKogdxdTFwaicc9LZDQH-vdZx5WODmt3PKjfYFKWWFS88uLyBlHDZnsvo_6ayT3La_phg-_lpy6ZYOsNRV-bSroBqCBtJpfE2obiiNdduhXxJufUzSO01Cx_UK7KZob34WBVKFSRuVdFcJ-fO_5zuTbDggrF8dKc69Rp1mzCr1dALWpoPkAX8fE8gi0.Db_ifYgsq_puECH4gn1RcY_1fdXAaBSQV69CE9eXqZDkvTxAzz1Wguk3SPI-XOFd8W4mSgV3PyFWI_tUQQQrr1GzUQ5A1WvIUCSN521IBmovyyXrzzEIklXVYx2M-8Hqj3R_fqUCSgKPw4xCmzIUCSy4nIj-sHRy2J7jZZOlsfTZKsXyNPaSu-tRpcrAJjZNWWCrhYsw3YsEuCksml_TIKYvhjZNWWCrhYtSSa9G4mLmFCR_g_3_ZgKfYt8-P1tA-BZZjdsRP5Qa1Gk_Edwnfkuevg4OHMkdm3ljGVrxZNMksqT7jHzs8BCFBCnml_TIKYvM5WJk4YqArB4qjo6CpXy6hUik9_8svn3l_X7rOj_LmI-v75W9E8s_GyF9OUDe6yAp7WI8Le8-f0.U1Yk0ZDqIv7VTZP-IhNzFHcskXHysdKcRn2LEom0TA-W5HD0IjdspZj74PUj0A-V5Hc1r0KM5gK1UMn0Iybq0ZKGujYz0APGujYYnjf0UgfqnH0kPsKopHYs0ZFY5HfvrfK-pyfqrjTsnjD0mhbqPj0zg1csP7t1njFxn1010AdW5H6kPHb3n1TdPsKkTA-b5H00TyPGujYs0ZFMIA7M5H00Uy-b5H00pg7Y5H00mycqn7ts0ANzu1Ys0ZKs5HcLnWTsrjcsPj60UMus5H08nj0snj0snj00Ugws5H00uAwETjYs0ZFJ5H00uMfqn0KspjYs0Aq15H00mMTqn0K8IjYs0ZPl5fK9TdqGuAnqUMnVmLf0IZN15HDvPHD4rHR4nHT1P1bvPW6kPjbL0ZF-TgfqnHRdnjTdn1n3nWmvrfK1pyfqnj6dmWbLm1IBnyndmHRsP6KWTvYqwHRdwHDLfYFKwRuAfHfvffK9m1Yk0ZK85H00TydY5H00Tyd15H00XMfqn0KVmdqhThqV5H00uA78IyF-gLK_my4GuZnqn0Ksmgwxuhk9u1Ys0AwWpyfqn0K-IA-b5iYk0A71TAPW5H00IgKGUhPW5H00Tydh5H00uhPdIjYs0AulpjYs0Au9IjYs0ZGsUZN15H00mywhUA7M5HD0UAuW5H00mLFW5HDsrHnd&word=wampsever+%E9%85%8D%E7%BD%AEPHP%E8%B7%AF%E5%BE%84" target="_blank" class="EC_ad_title">PhpStorm <font color=#C60A00>PHP</font>集成开发工具 - JetBrains</a><a class="c-tip-icon" style="float:right;margin-left:8px;">
    <i tip-url="http://www.baidu.com/tools?url=http%3A%2F%2Fwww.baidu.com%2Fbaidu.php%3Furl%3D0f0000jeTx0mG_-ZTrRs4EIQKogdxdTFwaicc9LZDQH-vdZx5WODmt3PKjfYFKWWFS88uLyBlHDZnsvo_6ayT3La_phg-_lpy6ZYOsNRV-bSroBqCBtJpfE2obiiNdduhXxJufUzSO01Cx_UK7KZob34WBVKFSRuVdFcJ-fO_5zuTbDggrF8dKc69Rp1mzCr1dALWpoPkAX8fE8gi0.Db_ifYgsq_puECH4gn1RcY_1fdXAaBSQV69CE9eXqZDkvTxAzz1Wguk3SPI-XOFd8W4mSgV3PyFWI_tUQQQrr1GzUQ5A1WvIUCSN521IBmovyyXrzzEIklXVYx2M-8Hqj3R_fqUCSgKPw4xCmzIUCSy4nIj-sHRy2J7jZZOlsfTZKsXyNPaSu-tRpcrAJjZNWWCrhYsw3YsEuCksml_TIKYvhjZNWWCrhYtSSa9G4mLmFCR_g_3_ZgKfYt8-P1tA-BZZjdsRP5Qa1Gk_Edwnfkuevg4OHMkdm3ljGVrxZNMksqT7jHzs8BCFBCnml_TIKYvM5WJk4YqArB4qjo6CpXy6hUik9_8svn3l_X7rOj_LmI-v75W9E8s_GyF9OUDe6yAp7WI8Le8-f0.U1Yk0ZDqIv7VTZP-IhNzFHcskXHysdKcRn2LEom0TA-W5HD0IjdspZj74PUj0A-V5Hc1r0KM5gK1UMn0Iybq0ZKGujYz0APGujYYnjf0UgfqnH0kPsKopHYs0ZFY5HfvrfK-pyfqrjTsnjD0mhbqPj0zg1csP7t1njFxn1010AdW5H6kPHb3n1TdPsKkTA-b5H00TyPGujYs0ZFMIA7M5H00Uy-b5H00pg7Y5H00mycqn7ts0ANzu1Ys0ZKs5HcLnWTsrjcsPj60UMus5H08nj0snj0snj00Ugws5H00uAwETjYs0ZFJ5H00uMfqn0KspjYs0Aq15H00mMTqn0K8IjYs0ZPl5fK9TdqGuAnqUMnVmLf0IZN15HDvPHD4rHR4nHT1P1bvPW6kPjbL0ZF-TgfqnHRdnjTdn1n3nWmvrfK1pyfqnj6dmWbLm1IBnyndmHRsP6KWTvYqwHRdwHDLfYFKwRuAfHfvffK9m1Yk0ZK85H00TydY5H00Tyd15H00XMfqn0KVmdqhThqV5H00uA78IyF-gLK_my4GuZnqn0Ksmgwxuhk9u1Ys0AwWpyfqn0K-IA-b5iYk0A71TAPW5H00IgKGUhPW5H00Tydh5H00uhPdIjYs0AulpjYs0Au9IjYs0ZGsUZN15H00mywhUA7M5HD0UAuW5H00mLFW5HDsrHnd%26word%3Dwampsever%2B%25E9%2585%258D%25E7%25BD%25AEPHP%25E8%25B7%25AF%25E5%25BE%2584&jump=http%3A%2F%2Fjubao.baidu.com%2Fjubao%2Faccu%2F%3Ftitle%3DPhpStorm%2BPHP%25E9%259B%2586%25E6%2588%2590%25E5%25BC%2580%25E5%258F%2591%25E5%25B7%25A5%25E5%2585%25B7%2B-%2BJetBrains%26q%3Dwampsever%2B%25E9%2585%258D%25E7%25BD%25AEPHP%25E8%25B7%25AF%25E5%25BE%2584&key=surl" jubao="举报" class="c-icon c-icon-triangle-down"></i>
</a><a class="EC_ads_listurl" href="http://www.baidu.com/baidu.php?url=0f0000jeTx0mG_-ZTrRs4EIQKogdxdTFwaicc9LZDQH-vdZx5WODmt3PKjfYFKWWFS88uLyBlHDZnsvo_6ayT3La_phg-_lpy6ZYOsNRV-bSroBqCBtJpfE2obiiNdduhXxJufUzSO01Cx_UK7KZob34WBVKFSRuVdFcJ-fO_5zuTbDggrF8dKc69Rp1mzCr1dALWpoPkAX8fE8gi0.Db_ifYgsq_puECH4gn1RcY_1fdXAaBSQV69CE9eXqZDkvTxAzz1Wguk3SPI-XOFd8W4mSgV3PyFWI_tUQQQrr1GzUQ5A1WvIUCSN521IBmovyyXrzzEIklXVYx2M-8Hqj3R_fqUCSgKPw4xCmzIUCSy4nIj-sHRy2J7jZZOlsfTZKsXyNPaSu-tRpcrAJjZNWWCrhYsw3YsEuCksml_TIKYvhjZNWWCrhYtSSa9G4mLmFCR_g_3_ZgKfYt8-P1tA-BZZjdsRP5Qa1Gk_Edwnfkuevg4OHMkdm3ljGVrxZNMksqT7jHzs8BCFBCnml_TIKYvM5WJk4YqArB4qjo6CpXy6hUik9_8svn3l_X7rOj_LmI-v75W9E8s_GyF9OUDe6yAp7WI8Le8-f0.U1Yk0ZDqIv7VTZP-IhNzFHcskXHysdKcRn2LEom0TA-W5HD0IjdspZj74PUj0A-V5Hc1r0KM5gK1UMn0Iybq0ZKGujYz0APGujYYnjf0UgfqnH0kPsKopHYs0ZFY5HfvrfK-pyfqrjTsnjD0mhbqPj0zg1csP7t1njFxn1010AdW5H6kPHb3n1TdPsKkTA-b5H00TyPGujYs0ZFMIA7M5H00Uy-b5H00pg7Y5H00mycqn7ts0ANzu1Ys0ZKs5HcLnWTsrjcsPj60UMus5H08nj0snj0snj00Ugws5H00uAwETjYs0ZFJ5H00uMfqn0KspjYs0Aq15H00mMTqn0K8IjYs0ZPl5fK9TdqGuAnqUMnVmLf0IZN15HDvPHD4rHR4nHT1P1bvPW6kPjbL0ZF-TgfqnHRdnjTdn1n3nWmvrfK1pyfqnj6dmWbLm1IBnyndmHRsP6KWTvYqwHRdwHDLfYFKwRuAfHfvffK9m1Yk0ZK85H00TydY5H00Tyd15H00XMfqn0KVmdqhThqV5H00uA78IyF-gLK_my4GuZnqn0Ksmgwxuhk9u1Ys0AwWpyfqn0K-IA-b5iYk0A71TAPW5H00IgKGUhPW5H00Tydh5H00uhPdIjYs0AulpjYs0Au9IjYs0ZGsUZN15H00mywhUA7M5HD0UAuW5H00mLFW5HDsrHnd&word=wampsever+%E9%85%8D%E7%BD%AEPHP%E8%B7%AF%E5%BE%84" target="_blank">www.jetbrains.com</a></li></ul></div></div>
</div>
<script>
                            !function(e){e.ecom=e.ecom||{},e.ecom.pl=e.ecom.pl||{},e.ecom.pl.imTimesign=parseInt("112",10),e.ecom.pl.searchId="085b97c7b1c5a506"}(window);!function(e){function n(n){var t=location.href.match("debug=1"),o=window.jQuery||{};if(t)n(e.pl,o);else try{n(e.pl,o)}catch(i){}}e.pl.run=function(e,t){t||1==arguments.length?bds.ready(function(){n(e)}):n(e)},e.pl.q=function(e,n){if(n=n||document,n.getElementsByClassName)return n.getElementsByClassName(e);var t=[],o=n.all||n.getElementsByTagName("*"),i=o.length;e=e.replace(/\-/g,"\\-");for(var r=new RegExp("(^|\\s)"+e+"(\\s|$)");--i>=0;)r.test(o[i].className)&&t.push(o[i]);return t}}(window.ecom),function(e){function n(){var e=y.href,n=N.exec(e)||k.exec(e);
return n?n[1]:!1}function t(e){var t=n();if(t!==!1){var r=i(t,e);o(r)}}function o(e){var n="&ck="+[e,g,E,v,d,l,m,p].join(".");if(y.href){var t=y.href;-1==t.indexOf("&ck=")?y.href+=n:y.href=t.replace(/&ck=[\d.]*/,n)}}function i(e,n){for(var t=0,o=0;g*n%99+9>o;o++){{e.length<20?e.length:20}t+=e.charCodeAt(E*o%e.length)}return t}function r(e){e=e||window.event,g++,void 0===l&&(l=e.clientX),void 0===m&&(m=e.clientY),s=(new Date).getTime()}function c(e,n){for(e=e||window.event,y=e.target||e.srcElement;y&&"A"!=y.tagName;)y=y.parentNode;
w=(new Date).getTime(),E=9999,v=e.clientX,d=e.clientY,p=0===s?0:w-s,t(n)}function a(e,n){h=(new Date).getTime(),E=h-w,t(n)}function u(e,n,t){var o,i,r;for(r in n)o=n[r],i=t[r],window.attachEvent?e.attachEvent("on"+o,i):e.addEventListener(o,i,!1)}function f(e){return[function(e){r(e)},function(n){c(n,e)},function(n){a(n,e)}]}var l=void 0,m=void 0,v=0,d=0,g=0,s=0,w=0,h=0,p=0,E=0,y=0,N=/link\?url\=([^\&]+)/,k=/\?url\=([^\.]+)\./;e.ck=function(e,n){void 0===e.length&&(e=[e]);for(var t=e.length,o=0,i=f(n);t>o;o++)u(e[o],["mouseover","mousedown","mouseup"],i)
}}(window.ecom.pl),window.ecom.pl.run(function(e){for(var n=e.q("EC_result"),t=0;t<n.length;t++){var o=n[t],i=o.getElementsByTagName("A");e.ck(i,window.ecom.pl.imTimesign)}},!1);!function(){function t(){var t={statistics:{identity:<?php echo url("","",true,false);?>}}};window.__nsTip__.init(t)}function e(t){for(var e=!1,n=document.getElementsByTagName("script"),i=0,a=n.length;a>i;i++)if(n[i].getAttribute("id")===t){e=!0;break}return e}function n(t,n,i){if(!e(t)){var a=document.getElementsByTagName("head")[0]||document.body,r=document.createElement("script");r.setAttribute("type","text/javascript"),r.setAttribute("src",n),r.setAttribute("id",t),null!=i&&(r.onload=r.onreadystatechange=function(){return r.ready?!1:void(r.readyState&&"loaded"!=r.readyState&&"complete"!=r.readyState||(r.ready=!0,i()))
}),a.appendChild(r)}}if(window.__nsTip__)t();else{var i="https://ss1.bdstatic.com/5eN1bjq8AAUYm2zgoY3K/r/www/cache/biz/ecom/common/api/v-nstip/20151117/nstip.js";n("nstip",i,t)}}();!function(t,e){function n(t){return this.containerId="c-tips-container",this.advertContainerId=["ec_zwd_ctner","ec_pc_search","ec_im_220_2062_for_vui_widget"],this.triangularSign="tip-url",this.delaySeconds=200,this.adventContainer="",this.triangulars=[],this.motherContainer=o.createDom("div"),this.oTipContainer=o.getDom(this.containerId),this.tip="",this.tpl='<div class="c-tip-con"><div><div class="c-tip-menu"><ul><li><a target="_blank" href="{{#href}}">{{#jubao}}</a></li></ul></div></div><div class="c-tip-arrow" style="left: 30px;"><em></em><ins></ins></div></div>',this.arrInit(t)
}var i=Array.prototype.slice,r={isListener:document.addEventListener,getOnEvent:function(t,e,n,i){return function(r){var r=r||window.event;return n.call(i||t,r,e,i)===!1?(r.preventDefault(),!1):void 0}}};r.addEventListener=r.isListener?function(t,e,n,i,o){return e=e.replace(/^on/i,""),t.addEventListener(e,r.getOnEvent(t,e,n,i),!!o),t}:function(t,e,n,i){return e=e.replace(/^on/i,""),t.attachEvent("on"+e,r.getOnEvent(t,e,n,i)),t};var o={getDom:function(t,n){return arguments.length<=1?e.getElementById(t):(n||e).getElementsByTagName(t)
},createDom:function(t,n,i){var r=e.createElement(t);for(var o in n)r[o]=n[o];return i&&i.appendChild(r),r},getElementsByClassName:function(t,e){for(var n=(e||document).getElementsByTagName("*"),i=new RegExp("\\b"+t+"\\b","i"),r=[],o=0,a=n.length;a>o;o++)i.test(n[o].className)&&r.push(n[o]);return r},getPosition:function(t){var e=t&&t.ownerDocument,n={left:0,top:0};if(!e)return n;var i=t.getBoundingClientRect(),r=e.documentElement,o=r.clientLeft,a=r.clientTop,s=window.pageXOffset||r.scrollLeft,u=window.pageYOffset||r.scrollTop;
return n.left=i.left+s-o,n.top=i.top+u-a,n},getStyle:function(t,e){return t.currentStyle?t.currentStyle[e]:getComputedStyle(t,!1)[e]}},a=function(t,e){function n(){if(n=null,"complete"===e.readyState)r&&r();else if(e.dispatchEvent)e.addEventListener("DOMContentLoaded",r);else{e.attachEvent("onreadystatechange",function(){"complete"===e.readyState&&r&&r()});try{var t=null===window.frameElement}catch(a){}document.documentElement.doScroll&&t&&window.external&&i(function(){r&&r()})}var s=e.dispatchEvent?"addEventListener":"attachEvent",u=e.dispatchEvent?"load":"onload";
return o[s](u,function(){r&&r()},!1),!0}function i(t){try{document.documentElement.doScroll("left"),t&&t.call(null)}catch(e){setTimeout(function(){i(t)},0)}}function r(){r=null,o.domIsReady=!0;for(var t,e=0,n=a.length;n>e&&(t=a[e]);e++)t.call(null);a=[]}var o=this||(0,eval)("this"),a=[],s=function(t){return t&&"function"==typeof t?r?(a.push(t),n&&n()):t.call():!1};return s}(t,e);t.domReady=t.domReady||a,n.prototype={constructor:n,arrInit:function(){for(var t=0;t<this.advertContainerId.length;t++)this.init(this.advertContainerId[t])
},init:function(t){return this.adventContainer=o.getDom(t),this.adventContainer?this.reset().initContainer().initTriangulars().bindEvents():this},initContainer:function(){var t=this;return this.oTipContainer||(this.oTipContainer=o.createDom("div",{id:t.containerId,className:t.containerId},e.body)),this},initTriangulars:function(){return this.triangulars=this.getTriangulars(),this},getEvents:function(){var t=this,e={mouseenter:function(){return this.isRendered?(t.showTip.apply(this.tip,i.call(arguments)),this):(this.tip=t.renderTip(this.getAttribute(t.triangularSign),this.getAttribute("jubao")),this.tip.self=t,t.oTipContainer.appendChild(this.tip),t.showTip.apply(this.tip,i.call(arguments)),t.setPosition(this),r.addEventListener(this.tip,"mouseenter",t.showTip),r.addEventListener(this.tip,"mouseleave",t.hideTip),void(this.isRendered=!0))
},mouseleave:function(){t.hideTip.apply(this.tip,i.call(arguments))}};return e},bindEvents:function(){for(var t,e=this.getEvents(),n=0;t=this.triangulars[n++];)for(var o in e)r.addEventListener(t,o,function(t){return function(){return e[t].apply(this,i.call(arguments))}}(o));return this},setPosition:function(t){if(!t&&!t.tip)return!1;var e=o.getDom("em",t.tip)[0],n=o.getPosition(t),i=n.left+t.offsetWidth/2-t.tip.offsetWidth/2,r=n.top+t.offsetHeight+e.offsetHeight/2;return t.tip.style.left=i+"px",t.tip.style.top=r+"px",this
},renderTip:function(t,e){var n=this.tpl.replace(/\{\{#href\}\}/g,t).replace(/\{\{#jubao\}\}/g,e);return this.motherContainer.innerHTML=n,this.motherContainer.removeChild(this.motherContainer.children[0])},showTip:function(){return clearTimeout(this.hideTimer),this.style.display="block",this},hideTip:function(){var t=this;return this.hideTimer=setTimeout(function(){t.style.display="none"},this.self.delaySeconds),this},getTriangulars:function(){for(var t,e=[],n=0,i=o.getDom("i",this.adventContainer);t=i[n++];)t.hasAttribute(this.triangularSign)&&e.push(t);
return e},reset:function(t){for(var e in t)this[e]=t[e];return this}},t.TipOffComponent=t.TipOffComponent||n}(window,document);!function(n){n.domReady(function(){new n.TipOffComponent})}(window,document);
                        </script>

</td></tr></table>
<style type="text/css">
            #qbleftdown-container .EC_ads_listborder {
                border: none;
                margin-bottom: 0px;
                padding: 30px 0 20px 42px;
                font-family: "Microsoft YaHei";
            }
            .wgt-asp-top {
                border-bottom: 1px solid #ebf0f1;
            }
            .wgt-asp-bottom {
                border-top: 1px solid #ebf0f1;
            }
            .qbleftdown h2 {
                margin-bottom: 10px;
            }

        </style>
<script type="text/javascript">
            F.context('ads_log_leftdown', 1);
        </script>
<div class="wgt-related mt-5 mod-shadow" id="wgt-related">
<h2><i class="iknow-qb_home_icons"></i>其他类似问题</h2>
<div class="related-list line">
<ul class="list-34 related-ul" alog-group="qb-relative-que">
<li >
<span class="grid-r f-aid ff-arial">2016-09-16</span>
<a href="/question/922895209736407139.html?qbl=relate_question_0&word=wampsever%20%C5%E4%D6%C3PHP%C2%B7%BE%B6" target="_blank"
                    log="fr:qrl,pms:newqb,page:qb-new,pos:relative_title,qtype:zd,index:1,cid:1069,fr2:query" class="related-link related-link-zd" data-qid="922895209736407139">
<span class="related-restrict-title grid">如何修改wampserver的www目录或根目录</span>
</a>
</li>
<li >
<span class="grid-r f-aid ff-arial">2017-01-04</span>
<a href="/question/1962976226507868580.html?qbl=relate_question_1&word=wampsever%20%C5%E4%D6%C3PHP%C2%B7%BE%B6" target="_blank"
                    log="fr:qrl,pms:newqb,page:qb-new,pos:relative_title,qtype:zd,index:2,cid:1069,fr2:query" class="related-link related-link-zd" data-qid="1962976226507868580">
<span class="related-restrict-title grid">wampserver 怎么配置环境变量</span>
<em class="praise-num ml-5" title="所有回答获得1个赞同">
<i class="ikonw-qb-new-icon wgt-related-praise"></i><span class="ml-5 ff-arial">1</span>
</em>
</a>
</li>
<li >
<span class="grid-r f-aid ff-arial">2014-11-13</span>
<a href="/question/424679150904573652.html?qbl=relate_question_2&word=wampsever%20%C5%E4%D6%C3PHP%C2%B7%BE%B6" target="_blank"
                    log="fr:qrl,pms:newqb,page:qb-new,pos:relative_title,qtype:zd,index:3,cid:1069,fr2:query" class="related-link related-link-zd" data-qid="424679150904573652">
<span class="related-restrict-title grid">wampserver 2.5 64位 项目路径配置</span>
</a>
</li>
<li >
<span class="grid-r f-aid ff-arial">2017-10-23</span>
<a href="/question/1707595356322805820.html?qbl=relate_question_3&word=wampsever%20%C5%E4%D6%C3PHP%C2%B7%BE%B6" target="_blank"
                    log="fr:qrl,pms:newqb,page:qb-new,pos:relative_title,qtype:zd,index:4,cid:1069,fr2:query" class="related-link related-link-zd" data-qid="1707595356322805820">
<span class="related-restrict-title grid">如何修改WAMPServer默认的网站路径地址</span>
</a>
</li>
<li >
<span class="grid-r f-aid ff-arial">2015-09-06</span>
<a href="/question/306130341857450004.html?qbl=relate_question_4&word=wampsever%20%C5%E4%D6%C3PHP%C2%B7%BE%B6" target="_blank"
                    log="fr:qrl,pms:newqb,page:qb-new,pos:relative_title,qtype:zd,index:5,cid:1069,fr2:query" class="related-link related-link-zd" data-qid="306130341857450004">
<span class="related-restrict-title grid">如何修改WAMPServer默认的网站路径地址</span>
</a>
</li>
<li >
<span class="grid-r f-aid ff-arial">2016-09-21</span>
<a href="/question/1178642029851576419.html?qbl=relate_question_5&word=wampsever%20%C5%E4%D6%C3PHP%C2%B7%BE%B6" target="_blank"
                    log="fr:qrl,pms:newqb,page:qb-new,pos:relative_title,qtype:zd,index:6,cid:1069,fr2:query" class="related-link related-link-zd" data-qid="1178642029851576419">
<span class="related-restrict-title grid">怎么改变wampserver默认的网站目录</span>
<i class="iknow-qb_home_icons i-has-img" title="该问题包含图片"></i>
</a>
</li>
<li >
<span class="grid-r f-aid ff-arial">2018-01-24</span>
<a href="/question/589177943934674525.html?qbl=relate_question_6&word=wampsever%20%C5%E4%D6%C3PHP%C2%B7%BE%B6" target="_blank"
                    log="fr:qrl,pms:newqb,page:qb-new,pos:relative_title,qtype:jx,index:7,cid:1069,fr2:query" class="related-link related-link-jx" data-qid="589177943934674525">
<span class="related-restrict-title grid">JAVA的配置路径怎么弄？</span>
</a>
</li>
<li >
<span class="grid-r f-aid ff-arial">2016-10-24</span>
<a href="/question/1386166950299289340.html?qbl=relate_question_7&word=wampsever%20%C5%E4%D6%C3PHP%C2%B7%BE%B6" target="_blank"
                    log="fr:qrl,pms:newqb,page:qb-new,pos:relative_title,qtype:zd,index:8,cid:1069,fr2:query" class="related-link related-link-zd" data-qid="1386166950299289340">
<span class="related-restrict-title grid">如何修改WAMPServer默认的网站路径地址</span>
</a>
</li>
</ul>
</div>
<div class="related-more clearfix">
<a log="fr:qrl,pms:newqb,pos:relative_more" alog-action="qb-relative-more" target="_blank" rel="nofollow" href="/search?word=wampsever%20%C5%E4%D6%C3PHP%C2%B7%BE%B6&ie=gbk&fr=qrl&cid=1069&qbl=relate_question_more" class="line f-14 mt-5">
更多相关<em>wampsever 配置PHP路径</em>的问题<span class="ff-arial">&nbsp;&gt;</span>
</a>
</div>
</div>
<div class="wgt-bottom-union mod-shadow last line wgt-union-bottom">
<h2><i class="iknow-qb_home_icons"></i>为你推荐：</h2>
<script type="text/javascript" src="//mountain.zhidao.baidu.com/rmeiloouv.js"></script>
</div>
</article>
<aside class="grid-r qb-side" id="qb-side">
<div style="display:none">
1
2
</div>
<div class="cms-slide cms-slide-lazy mod-noshadow">
<p class="cms-link-title">特别推荐</p>
<script type="text/javascript">
        F.context('cmsRight', [
                                                            
                            {
                    'url':'https://zhidao.baidu.com/kit/topic?name=tuhudongji&from=qbyouce',
                    'src':'https://gss0.bdstatic.com/7051cy89RcgCncy6lo7D0j9wexYrbOWh7c50/tuhuchunjie/270170.jpg?t=1550747459'
                },                                                                        
                            {
                    'url':'https://zhidao.baidu.com/kit/topic?name=aodia6LNew',
                    'src':'https://gss0.bdstatic.com/7051cy89RcgCncy6lo7D0j9wexYrbOWh7c50/aodi/270-140.png?t=1550747459'
                },                                                                        
                            {
                    'url':'',
                    'src':''
                }                            ]);
    </script>
<div class="cms-scroll" id="cms-scroll">
<div class="cms-mask" id="cms-mask"></div>
</div>
<div class="cms-inner">
<ul id="cms-link">
<li><a alog-action="qb-inner-link" href="http://zhidao.baidu.com/daily/view?id=152399" target="_blank" log="page:question,area:knowledge,index:0">为什么日本人很少有肥胖的？</a></li>
<li><a alog-action="qb-inner-link" href="http://zhidao.baidu.com/daily/view?id=152407" target="_blank" log="page:question,area:knowledge,index:1">渣男！丈夫强闯ICU杀妻</a></li>
<li><a alog-action="qb-inner-link" href="http://zhidao.baidu.com/daily/view?id=151545" target="_blank" log="page:question,area:knowledge,index:2">八旗铁骑是如何跨海作战的？</a></li>
<li><a alog-action="qb-inner-link" href="http://zhidao.baidu.com/daily/view?id=152274" target="_blank" log="page:question,area:knowledge,index:3">没文化，千万别和重庆人吵架</a></li>
</ul>
</div>
</div>
<div id="wgt-ad-right-fixed">
<a log="area:right_bonus,action:click,page:question" target="_blank" href="https://zhidao.baidu.com/special/view?id=9fa05a24626975510400" class="wgt-right-bonusseason">
<img style="width: 100%;" src="https://gss0.baidu.com/7051cy89RMgCncy6lo7D0j9wexYrbOWh7c50/activityofmoney/moneypc.jpg" alt="">
</a>
<div class="widget-new-graphic">
<style>.ec-ad {margin-left: -10px;padding-top: 5px;padding-bottom: 12px;}.ec-ad .ec-row-title .ec-title {font: normal 14px/34px 'Microsoft YaHei';padding-left: 10px;color: #666;}.ec-ad .ec-img-list {font-size: 0;}.ec-ad .ec-img-list .ec-img-item {width: 83px;display: inline-block;font-size: 12px;margin-left: 10px;vertical-align: top;}.ec-ad .ec-img {vertical-align: top;}.ec-ad .ec-img-desc {margin-top: 7px;text-align: center;color: #2d64b3;display: block;font-size: 12px;line-height: 18px;}</style><div class="ec-ad"><div class="ec-row-title"><h3 class="ec-title">相关搜索</h3></div><div class="ec-row-desc"><div class="ec-img-list"><a href="https://www.baidu.com/s?wd=%C6%F8%B6%AF%B8%F4%C4%A4%B1%C3%B0%B2%D7%B0%CD%BC&tn=SE_pczhidaotuwenqb_bvf4ih05&lqsource=2&dmaseid=dmaseid0&qid=fcb7c2063f915f1e" class="ec-img-item" target="_blank"><img src="https://gss0.baidu.com/7LsWdDW5_xN3otqbppnN2DJv/dmas/pic/item/08600c338744ebf803ef99aad1f9d72a6159a78d.jpg" class="ec-img" width="83" height="83" alt=""><span class="ec-img-desc">气动隔膜泵安装图</span></a><a href="https://www.baidu.com/s?wd=%BE%ED%C1%B1%B4%B0%C1%B1%B0%B2%D7%B0%B7%BD%B7%A8&tn=SE_pczhidaotuwenqb_bvf4ih05&lqsource=2&dmaseid=dmaseid0&qid=fcb7c2063f915f1e" class="ec-img-item" target="_blank"><img src="https://gss0.baidu.com/7LsWdDW5_xN3otqbppnN2DJv/dmas/pic/item/29ed2e738bd4b31c7c9c0c2e8fd6277f9f2ff880.jpg" class="ec-img" width="83" height="83" alt=""><span class="ec-img-desc">卷帘窗帘安装方法</span></a><a href="https://www.baidu.com/s?wd=%BF%BE%B4%C9%D1%C0%CA%C7%D4%F5%C3%B4%B0%B2%D7%B0%B5%C4&tn=SE_pczhidaotuwenqb_bvf4ih05&lqsource=2&dmaseid=dmaseid0&qid=fcb7c2063f915f1e" class="ec-img-item" target="_blank"><img src="https://gss0.baidu.com/7LsWdDW5_xN3otqbppnN2DJv/dmas/pic/item/36fbb2fb43166d2284f523024e2309f79152d2a2.jpg" class="ec-img" width="83" height="83" alt=""><span class="ec-img-desc">烤瓷牙是怎么安装的</span></a></div></div></div>
</div>
<style type="text/css">
            .ec-ad .ec-row-title .ec-title {
                padding-left: 0;
            }
            .ec-ad .ec-img-list {
                width: 290px;
            }
            .ec-ad .ec-img-list .ec-img-item {
                margin-left: 0;
                margin-right: 10px;
            }
            </style>
</div>
</aside>
</section>
</div>
</div>
<div class="wgt-mask" id="js-mask" style="display: none;"></div>
<div class="wgt-accusation" id="js-accuse">
<div class="close-btn" id="js-accuse-closebtn">×</div>
<ul class="accusation-tip">
<li class="accusation-tip-item">个人、企业类<a href="javascript:void(0)" class="tort-entry">侵权投诉</a></li>
<li class="accusation-tip-item">违法有害信息,请在下方选择后提交</li>
</ul>
<p class="title-item">类别</p>
<div class="types">
<ul class="types-wrap clearfix">
<li class="type-item js-accuse-type-item" data-reason="2">垃圾广告</li>
<li class="type-item js-accuse-type-item" data-reason="3">低质灌水</li>
<li class="type-item js-accuse-type-item" data-reason="4">色情、暴力</li>
<li class="type-item js-accuse-type-item" data-reason="5">政治敏感</li>
</ul>
</div>
<p class="desc">我们会通过消息、邮箱等方式尽快将举报结果通知您。</p>
<p class="title-item">说明</p>
<div class="text-container">
<textarea class="accusation-content" id="js-accuse-content" placeholder="详细的说明，有助于我们更快的理解您的反馈。"></textarea>
<p class="words"><span class="words-current" id="js-accuse-words-current">0</span>/200</p>
</div>
<div class="accusation-btn-group">
<p class="errmsg" id="js-errmsg"></p>
<div class="accusation-btn accusation-btn-submit disabled" id="js-accuse-btn-submit">提交</div>
<div class="accusation-btn accusation-btn-cancel" id="js-accuse-btn-cancel">取消</div>
</div>
</div>


<div class="wgt-footer-new">
<div class="footer-wp">
<ul class="footer-list clearfix">
<li class="footer-list-item footer-list-guide">
<div class="footer-title"><span class="icon-guide"></span>新手帮助</div>
<ul class="footer-link clearfix">
<li><a href="http://help.baidu.com/question?prod_en=zhidao&class=320&id=1525" target="_blank">如何答题</a></li>
<li><a href="http://help.baidu.com/question?prod_id=9&class=320&id=1526" target="_blank">获取采纳</a></li>
<li><a href="http://help.baidu.com/question?prod_id=9&class=337&id=1513" target="_blank">使用财富值</a></li>
</ul>
</li>
<li class="footer-list-item footer-list-intro">
<div class="footer-title"><span class="icon-intro"></span>玩法介绍</div>
<ul class="footer-link clearfix">
<li><a href="/shop" target="_blank">知道商城</a></li>
<li><a href="http://zhidao.baidu.com/pcs/zhimatuan/index.html" target="_blank">知道团队</a></li>
<li><a href="/home/partnerhome" target="_blank">合伙人认证</a></li>
<li><a href="http://zhidao.baidu.com/s/hi-quality/index.html" target="_blank">高质量问答</a></li>
</ul>
</li>
<li class="footer-list-item footer-list-sug">
<div class="user-tip" id="js-footer-user-tip" style="display: none;">
<p class="title">您的帐号状态正常</p>
<p class="desc">感谢您对我们的支持</p>
</div>
<div class="footer-title"><span class="icon-sug"></span>投诉建议</div>
<ul class="footer-link clearfix">
<li><a href="javascript:;" log="module:common,action:click,area:footer_feedback" target="_blank" id="footer-feedback">意见反馈</a></li>
<li><a href="/misc/appeal" log="module:common,action:click,area:footer_appeal" target="_blank" id="js-footer-appeal">账号申诉</a></li>
<li><a href="http://ikefu.baidu.com/web/zhishisousuo#" log="module:common,action:click,area:footer_consult" target="_blank">智能咨询</a></li>
</ul>
</li>
</ul>
</div>
<div class="footer-new">
<p class="jt1128">
京ICP证030173号-1&nbsp;&nbsp;&nbsp;京网文【2013】0934-983号&nbsp;&nbsp;&nbsp;&nbsp;        &copy;2019Baidu&nbsp;&nbsp;<a rel="nofollow" href="http://www.baidu.com/duty/" target="_blank">使用百度前必读</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a rel="nofollow" href="http://help.baidu.com/question?prod_id=9&class=325&id=2760" target="_blank">知道协议</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a rel="nofollow" href="/special/view/cooperation" target="_blank">百度知道品牌合作</a>
</p>
</div>
</div>


<div id="anttongji"></div>





<script>
    void function(a,b,c,d,e,f){function g(b){a.attachEvent?a.attachEvent("onload",b,!1):a.addEventListener&&a.addEventListener("load",b)}function h(a,c,d){d=d||15;var e=new Date;e.setTime((new Date).getTime()+1e3*d),b.cookie=a+"="+escape(c)+";path=/;expires="+e.toGMTString()}function i(a){var c=b.cookie.match(new RegExp("(^| )"+a+"=([^;]*)(;|$)"));return null!=c?unescape(c[2]):null}function j(){var a=i("PMS_JT");if(a){h("PMS_JT","",-1);try{a=a.match(/{["']s["']:(\d+),["']r["']:["']([\s\S]+)["']}/),a=a&&a[1]&&a[2]?{s:parseInt(a[1]),r:a[2]}:{}}catch(c){a={}}a.r&&b.referrer.replace(/#.*/,"")!=a.r||alog("speed.set","wt",a.s)}}if(a.alogObjectConfig){var k=a.alogObjectConfig.sample,l=a.alogObjectConfig.rand;d="https:"===a.location.protocol?"https://fex.bdstatic.com"+d:"http://fex.bdstatic.com"+d,k&&l&&l>k||(g(function(){alog("speed.set","lt",+new Date),e=b.createElement(c),e.async=!0,e.src=d+"?v="+~(new Date/864e5)+~(new Date/864e5),f=b.getElementsByTagName(c)[0],f.parentNode.insertBefore(e,f)}),j())}}(window,document,"script","/hunter/alog/dp.min.js");
    </script>

<script>
				var _hmt = _hmt || [];
				(function() {
					var hm = document.createElement("script");
					hm.src = "https://hm.baidu.com/hm.js?6859ce5aaf00fb00387e6434e4fcc925";
					var s = document.getElementsByTagName("script")[0];
					s.parentNode.insertBefore(hm, s);
				})();
			</script>

</body><script type="text/javascript" src="https://iknowpc.bdimg.com/static/common/lib/mod.75d1f98.js"></script><script type="text/javascript">(window.__IKNOW_GLOBAL__ || window).require.resourceMap({"res":{"common:widget\/lib\/jquery\/jquery.origin.js":{"pkg":"common:p3"},"common:widget\/js\/util\/https\/https.js":{"pkg":"common:p6"},"common:widget\/bottom-ask\/bottom-ask.js":{"pkg":"common:p0","deps":["common:widget\/js\/util\/tangram\/tangram.js","common:widget\/js\/util\/event\/event.js","common:widget\/js\/util\/log\/log.js"]},"common:widget\/css\/fonts\/iconfont.js":{"pkg":"common:p0"},"common:widget\/css\/fonts\/iconfont.min.js":{"pkg":"common:p0"},"common:widget\/footer-new\/footer-new.js":{"pkg":"common:p0","deps":["common:widget\/lib\/jquery\/jquery.js","common:widget\/js\/util\/event\/event.js"]},"common:widget\/footer\/footer.js":{"pkg":"common:p0"},"common:widget\/header-metis\/header.js":{"pkg":"common:p0","deps":["common:widget\/lib\/jquery\/jquery.js","common:widget\/js\/ui\/dialog\/dialog.js","common:widget\/js\/util\/template\/template.js","common:widget\/js\/ui\/scrollbar-new\/scrollbar-new.js","common:widget\/js\/util\/store\/store.js"]},"common:widget\/menu\/menu.js":{"pkg":"common:p0","deps":["common:widget\/js\/util\/tangram\/tangram.js","common:widget\/js\/util\/log\/log.js"]},"common:widget\/search-box-new\/search-box-new.js":{"pkg":"common:p0","deps":["common:widget\/js\/util\/tangram\/tangram.js","common:widget\/js\/ui\/suggestion-new\/suggestion-new.js","common:widget\/js\/util\/event\/event.js","common:widget\/js\/util\/form\/form.js","common:widget\/js\/util\/log\/log.js","common:widget\/js\/ui\/dialog\/dialog.js","common:widget\/lib\/jquery.placeholder\/jquery.placeholder.js"]},"common:widget\/userbar-renew\/userbar-renew.js":{"pkg":"common:p0","deps":["common:widget\/js\/util\/tangram\/tangram.js","common:widget\/js\/util\/event\/event.js","common:widget\/js\/logic\/login\/login.js","common:widget\/js\/util\/log\/log.js","common:widget\/js\/util\/store\/store.js"]},"question-new:widget\/mini-editor\/mini-editor.js":{"pkg":"question-new:p2","deps":["common:widget\/js\/util\/tangram\/tangram.js","common:widget\/js\/util\/event\/event.js","common:widget\/js\/ui\/base\/base.js"]},"common:widget\/js\/ui\/clipboard\/clipboard.min.js":{"pkg":"common:p4"},"question-new:widget\/ask\/editor-guide\/editor-guide.js":{"pkg":"question-new:p3","deps":["common:widget\/js\/util\/tangram\/tangram.js","common:widget\/js\/util\/tangram\/cookie.js"]},"question-new:widget\/ask\/pc-exp\/ask-img.js":{"url":"https:\/\/iknowpc.bdimg.com\/static\/question-new\/widget\/ask\/pc-exp\/ask-img.8d3204c.js","deps":["common:widget\/lib\/jquery\/jquery.js","question-new:widget\/read-opt\/img-preview\/preview.js"]},"common:widget\/upgrade-tips\/upgrade-tips.js":{"url":"https:\/\/iknowpc.bdimg.com\/static\/common\/widget\/upgrade-tips\/upgrade-tips.aae0426.js","deps":["common:widget\/js\/util\/tangram\/tangram.js","common:widget\/js\/util\/log\/log.js","common:widget\/js\/util\/https\/https.js"]},"question-new:widget\/js\/send-more\/send-more.es.js":{"url":"https:\/\/iknowpc.bdimg.com\/static\/question-new\/widget\/js\/send-more\/send-more.es.8a4af07.js","deps":["common:widget\/js\/util\/tangram\/tangram.js","common:widget\/js\/util\/store\/store.js"]},"question-new:widget\/js\/submitjump\/submitjump.js":{"pkg":"question-new:p5","deps":["common:widget\/js\/util\/tangram\/tangram.js","common:widget\/js\/logic\/submit\/submit.js","common:widget\/js\/util\/log\/log.js","common:widget\/js\/ui\/dialog\/dialog.js","common:widget\/js\/ui\/pop-tip\/pop-tip.js"]},"question-new:widget\/js\/accuse\/accuse.js":{"pkg":"question-new:p5","deps":["common:widget\/js\/util\/tangram\/tangram.js","common:widget\/js\/util\/log\/log.js","common:widget\/js\/util\/event\/event.js","common:widget\/js\/logic\/login\/login.js","common:widget\/js\/ui\/dialog\/dialog.js"]},"question-new:widget\/user\/info\/basic\/basic.js":{"pkg":"question-new:p5","deps":["common:widget\/lib\/jquery\/jquery.js","common:widget\/js\/util\/event\/event.js","common:widget\/js\/logic\/set-avatar\/set-avatar.js","common:widget\/js\/logic\/sign-in\/sign-in.js"]},"question-new:widget\/user\/info\/bind-mobile\/tip.js":{"pkg":"question-new:p5","deps":["common:widget\/js\/util\/tangram\/tangram.js","common:widget\/js\/util\/log\/log.js"]},"question-new:widget\/user\/info\/daily\/daily.js":{"pkg":"question-new:p5","deps":["common:widget\/js\/util\/tangram\/tangram.js","common:widget\/js\/util\/event\/event.js","common:widget\/js\/util\/log\/log.js","common:widget\/js\/ui\/carousel\/carousel.js"]},"question-new:widget\/js\/psask-bindsms\/psask-bindsms.js":{"url":"https:\/\/iknowpc.bdimg.com\/static\/question-new\/widget\/js\/psask-bindsms\/psask-bindsms.54daf62.js","deps":["common:widget\/js\/util\/tangram\/tangram.js","common:widget\/js\/util\/log\/log.js","common:widget\/js\/util\/event\/event.js","common:widget\/js\/ui\/dialog\/dialog.js","common:widget\/js\/logic\/phone-bind\/phone-bind.js"]},"question-new:widget\/js\/admin\/officialAdmin\/officialAdmin.js":{"url":"https:\/\/iknowpc.bdimg.com\/static\/question-new\/widget\/js\/admin\/officialAdmin\/officialAdmin.2bdbdb8.js","deps":["common:widget\/js\/util\/tangram\/tangram.js","common:widget\/js\/ui\/dialog\/dialog.js","common:widget\/js\/logic\/category\/category.js","common:widget\/js\/util\/event\/event.js"]},"question-new:widget\/js\/set-tag\/set-tag.js":{"url":"https:\/\/iknowpc.bdimg.com\/static\/question-new\/widget\/js\/set-tag\/set-tag.51e6663.js","deps":["common:widget\/js\/util\/tangram\/tangram.js","common:widget\/js\/util\/event\/event.js","common:widget\/js\/ui\/base\/base.js","common:widget\/js\/util\/template\/template.js","common:widget\/js\/ui\/dialog\/dialog.js","common:widget\/js\/ui\/scrollbar\/scrollbar.js","common:widget\/js\/util\/tangram\/string.js"]},"question-new:widget\/js\/admin\/userAdmin\/userAdmin.js":{"url":"https:\/\/iknowpc.bdimg.com\/static\/question-new\/widget\/js\/admin\/userAdmin\/userAdmin.952815d.js","deps":["common:widget\/js\/util\/tangram\/tangram.js","common:widget\/js\/util\/event\/event.js","common:widget\/js\/ui\/dialog\/dialog.js","common:widget\/js\/logic\/category\/category.js","question-new:widget\/js\/set-tag\/set-tag.js","common:widget\/lib\/jquery.placeholder\/jquery.placeholder.js"]},"question-new:widget\/js\/unloginask-bindsms\/unloginask-bindsms.js":{"url":"https:\/\/iknowpc.bdimg.com\/static\/question-new\/widget\/js\/unloginask-bindsms\/unloginask-bindsms.3038abd.js","deps":["common:widget\/js\/util\/tangram\/tangram.js","common:widget\/js\/util\/log\/log.js","common:widget\/js\/util\/event\/event.js","common:widget\/js\/ui\/dialog\/dialog.js"]},"question:widget\/js\/audio\/jplayer\/jplayer.js":{"url":"https:\/\/iknowpc.bdimg.com\/static\/question\/widget\/js\/audio\/jplayer\/jplayer.64dcc3a.js","deps":["common:widget\/lib\/jquery\/jquery.js"]},"question-new:widget\/js\/audio\/audio.js":{"url":"https:\/\/iknowpc.bdimg.com\/static\/question-new\/widget\/js\/audio\/audio.d5225af.js","deps":["common:widget\/js\/util\/tangram\/tangram.js","common:widget\/js\/util\/log\/log.js","question:widget\/js\/audio\/jplayer\/jplayer.js"]}},"pkg":{"common:p0":{"url":"https:\/\/iknowpc.bdimg.com\/static\/common\/pkg\/more.8fa028c.js","has":["common:widget\/bottom-ask\/bottom-ask.js","common:widget\/css\/fonts\/iconfont.js","common:widget\/css\/fonts\/iconfont.min.js","common:widget\/footer-new\/footer-new.js","common:widget\/footer\/footer.js","common:widget\/header-metis\/header.js","common:widget\/menu\/menu.js","common:widget\/search-box-new\/search-box-new.js","common:widget\/userbar-renew\/userbar-renew.js"]},"common:p4":{"url":"https:\/\/iknowpc.bdimg.com\/static\/common\/pkg\/clipboard.0c05b89.js","has":["common:widget\/js\/ui\/clipboard\/clipboard.min.js"]},"question-new:p5":{"url":"https:\/\/iknowpc.bdimg.com\/static\/question-new\/pkg\/login.f9f5c53.js","has":["question-new:widget\/js\/submitjump\/submitjump.js","question-new:widget\/js\/accuse\/accuse.js","question-new:widget\/user\/info\/basic\/basic.js","question-new:widget\/user\/info\/bind-mobile\/tip.js","question-new:widget\/user\/info\/daily\/daily.js"]}}});</script><script type="text/javascript" src="https://iknowpc.bdimg.com/static/common/pkg/lib.33719ed.js"></script><script type="text/javascript" src="https://iknowpc.bdimg.com/static/common/pkg/commonjs.e08515d.js"></script><script type="text/javascript" src="https://iknowpc.bdimg.com/static/common/pkg/ueditor.62b776a.js"></script><script type="text/javascript" src="https://iknowpc.bdimg.com/static/question-new/pkg/module.7a788cd.js"></script><script type="text/javascript" src="https://iknowpc.bdimg.com/static/question-new/pkg/editor.bd546be.js"></script><script type="text/javascript" src="https://iknowpc.bdimg.com/static/question-new/widget/js/comment-accusation/index.es.6af3198.js"></script><script type="text/javascript" src="https://iknowpc.bdimg.com/static/question-new/widget/js/ck/ck.0af7fcd.js"></script><script type="text/javascript" src="https://iknowpc.bdimg.com/static/question-new/pkg/replyer.d18f9ad.js"></script><script type="text/javascript">
!function(){var F = (window.__IKNOW_GLOBAL__ || window).F;var require = (window.__IKNOW_GLOBAL__ || window).require;    require.async(['common:widget/userbar-renew/userbar-renew']);
}();
!function(){var F = (window.__IKNOW_GLOBAL__ || window).F;var require = (window.__IKNOW_GLOBAL__ || window).require;    require.async(['question-new:widget/ad-header/ad-header'], function (Header) {
    	Header.init({
    		hotList: [{"keyword":"\u8305\u53f0\u53eb\u505c\u8d34\u724c\u9152","searches":"21130191","changeRate":"810937","isNew":"0","trend":"rise","gentime":"2019-02-21 20:41:05","interfere":"0","srchCalcu":"21130191","eventid":"efe0d00b41dd3c94368e4f23aa6e607a"},{"keyword":"\u4eac\u4e1c\u5976\u8336\u5e97\u505c\u4e1a","searches":"20441245","changeRate":"1610263","isNew":"1","trend":"rise","interfere":"0","srchCalcu":"20441245","eventid":"21c903a84c9e84347c4bd44ac9d55ba9"},{"keyword":"\u82f1\u4fdd\u5b88\u515a\u8bae\u5458\u8131\u515a","searches":"19529651","changeRate":"5856608","isNew":"0","trend":"rise","interfere":"0","srchCalcu":"19529651","eventid":"14a0ba5e7eba7edc638faf4b50dc24ff"},{"keyword":"\u6000\u624d\u4e0d\u9047\u5415\u79c0\u624d","searches":"18418249","changeRate":"1884018","isNew":"0","trend":"rise","interfere":"0","srchCalcu":"18418249","eventid":"b20b3b3207dd7b554fbcdc79002274af"},{"keyword":"\u5e74\u5ea6\u6700\u60e8\u5c0f\u5b66\u751f","searches":"18382712","changeRate":"1372192","isNew":"0","trend":"rise","interfere":"0","srchCalcu":"18382712","eventid":"3ce82cc944ebf56b7ede653efef4e72d"},{"keyword":"\u8fd8\u613f \u4f55\u8001\u5e08","searches":"18023345","changeRate":"5029675","isNew":"0","trend":"rise","interfere":"0","srchCalcu":"18023345","eventid":"94198639b09e61c9825f15588154d36f"},{"keyword":"\u683c\u529b\u4e07\u5143\u9500\u552e\u4efb\u52a1","searches":"17048296","changeRate":"-241131","isNew":"0","trend":"fall","interfere":"0","srchCalcu":"17048296","eventid":"f70686eeea2b0a73223e0e0c6f4503b2"},{"keyword":"\u5b8f\u8fdc\u7b7e\u9a6c\u5c1a\u6bd4\u65af\u5229","searches":"15397021","changeRate":"4494357","isNew":"0","trend":"rise","interfere":"0","srchCalcu":"15397021","eventid":"9e1b116fae2440936e9dc1af754f13ca"},{"keyword":"\u7f8e\u56fd\u80d6\u753729\u5c81\u53bb\u4e16","searches":"15362176","changeRate":"4918233","isNew":"0","trend":"rise","interfere":"0","srchCalcu":"15362176","eventid":"ae32aeb5716f82fc3d7d9783f627febc"},{"keyword":"\u82f1\u5982\u955d KHL\u9996\u7403","searches":"13623266","changeRate":"-1916472","isNew":"0","trend":"fall","interfere":"0","srchCalcu":"13623266","eventid":"7241f78f95a934195b1cf200152b9fa1"},{"keyword":"\u7ae0\u5b50\u6021\u8c08\u5927\u5973\u513f","searches":"13377676","changeRate":"-6538687","isNew":"1","trend":"fall","interfere":"0","srchCalcu":"13377676","eventid":"99c8e4d8937ee14178cd1f9e9817ad93"},{"keyword":"2019\u5143\u5bb5\u665a\u4f1a","searches":"13358119","changeRate":"-176894","isNew":"0","trend":"fall","interfere":"0","srchCalcu":"13358119","eventid":"d7bee756dcb7c45198f50c2124118a56"},{"keyword":"\u5fae\u4fe1\u56de\u5e94\u8bbf\u5ba2\u8bb0\u5f55","searches":"13196379","changeRate":"4228306","isNew":"0","trend":"rise","interfere":"0","srchCalcu":"13196379","eventid":"19fc601528dfc5f4713246cff762f20c"},{"keyword":"\u536b\u89c6\u5143\u5bb5\u665a\u4f1a\u9635\u5bb9","searches":"12449481","changeRate":"-5174258","isNew":"0","trend":"fall","interfere":"0","srchCalcu":"12449481","eventid":"2d76da879fe912642bcea440c0d193ef"},{"keyword":"\u5357\u4eac\u94f6\u884c\u7ecf\u7406\u5931\u8054","searches":"12408471","changeRate":"410548","isNew":"0","trend":"rise","interfere":"0","srchCalcu":"12408471","eventid":"891d11b3e00491a9c3f440420857f650"},{"keyword":"\u6bd4\u65af\u5229\u7b7e\u7ea6\u5e7f\u4e1c","searches":"12349178","changeRate":"3664949","isNew":"0","trend":"rise","interfere":"0","srchCalcu":"12349178","eventid":"ba6ce87b04afaabe261deab82b739091"},{"keyword":"\u6731\u8fc5\u6b7b\u4ea1\u82ad\u6bd4\u7c89","searches":"11428188","changeRate":"-749432","isNew":"0","trend":"fall","interfere":"0","srchCalcu":"11428188","eventid":"0e7a82a1baacf6382330c63b2b838bf3"},{"keyword":"\u57c3\u53ca\u5f00\u7f57\u53d1\u751f\u7206\u70b8","searches":"11422301","changeRate":"3001574","isNew":"0","trend":"rise","interfere":"0","srchCalcu":"11422301","eventid":"9aa577bc6862fe5480efe3e1576219d6"},{"keyword":"\u6d41\u6d6a\u5730\u7403\u783440\u4ebf","searches":"11015439","changeRate":"-840598","isNew":"0","trend":"fall","interfere":"0","srchCalcu":"11015439","eventid":"1f58415561390d00799a1766594b4f77"},{"keyword":"\u6148\u6587\u4f20\u5a92\u5ba3\u5e03\u505c\u724c","searches":"10803367","changeRate":"-4669029","isNew":"0","trend":"fall","interfere":"0","srchCalcu":"10803367","eventid":"0f646be11a6266592f4ca34248dd00f3"},{"keyword":"\u90b1\u6cfd \u4e9a\u6d32\u4e4b\u661f\u5956","searches":"10720649","changeRate":"-3868686","isNew":"0","trend":"fall","interfere":"0","srchCalcu":"10720649","eventid":"4de20d376bd25c250761b9b5ba116aab"},{"keyword":"\u5927\u4f17\u70b9\u8bc4\u5373\u5c06\u6d88\u5931","searches":"10713029","changeRate":"1637174","isNew":"0","trend":"rise","interfere":"0","srchCalcu":"10713029","eventid":"19d00322b2bebf7f6ef6bdaf4240bc40"},{"keyword":"\u4f60\u8d54\u6211\u4e00\u9897\u7cd6\u5427","searches":"10709012","changeRate":"1645474","isNew":"0","trend":"rise","interfere":"0","srchCalcu":"10709012","eventid":"2857e636c38ecd0ecf0527e18d8051d8"},{"keyword":"\u9152\u5e97\u7761\u9192\u5934\u79c3\u4e86","searches":"10437163","changeRate":"-2275232","isNew":"1","trend":"fall","interfere":"0","srchCalcu":"10437163","eventid":"0fe7a1d8c101e05107ef1e60ed5b9ba3"},{"keyword":"\u54c8\u5c14\u6ee8\u8fce\u65e0\u966a\u513f\u7ae5","searches":"10124853","changeRate":"-11042672","isNew":"0","trend":"fall","interfere":"0","srchCalcu":"10124853","eventid":"454e53a2ef814edcc674f509ce751f02"},{"keyword":"\u6743\u5fd7\u9f99\u60bc\u5ff5\u8001\u4f5b\u7237","searches":"9938788","changeRate":"-2604266","isNew":"0","trend":"fall","interfere":"0","srchCalcu":"9938788","eventid":"6719abddec42f3436519a4f8c5fb2e6e"},{"keyword":"\u6c5f\u758f\u5f71\u673a\u573a\u5403\u8fa3\u6761","searches":"9864872","changeRate":"-2694516","isNew":"0","trend":"fall","interfere":"0","srchCalcu":"9864872","eventid":"38e85d00db9fa1aa4a06ed31525df15a"},{"keyword":"\u65af\u56fe\u52a0\u7279 \u6731\u5a77","searches":"9846580","changeRate":"-2460471","isNew":"0","trend":"fall","interfere":"0","srchCalcu":"9846580","eventid":"5904d3a07efeae0b436642277bad8562"},{"keyword":"\u6c11\u653f\u56de\u5e94\u798f\u5f69\u8150\u8d25","searches":"9774089","changeRate":"-3027739","isNew":"1","trend":"fall","interfere":"0","srchCalcu":"9774089","eventid":"f8a13a27bf344b3348fa5b0720f1f186"},{"keyword":"\u6c99\u6ea2\u8981\u51cf\u80a5","searches":"9702511","changeRate":"-11296817","isNew":"1","trend":"fall","interfere":"0","srchCalcu":"9702511","eventid":"97651953e68ace28954524a6772b2275"},{"keyword":"\u674e\u6613\u5cf0\u738b\u601d\u806a\u540c\u6e38","searches":"9231620","changeRate":"-3764989","isNew":"0","trend":"fall","interfere":"0","srchCalcu":"9231620","eventid":"379ab3ef1147bfbfd1720b28652042e2"},{"keyword":"\u66fc\u57ce\u6536\u8d2d\u56db\u5ddd\u4e5d\u725b","searches":"9224074","changeRate":"-4091124","isNew":"0","trend":"fall","interfere":"0","srchCalcu":"9224074","eventid":"cd2a91d4319348cf630bbb62713ce09c"},{"keyword":"\u6e38\u620f\u7248\u53f7\u7533\u62a5\u6682\u505c","searches":"9177149","changeRate":"-2298282","isNew":"0","trend":"fall","interfere":"0","srchCalcu":"9177149","eventid":"eee3468e910401516a38e4a59efc9fa6"},{"keyword":"\u652f\u4ed8\u5b9d\u8fd8\u6b3e\u6536\u8d39","searches":"9102370","changeRate":"-1638172","isNew":"0","trend":"fall","interfere":"0","srchCalcu":"9102370","eventid":"fdb6e6e7bef8a985114cd7ffbec6650d"},{"keyword":"\u5e7f\u897f\u96a7\u9053\u5927\u5df4\u8f66\u7978","searches":"8924060","changeRate":"-1400614","isNew":"1","trend":"fall","interfere":"0","srchCalcu":"8924060","eventid":"5fb2516320efd9e3435f3ef745e21520"},{"keyword":"\u6559\u80b2\u90e8 \u6821\u8f66\u81ea\u67e5","searches":"8566681","changeRate":"-1347149","isNew":"1","trend":"fall","interfere":"0","srchCalcu":"8566681","eventid":"74b3c84a952b8fbdaf3330638716226b"},{"keyword":"\u9648\u610f\u6db5\u6253\u7ffb\u6bcd\u4e73","searches":"8393666","changeRate":"-1869065","isNew":"1","trend":"fall","interfere":"0","srchCalcu":"8393666","eventid":"ff1027d990155a16d3f7d0fc7cc0b25d"},{"keyword":"\u8d85\u7ea7\u676f\u540d\u5355\u516c\u5e03","searches":"8301306","changeRate":"-1833422","isNew":"1","trend":"fall","interfere":"0","srchCalcu":"8301306","eventid":"782448b297587bb81d5ba9fa2ea2e3ac"},{"keyword":"\u5468\u6770\u4f26\u70b9\u8d5e\u65b0\u4e13\u8f91","searches":"8235623","changeRate":"-1430671","isNew":"1","trend":"fall","interfere":"0","srchCalcu":"8235623","eventid":"6db009e29dc84363ea8a5ee1a6812954"},{"keyword":"\u6c5f\u6cb9\u592a\u767d\u4f24\u4eba\u6848","searches":"8229590","changeRate":"-1553508","isNew":"1","trend":"fall","interfere":"0","srchCalcu":"8229590","eventid":"469e03c932e9c3b229104db96b402807"},{"keyword":"\u5168\u56fd\u52b3\u6a21\u674e\u658c\u75c5\u901d","searches":"7948961","changeRate":"332124","isNew":"0","trend":"rise","interfere":"0","srchCalcu":"7948961","eventid":"c1e2d1b338d2f11ace9ec09f7158a9b0"},{"keyword":"\u6797\u5fd7\u73b2 \u4ea4\u53cb\u8f6f\u4ef6","searches":"7807259","changeRate":"-175449","isNew":"0","trend":"fall","interfere":"0","srchCalcu":"7807259","eventid":"c5ac52c32a4af75155878ed85dad6319"},{"keyword":"\u5434\u9752\u5cf0\u6f84\u6e05\u89e3\u6563","searches":"7802561","changeRate":"731228","isNew":"0","trend":"rise","interfere":"0","srchCalcu":"7802561","eventid":"b765613682f690a3e3c8471f1553aedd"},{"keyword":"\u6545\u5bab\u706f\u5149\u79c0\u672a\u53d6\u6d88","searches":"7789452","changeRate":"-507437","isNew":"0","trend":"fall","interfere":"0","srchCalcu":"7789452","eventid":"c3e2bf6ca2a52114b6babed1a6153359"},{"keyword":"\u6d41\u6d6a\u5730\u7403\u5b98\u65b9\u8f9f\u8c23","searches":"7733615","changeRate":"-532434","isNew":"0","trend":"fall","interfere":"0","srchCalcu":"7733615","eventid":"0a4bd6ef470a44f216d7973a0f566bc3"},{"keyword":"\u7f8e\u7684\u5408\u5e76\u5c0f\u5929\u9e45","searches":"7188323","changeRate":"-1043156","isNew":"0","trend":"fall","interfere":"0","srchCalcu":"7188323","eventid":"0e77583ead4cf5450316c55b593fdd3d"},{"keyword":"\u53f0\u5357\u5927\u697c\u5012\u584c\u6848","searches":"7130212","changeRate":"-9059464","isNew":"1","trend":"fall","interfere":"0","srchCalcu":"7130212","eventid":"733be1773b3111381c9fc6e636b81c02"},{"keyword":"\u595a\u68a6\u7476\u5de5\u4f5c\u4f24\u75d5\u7167","searches":"7122361","changeRate":"-8617930","isNew":"1","trend":"fall","interfere":"0","srchCalcu":"7122361","eventid":"adac95c0dbb683f7bf6070708fa1926b"},{"keyword":"\u5b89\u5fbd\u961c\u9633\u53d6\u6d88\u9650\u4ef7","searches":"7096307","changeRate":"-1085572","isNew":"0","trend":"fall","interfere":"0","srchCalcu":"7096307","eventid":"389949c8d62820123f9bc283ab48b55f"},{"keyword":"\u6cf3\u88c5\u7167\u88ab\u53d1\u5de5\u4f5c\u7fa4","searches":"7085294","changeRate":"-1306614","isNew":"0","trend":"fall","interfere":"0","srchCalcu":"7085294","eventid":"e4fc9c57d33134a3aeb72faa6787693f"}]
    	});
    });
}();
!function(){var F = (window.__IKNOW_GLOBAL__ || window).F;var require = (window.__IKNOW_GLOBAL__ || window).require;    require.async(['common:widget/search-box-new/search-box-new']);
}();
!function(){var F = (window.__IKNOW_GLOBAL__ || window).F;var require = (window.__IKNOW_GLOBAL__ || window).require;    require.async(['question-new:widget/header-title/header-title.es'], function (HeaderTitle) {
        var headerTitle = new HeaderTitle();
    });
}();
!function(){var F = (window.__IKNOW_GLOBAL__ || window).F;var require = (window.__IKNOW_GLOBAL__ || window).require;    require.async(['common:widget/menu/menu'], function(menu){
    	menu.init();
    });
    // 导航menu可用时间打点
    alog && alog('speed.set', 'c_menu', +new Date); alog.fire && alog.fire("mark");
}();
!function(){var F = (window.__IKNOW_GLOBAL__ || window).F;var require = (window.__IKNOW_GLOBAL__ || window).require;        F.context('feedback', '1');
    F.context('springActivityShow', '0')
    require.async(['question-new:widget/ask/replyer/replyer']);
}();
!function(){var F = (window.__IKNOW_GLOBAL__ || window).F;var require = (window.__IKNOW_GLOBAL__ || window).require;    require.async(['question-new:widget/ask/ask'], function(ask){
        ask.init({
            askContentType: 'default',
            timely: {
                isNeed: '',
                leftTime: '-100868236'
            }
        });
    });
    require.async(['question-new:widget/ask/pc-exp/ask-img']);
}();
!function(){var F = (window.__IKNOW_GLOBAL__ || window).F;var require = (window.__IKNOW_GLOBAL__ || window).require;    require.async(['question-new:widget/replyer-all/replyer-all.es'], function (Replyer) {
        var replyer2383726729 = new Replyer('#wgt-replyer-all-2383726729');
    });
}();
!function(){var F = (window.__IKNOW_GLOBAL__ || window).F;var require = (window.__IKNOW_GLOBAL__ || window).require;    require.async(['question-new:widget/value-comment/value-comment'],function(vc){
        vc.init('2383726729','0', '', 'best');
    });
}();
!function(){var F = (window.__IKNOW_GLOBAL__ || window).F;var require = (window.__IKNOW_GLOBAL__ || window).require;    require.async(['question-new:widget/newbest/newbest-init','common:widget/lib/jquery/jquery','common:widget/js/util/log/log'], function(newbest, $, log) {
        newbest.init();

        if ($('.wgt-best .best-text .answer-expand').size() != 0) {
            log.addKey({
                answer_expand_show: 1
            });
        }
        $(".wgt-best .best-text").on('click', ".answer-expand", function(e) {
            $(this).hide();
            $(".wgt-best .best-text .answer-expand-content").hide();
            $(".wgt-best .best-text .answer-collapse-content").show();
            $(".wgt-best .best-text .answer-collapse").css('display', 'block');
            log.send({page:'question',pos:'qb-detail-expand-btn-click'});
        });
        $(".wgt-best .best-text").on('click', ".answer-collapse", function(e) {
            $(this).hide();
            $(".wgt-best .best-text .answer-collapse-content").hide();
            $(".wgt-best .best-text .answer-expand-content").show();
            $(".wgt-best .best-text .answer-expand").show();
        });
    });
}();
!function(){var F = (window.__IKNOW_GLOBAL__ || window).F;var require = (window.__IKNOW_GLOBAL__ || window).require;    require.async(['question-new:widget/related/related'], function(rel){
        rel({
            isRelatedLog: true,
                    });
    });
}();
!function(){var F = (window.__IKNOW_GLOBAL__ || window).F;var require = (window.__IKNOW_GLOBAL__ || window).require;        require.async(['common:widget/js/util/log/log'], function(log) {
            // 展现相关问题的PV，ps：不知道以前怎么这么写，related_search_show和网友都在找参数是一样的？
            log.addKey({related_search_show: '1'});
            // 为您推荐展现pv
            log.addKey({bottom_union: '1'});
        });
    }();
!function(){var F = (window.__IKNOW_GLOBAL__ || window).F;var require = (window.__IKNOW_GLOBAL__ || window).require;    require.async(['question-new:widget/ad-right/ad-right']);
}();
!function(){var F = (window.__IKNOW_GLOBAL__ || window).F;var require = (window.__IKNOW_GLOBAL__ || window).require;    require.async(['common:widget/js/util/tangram/tangram','question-new:widget/link-union/link-union'], function($, LU) {
        LU.init({
            newbest: {"2383726729":{"id":2383726729,"qid":"649247327024278045","encode_qid":"649247327024278045","threadId":"9534906917","deleted":0,"isBest":1,"isHighQuality":0,"isExcellent":0,"isRecommend":0,"isSpecial":0,"c_timestamp":1449884570,"createTime":"2015-12-12","recommendCanceled":0,"hasImage":0,"hasComment":0,"isFromHelp":0,"isFromWap":0,"valueNum":2,"valueBadNum":7,"refContent":"","content":null,"contentText":null,"mapUrl":"","contentRich":null,"contentRichOrig":null,"imgUrl":null,"fileName":[],"fileAttrs":[],"bit_pack":{"is_recommend":0,"wap_flag":0,"is_pic_contained":0,"media_flag":0,"help_flag":0,"anonymous":0,"is_really_anonymous":0,"level_new":1,"comment_flag":0,"in_mis":0,"auto_recommend":0,"content_rich_flag":1,"prior_flag":1,"hidden_flag":0,"rec_canceled_flag":0,"mis_flag":0,"file_flag":0,"read_flag":0,"is_challenge":0,"ikaudio_flag":0,"mavin_flag":0,"authentic_state":0,"is_compulsory_best":0,"dynamic_stick_flag":0},"ext_pack":{"reply_entry":"qb_ihome_tag","mode_qtype":0,"mode_begintime":0,"op_uid":0,"anony_good_value":2,"reason_2_2":1,"recTime":1511275697,"anony_bad_value":3,"reason_2_1":1},"import_id":0,"uscore":{"level":14,"sublevel":0,"good_rate":85,"icon_sysno":4,"sex":1},"inMis":0,"isHard":0,"value_rank":1005376,"next_rid":"0","pre_rid":"0","title":null,"applyStatus":{"applyExcType":4,"applyNum":0},"area":1,"user":{"uid":32118001,"name":"zzl1314520","imId":"f1147a7a6c31333134353230ea01","isAnonymous":0,"isUnLogin":0,"isCurrentUser":0,"ipNum":1458908533,"isNoUserName":0,"iconType":6,"sex":1,"isAuth":0,"isExpert":0,"isExpertImport":0,"isUserAdmin":0,"isFamous":0,"isMaster":0,"isFromTorch":0,"isOpenApp":0,"encodeUid":"f1144069236f25705e79ea01","gradeIndex":17,"grAnswerNum":8288,"goodRate":92.769196328632,"carefield":[{"cid":761,"cname":null},{"cid":96,"cname":null},{"cid":206,"cname":null},{"cid":1284,"cname":"Windows"},{"cid":1097,"cname":null}],"userAdminType":1,"userAdminLevel":4,"userAdminTitle":null,"selfDefinedPhoto":1,"isAppAuth":0,"teamId":77777,"teamName":null,"teamUrl":"http:\/\/a.hiphotos.baidu.com\/album\/s%3D1100%3Bq%3D90\/sign=fccc831334a85edffe8cfa2279643252\/b999a9014c086e065d68d50802087bf40bd1cbb5.jpg","isFromTeam":1,"showInfo":{"imgUrl":"http:\/\/himg.bdimg.com\/sys\/portrait\/item\/f1147a7a6c31333134353230ea01.jpg","type":4,"slogan":null,"name":"zzl1314520","siteUrl":"https:\/\/zhidao.baidu.com\/usercenter?uid=f1144069236f25705e79ea01&teamType=1","showName":null,"showImg":null,"level":null},"praiseNum":20185},"hasEvaluated":0,"evaluatedType":0,"oldQid":1078189433,"relateWords":[],"type":"dynamicBest"}},
            recommend: null,
            answerList: null,
            sid: '',
            askQid: '649247327024278045'
        });
        $.getScript("https://gh.bdstatic.com/static/gh/js/ll/m_word.js");
    });
}();
!function(){var F = (window.__IKNOW_GLOBAL__ || window).F;var require = (window.__IKNOW_GLOBAL__ || window).require;require.async(['question-new:widget/image-scale/image-scale'], function(imageScale){
    imageScale.init('.ikqb_img');
});
}();
!function(){var F = (window.__IKNOW_GLOBAL__ || window).F;var require = (window.__IKNOW_GLOBAL__ || window).require;require.async(['question-new:widget/mask/mask.es'], function(mask) {
    mask.init();
});
}();
!function(){var F = (window.__IKNOW_GLOBAL__ || window).F;var require = (window.__IKNOW_GLOBAL__ || window).require;require.async(['question-new:widget/view/accusation/accusation.es'], function(accusation) {
    accusation.init();
});
}();
!function(){var F = (window.__IKNOW_GLOBAL__ || window).F;var require = (window.__IKNOW_GLOBAL__ || window).require;    require('common:widget/js/logic/ie-prompt/ie-prompt');
    require.async(['common:widget/footer-new/footer-new'], function(footer) {
        footer.init();
    });
}();
!function(){var F = (window.__IKNOW_GLOBAL__ || window).F;var require = (window.__IKNOW_GLOBAL__ || window).require;require.async(['common:widget/js/util/tangram/tangram','common:widget/js/util/log/log','common:widget/js/util/event/event','common:widget/js/ui/dialog/dialog','question-new:widget/js/file/file','question-new:widget/js/video/video','common:widget/js/ui/tip/tip','common:widget/js/util/https/https','common:widget/js/util/store/store','question-new:widget/mavin-statistics/mavin-statistics','question-new:widget/js/send-more/send-more.es','question-new:widget/dom-ready/dom-ready'], function($, log, ec, Dialog, File, Video, Tip, https, store, mavinStatistics, sendMore, domReady) {
        // 页面类型
        F.context('pageType', 'view');

        // 打点QB页用户可操作时间
        alog && alog('speed.set', 'drt', +new Date);
                        require.async(['question-new:widget/js/accuse/accuse'], function(accuse){
                    accuse.init({ target: '#wgt-ask .accuse-area', response: 'wgt-ask', accusetype: 0 });
                    if (!$.isEmptyObject(F.context('answers'))){

                        accuse.init({ target: '.wgt-best .accuse-area',	response: 'wgt-best', accusetype: 1 });
                        accuse.init({ target: '#wgt-answers .accuse-area', response: 'answer', accusetype: 1 });
                    }
                });
                            require.async(['question-new:widget/js/submitjump/submitjump'],function(submitjump){
                submitjump.init();
            });
    		                            if (F.context('user')['internalAdmin']) {
                    require.async(['question-new:widget/js/admin/officialAdmin/officialAdmin'], function(A){
                        A.init();
                   });
                }
                if (F.context('user')['isUserAdmin']=='1') {
                    require.async(['question-new:widget/js/admin/userAdmin/userAdmin'], function(A){
                        A.init();
                   });
                }
                require.async(['common:widget/js/logic/complain/complain'], function(complain){
                    $('.complain-deleted').click(function(ev){
                        ev.preventDefault();
                        complain(F.context('page')['qid'], $(this).attr('data'));
                    });
                });

            
                
            log.addKey({
                qbleftdown: $('.qbleftdown').find('li').size(),
                qbrightdown:$('.qbrightdown').find('.r').size()
            });
            if ( $( '.qbleftdown a' ).size() ) {
                log.addKey({
                    ec_ads: '2',
                    ec_ads_count: $('.qbleftdown').find('a.ec_ad_title, span.ec_qad_title, a.EC_ad_title').size()
                });
                $('.qbleftdown a').click(function(){
                    var $parent = $( this ).parent();
                    if ( this.id || this.className == 'EC_ad_title'
                        || $(this).hasClass('ec_ik220_adtitle')
                        || $(this).hasClass('ec_ik220_desc')
                        || $parent.hasClass( 'EC_ads_answer' )
                        || this.className == 'EC_ads_listurl'
                        || this.className == 'ec_ad_title'
                        || $parent.hasClass('ec_qad_title')
                        || $parent.hasClass('ec_qad_answerer') ) {
                        log.send({
                            type: 2014,
                            evtType: 'click',
                            pos: 'ec_ads'
                        });
                    }
                });
            }
            require.async(['question-new:widget/js/card/card'], function(card){
                $('.user-name').each(function(index, item){
                    new card({ target: item, type: 'normal' });
                });
                $('.mavin-name').each(function(index, item){
                    new card({target: item, type: 'mavin' });
                });
                $('.opendev-name').each(function(index, item){
                    new card({target: item, type: 'opendev'});
                });
                $('.uadmin-a').each(function(index, item) {
                    new card({target: item, type: 'uadminIcon'});
                });
                $('.business-name').each(function(index, item){
                    new card({target: item, type: 'business' });
                });
                $('.quality-business-name').each(function (index, item) {
                    new card({target: item, type: 'qbusiness'});
                });
            });
            $('.replyask-extandup-btn').click(function (e) {
                var flag = $(this).find('.replyask-extandup-txt').text().indexOf('更多追问追答') != -1;
                $(this).find('.replyask-extandup-txt').html(flag ? '收起追问追答' : '更多追问追答');
                $(this).find('.iknow-icons').html(flag ? '&#xe772;' : '&#xe771;');
                var dl = $(this).closest('.replyask-box').find('.replyask');
                flag ? dl.css('display', 'block') : dl.not('[data-reset]').css('display', 'none');
            });
            $('.replyask-box').each(function (index, item) {
                $(item).find('.ikqb_img_alink').remove();
                if ($(item).find('.replyask-shrink').size() == 0) {
                    $(item).find('.ask-supply-line').last().hide();
                }
            });
            if($('.thunder-wrap').size()){
                require.async(['question-new:widget/js/thunder/thunder'], function(thunder){
                    $(function(){
                        thunder.init();
                    });
                });
            }
            $.each(F.context('answers'), function(index, item){
                if (item.ext_pack && item.ext_pack.team_id) {
                    log.send({
                        teamId: item.ext_pack.team_id,
                        excellentReverse: item.ext_pack.excellent_reverse ? 1 : 0,
                        isExcellent: +item.ext_pack.excellent_aduit_pass === 1 ? 1 : 0
                    });
                }
            });
            mavinStatistics.scan();
            if($('ikaudio').size()){
                log.addKey({
                    'audio' : 1
                });

                require.async(['question-new:widget/js/audio/audio'], function(audio){
                    audio.init();
                });
            }
            require.async(['question-new:widget/js/comment/comment'], function(comm){
                comm.getCount();
            });
            $('.recommend-text, .best-text, .answer-text, .replyask-content').each(function(i, answerText){
                $(answerText).find('pre[t="code"]').each(function(i, pre){
                    var loadSyntax = function(){
                        SyntaxHighlighter(pre);
                    };

                    $(pre).text($(pre).html($(pre).html().replace(/<br\s*\/?>/ig, '##IK_LINEBREAK##')).text().split('##IK_LINEBREAK##').join('\n'));

                    $(pre).addClass('brush:'+$(pre).attr('l')+';toolbar:false;');
                    if (window.SyntaxHighlighter) {
                        SyntaxHighlighter.highlight(pre);
                        $(answerText).find('.syntaxhighlighter .code .line').each(function(index, line){
                            $(answerText).find('.syntaxhighlighter .gutter .line').eq(index).height($(line).height());
                        });
                    } else {
                        var sioUrl = https.autoTrans('http://img.iknow.bdimg.com/libs/SyntaxHighlighter/shCore.min.js');
                        $.sio(sioUrl).callByBrowser(function(){
                            SyntaxHighlighter.defaults['quick-code'] = false;
                            SyntaxHighlighter.config.stripBrs = true;
                            SyntaxHighlighter.highlight(pre);
                            $(answerText).find('.syntaxhighlighter .code .line').each(function(index, line){
                                $(answerText).find('.syntaxhighlighter .gutter .line').eq(index).height($(line).height());
                            });
                        });
                    }
                });

                $(answerText).find('ikvideo').each(function(i, video){
                    var id = 'VIDEO_' + $.id();
                    var src = $(video).attr('src');
                    var poster = $(video).attr('img') || 'https://gss0.bdstatic.com/7051cy89QMgCncy6lo7D0j9wexYrbOWh7c50/yt/hhr_b.png';
                    var sid;
                    var width = $(answerText).width();
                    var height = width * 0.563;

                    // 如果为mp4资源
                    if (/^(http|https):\/\/.+\.mp4$/.test(src)) {
                        var html = '<video '
                            + 'class="ik-video" '
                            + 'controls '
                            + 'style="font-size: 18px"'
                            + 'poster="' + poster + '"'
                            + 'width="' + width
                            + '" height="' + height + '" '
                            + '<source src="' + src
                            + '" type="video/mp4">'
                            + '<p class="video-no-js">'
                                + '播放视频需要启用 JavaScript，推荐使用<a href="http://videojs.com/html5-video-support/" target="_blank">支持HTML5</a>的浏览器访问。</p>'
                            + '</video>';
                        $(video).after(html);
                        return;
                    }
                    var container = $('<div/>').attr('id', id).insertBefore($(video));
                    if (src.indexOf('v.baidu.com') > -1 ) {
                        container.html('<iframe src="'+src+'" frameborder=0 scrolling="no" width="'+$(video).attr('width')+'" height="'+$(video).attr('height')+'" class="'+$(video).attr('class')+'"></iframe>');
                        return;
                    }
                    if (src.indexOf('youku') > -1 && (sid = src.match(/sid\/(.*?)[\?\/]/))) {
                        if (sid[1]) {
                            src = 'http://player.youku.com/player.php/sid/'+sid[1]+'/v.swf';
                        }
                    }

                    container.html('<embed src="'+src+'" allowFullScreen="true" quality="high" width="'+$(video).attr('width')+'" height="'+$(video).attr('height')+'" align="'+$(video).attr('align')+'" allowScriptAccess="never" type="application/x-shockwave-flash"></embed>');
                });
            });

                var scrollLogged = false;
        var middleLogged = false;
        var bottomLogged = false;
        $(document).on('scroll', function () {
            var docViewTop = $(window).scrollTop();
            var docViewBottom = docViewTop + $(window).height();

            var $cmsScroll = $('#cms-scroll');

            if ($cmsScroll.length > 0) {
                var scrollElemTop = $cmsScroll.offset().top;

                if (!scrollLogged && (scrollElemTop > docViewTop && scrollElemTop < docViewBottom)) {
                    scrollLogged = true;
                    log.send({
                        area: 'quesion_right_scoll'
                    });
                }
            }

            var $cmsCompany = $('#cms-company');

            if ($cmsScroll.length > 0) {
                var middleElemTop = $cmsScroll.offset().top;

                if (!middleLogged && (middleElemTop > docViewTop && middleElemTop < docViewBottom)) {
                    middleLogged = true;
                    log.send({
                        area: 'question_middle_ads'
                    });
                }
            }

            var $knowledge = $('.knowledge');

            if ($knowledge.length > 0) {
                var bottomElemTop = $knowledge.offset().top;

                if (!bottomLogged && (bottomElemTop > docViewTop && bottomElemTop < docViewBottom)) {
                    bottomLogged = true;
                    log.send({
                        area: 'question_knowledge'
                    });
                }
            }
        });
        require.async(['common:widget/js/ui/lazyload/lazyload'], function(lazyload){
            $('.wgt-replyer-best .avatar-48 a, .wgt-replyer-best .avatar-66 a, .wgt-replyer-special .avatar-66 a,.wgt-replyer-best .avatar-69 a, .wgt-replyer-best .avatar-70 a, .wgt-replyer-best .avatar-66 a, #cms-company a').lazyload();
        });
        $('.ikqb-map').each(function(index, item) {
            var ifreamObj = $("<iframe/>").attr({
                frameborder: '0'
                ,width:"430"
                ,height:"310"
                ,style: 'display:none;'
                ,className: 'answer-map'
            }),
            tmpsrc = $(item).attr("map") || $(item).attr("src");
            
            var iframeSrc = !/ueditor\/dialogs\/map/i.test(tmpsrc) ? '//zhidao.baidu.com/html/map' + tmpsrc.replace(/^iknow/i, '') : tmpsrc;

            ifreamObj.attr('src', iframeSrc);

            $(item).before(ifreamObj).remove();
            ifreamObj.after(
                $("<p/>").addClass('f-aid').html("本数据来源于百度地图，最终结果以百度地图最新数据为准。")
            ).show();
        });
        if ($('video.edui-faked-video').size() > 0) {
            Video.init();
        }
        require.async(['common:widget/js/logic/ut/ut'], function(UT){
            UT.start(['userbar','header','wgt-ask','answer-editor','wgt-answers']);
        });

        File.init();

        logPV();
        if (F.context('user')['isUserAdmin'] != '1'){
            require.async(['question-new:widget/js/select-search/select-search'], function(A){
                A.init();
            });
        }
        log.init({key:2014, query: 'body',action:'click'});
        function logPV(){
            var logOptions = {
                module: 'question',
                page: 'question',
                screen: parseInt($('body').height()/$(window).height()),
                cid: F.context('page')['cid'],
                view: F.context('page').isView,
                cidTop: F.context('page')['cidTop'],
                cidMid: F.context('page')['cidMid'],
                refer: document.referrer,
                userStatus:   1 ,
                adsEids: F.context('page').adsAll.adsEids.join(','),
                create_time: F.context('page').createTime || 0,
                asker_uid: F.context('page').uid || 0,
                viewer_uid: F.context('user').uid || 0,
                isNewPcQbPage: F.context('pageType') === 'view' ? 1 : 0,
                rand: (+new Date()) + Math.random().toString().substring(2),
                entry: $.url.getQueryValue(location.href, 'entry'),
                pageType: 'view',
                isNewTpl: 1
            };

            log.addKey({
                evaSampling: 266,
                qid: F.context('page')['qid']
            });

            if (F.context('page').relateQids) {
                logOptions.relateQids = F.context('page').relateQids;
            }

            if (F.context('page').relateTopicQids) {
                logOptions.relateTopicQids = F.context('page').relateTopicQids;
            }
            if ($('.classinfo').length) {
                log.addKey({'classinfo': 1});
            }
            var uadminIcon = $('.uadmin-a');
            var uadminIconSize = uadminIcon.length;
            if (uadminIconSize) {
                logOptions.uadminIconNum = uadminIconSize;
            }

            log.addKey(logOptions);
        }
        var grid68  = $('.qb-content'),
            qid = F.context('page')['qid'];
        $.each({
            'qb-content'            : '.q-content a@',
            'qb-supply-content'     : '.q-supply-content a@',
            'qb-best-text'          : '.wgt-best .best-text a@',
            'qb-special-bast-text'  : '.wgt-special .best-text a@',
            'qb-recommend-text'     : '.wgt-recommend .recommend-text a@',
            'qb-answer-text'        : '.answer-text a@',
            'qb-replyask-ask'       : '.ask+dd a',
            'qb-replyask-reply'     : '.reply+dd a',
            'qb-best-thank'         : '.thank pre a',
            'qb-answer-refer'       : '.answer-refer a'
        }, function(key, val){
            var aLink = grid68.find( val.replace(/\@$/, '[title!="点击查看大图"]') )
                        .not('.app-keyword,.inner-link')
                        .filter(function(){
                            return this.getAttribute('href').match(/^http/i) && this.innerHTML != '' && !$(this).closest('.ed2k-wrap').size() && !$(this).closest('.thunder-wrap').size()
                        });
            aLink.click(function(){
                log.send({
                    'type'  : 2014,
                    'page'  : 'question',
                    'qid'   : qid,
                    'area'  : key,
                    'action': 'linkClick',
                    'text'  : this.getAttribute('href'),
                    'host'  : this.getAttribute('href').split('/')[2]
                });
            });
            grid68.find( val.replace(/\@$/, '') ).attr('rel', 'nofollow noopener');
        });

                            $(document).on('click', '.ikqb_img_alink', function(evt){
                if($.browser.msie&&$.browser.version==6){
                    return false;
                }
                var imgTarget = $(this).find('img'),
                    imgBigSrc = $(this).attr('href'),
                    maxWidth = $(this).parent('p').outerWidth(),
                    imgSmallSrc = imgTarget.attr('esrc'),
                    sourceWidth = imgTarget.width(),
                    sourceHeight = imgTarget.height();

                if(imgTarget.hasClass('img_show')){
                    imgTarget.attr('src',imgBigSrc);
                    if(!imgTarget.hasClass('ikqb_img')){
                        imgTarget.removeClass('ikqb_img');
                        imgTarget.animate({
                            'width':'100%'
                        },500);
                    }else{
                        imgTarget.animate({
                            'maxWidth':'500px',
                            'maxHeight':'340px'
                        },500);
                    }
                    imgTarget.removeClass('img_show');
                }else{
                    $(this).append('<i class="ikqb_img_loading"></i>');
                    var bigImg = new Image();
                    bigImg.onload = function(){
                        imgTarget.attr('src',imgBigSrc);
                        if(sourceWidth == bigImg.width){
                            imgTarget.removeClass('ikqb_img');
                            imgTarget.animate({
                                'width':'120%'
                            },500);
                        }else{
                            imgTarget.animate({
                                'maxWidth':bigImg.width>maxWidth?maxWidth:bigImg.width,
                                'maxHeight':bigImg.height
                            },500);
                        }
                        imgTarget.addClass('img_show');
                        $('.ikqb_img_loading').remove();
                    }
                    bigImg.src = imgBigSrc;
                }
                evt.preventDefault();
            });
        
    $(window).load(function () {
        // 图片居中
        $('.wgt-best .best-text').add('#wgt-answers .answer-text').add('.wgt-myanswer .answer-text').find('.ikqb_img_alink').each(function (index, item) {
            var $item = $(item);
            var $img = $item.find('img');
            if ($img.size()) {
                $item.css({
                    display: 'block',
                    width: $img.width(),
                    margin: '0 auto'
                });
            }
        });
        if (F.context('pageType') === 'asker' && !Number(F.context('page')['delAsk'])) {
            sendMore.default.init();
        }
        ec.fire('pageLoaded');
    });
    var loc_ans = $.url.getQueryValue(location.href, 'loc_ans');
    if(!loc_ans) {
        var myAnswerList = $('.wgt-best .answer-mine, .wgt-recommend .answer-mine, .wgt-special .answer-mine'),
            myAnswer = null;
        if(myAnswerList.size()){
            myAnswer = myAnswerList.first();
            setTimeout(function(){
                $(document).scrollTop(myAnswer.offset().top - 10);
            }, 200);
        // 保证其它回答翻页时定位到首个回答的顶部
        } else if (location.hash === '#wgt-answers' && $('#wgt-answers').size()) {
            // 防止刷新时重复定位
            try {
                if (document.referrer === sessionStorage.getItem('sessionPreReferrer')) {
                    return;
                } else {
                    sessionStorage.setItem('sessionPreReferrer', document.referrer);
                }
            }
            catch (e) {}
            // 顺序要在答案折叠后面，以免影响计算
            $(window).on('load', function () {
                // 变为异步排除其他定位干扰
                setTimeout(function () {
                    var top = $('#wgt-answers').offset().top;
                    // 主要是排除吸顶头部的干扰防止覆盖住回答顶部
                    var $title = $('.wgt-ask .ask-title');
                    var diff = top > $title.offset().top + $title.height() - 50 ? 55 : 0;
                    $(window).scrollTop(top - diff);
                }, 0)
            })
        }
    }else {
        var locAnswerList = $('.wgt-best .answer, .wgt-recommend .answer, .wgt-special .answer'),
            locAnswer = null;
        locAnswerList.each(function(index, item) {
            if($(item).attr("id").indexOf(loc_ans) != -1) {
                locAnswer = $(item);
            }
        });
        if(locAnswer) {
            setTimeout(function(){
                $(document).scrollTop(locAnswer.parent().offset().top - 10);
            }, 200);
        }
    }

    domReady.init();
});
}();
!function(){var F = (window.__IKNOW_GLOBAL__ || window).F;var require = (window.__IKNOW_GLOBAL__ || window).require;								                				require.async(['common:widget/js/logic/dom-ready/dom-ready'], function(D){ D.init([]) });
            }();
!function(){var F = (window.__IKNOW_GLOBAL__ || window).F;var require = (window.__IKNOW_GLOBAL__ || window).require;        require.async(["common:widget/js/logic/duration/duration"],function(dur){
            dur.init();
        });
    }();
</script>
<script type="text/javascript">
    require.async(['common:widget/lib/jquery/jquery'], function ($) {
        if (!/chrome|firefox|safari|msie 10|rsv:11|msie [89]/i.test(navigator.userAgent)) {
            return;
        }

        window.BaiduHttps = window.BaiduHttps || {};
        window.BaiduHttps.callbacks = function (data) {
            if (data && data.s === 0) {
                window.supportHttps = 1;
                setTimeout(function () {
                    $('a[href^="http://www.baidu.com/s?"]').each(function (index, item) {
                        var link = $(item).attr('href');
                        if (~link.indexOf('?wd=') || ~link.indexOf('&wd=')) {
                            link = link.replace(/^http/, 'https');
                            $(item).attr('href', link);
                        }
                    });
                }, 2000);
            }
        };

        var script = document.createElement('script');
        script.type = 'text/javascript';
        script.src = 'https://www.baidu.com/con?from=zhidao';
        document.body.appendChild(script);
    });
</script>


</html>
