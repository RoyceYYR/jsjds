
$(document).ready(function() {
	$("#btn").click(function() {
		$.ajax({
			url: "/index/index/index2"
			//url:"D:/thinkphp_5.0.24_with_extend/application/index/controller/Index.php"
			//url:"D:/thinkphp_5.0.24_with_extend/application/api/controller/Index.php/index",
			type: "POST",
			data: {username:$("#input").val()}
			success: function(data) {
			 if(data == "0") 
			 	{ window.location.href = "admin/edit/editget" } 
			 else { alert("请检查用户名和密码!") } }, 
			error: function() { alert("服务器出错了") }

		});
	});
});