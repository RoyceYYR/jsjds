<?php
namespace app\index\controller;
use think\Controller;
use app\api\model\User;
use think\view;
use think\Db;
use think\Session;
//header('Access-Control-Allow-Origin:'.$_SERVER["HTTP_ORIGIN"]);
header("Access-Control-Allow-Origin:*");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS, PUT, DELETE");
header('Access-Control-Allow-Headers:x-requested-with,content-type');
header("Access-Control-Allow-Credentials: true");
header('Content-type: text/html;charset=GB2312');

class Index extends Controller
{
    public function index()
    {    
         
    }
    
    public function pdetail()
    {    
        $data=input();
        $username=$data['un'];
        //$username="Nakajima";
        $gender=$data['gender'];
        $bfz=$data['value'];
        $bfz=$bfz[0].$bfz[1].$bfz[2].$bfz[3].$bfz[4].$bfz[5].$bfz[6].$bfz[7].$bfz[8];
        $birth=$data['date'];
        $frist = substr( $birth,0,4);
        $frist=2000-$frist+19;
        $res=mysqli_connect("localhost","root","","ge"); 
        $sql1="UPDATE userinfo SET gender='{$gender}' WHERE nicknamesign_up='{$username}'";
        $qid=mysqli_query($res,$sql1);
        $sql1="UPDATE userinfo SET bfz='{$bfz}' WHERE nicknamesign_up='{$username}'";
        $qid=mysqli_query($res,$sql1);
        $sql1="UPDATE userinfo SET age='{$frist}' WHERE nicknamesign_up='{$username}'";
        $qid=mysqli_query($res,$sql1);
    }

    public function alert()
    {    
         $res=mysqli_connect("localhost","root","","ge"); 
         $sql1="SELECT alert FROM alert WHERE id=1";
         $qid=mysqli_query($res,$sql1);
         $row=mysqli_fetch_array($qid,MYSQL_NUM);
         echo $row[0];
    }
    
    public function slipdata()
    {    
         $data=input();
         $dt=file_get_contents('php://input');
         //$dt="Nakajima|1|1|1|1|1|1";
         //$dt=gettype($dt);
         $dt= explode('|', $dt);
         $user=$dt[0];
         $c = system("python C:/Users/Administrator/Desktop/fallSVC.py $dt[1] $dt[2] $dt[3] $dt[4] $dt[5] $dt[6]",$out);
         if(!($out[0])){
            $res=mysqli_connect("localhost","root","","ge"); 
            $sql1="UPDATE alert SET alert=1 WHERE id=1";
            $qid=mysqli_query($res,$sql1);

         }
    }
    
    public function familywatch()
    {    
         $data=input();
         //$fname="Kagawa";
         $fname=$data['fname'];
         $res=mysqli_connect("localhost","root","","ge"); 
         $sql1="SELECT familymemb FROM familymembinfo WHERE f_nicknamesign_up='{$fname}'";
         $qid=mysqli_query($res,$sql1);
         $row=mysqli_fetch_array($qid,MYSQL_NUM);
         echo $row[0];
    }
     //由家属账号查医生
    public function checkdoct()
    {
        $data=input();
        $uname=$data['un'];
        //$uname="Nakajima";
        $res=mysqli_connect("localhost","root","","ge"); 
        $sql1="SELECT yourdoctor FROM userinfo WHERE nicknamesign_up='{$uname}'";
        $qid=mysqli_query($res,$sql1);
        $row=mysqli_fetch_array($qid,MYSQL_NUM);

        $uname=$row[0];
        //$uname="656356768";
        $sql1="SELECT nicknamesign_up FROM doctorinfo WHERE doctorid='{$uname}'";
        $qid=mysqli_query($res,$sql1);
        $row=mysqli_fetch_array($qid,MYSQL_NUM);
        $sql1="SELECT emailsign_up FROM doctorinfo WHERE doctorid='{$uname}'";
        $qid=mysqli_query($res,$sql1);
        $row2=mysqli_fetch_array($qid,MYSQL_NUM);
        $sql1="SELECT doctorid FROM doctorinfo WHERE doctorid='{$uname}'";
        $qid=mysqli_query($res,$sql1);
        $row3=mysqli_fetch_array($qid,MYSQL_NUM);
        echo $row[0].'|'.$row2[0].'|'.$row3[0];
    }
     //家属界面查询病人
    public function familyandp()
    {    
         $data=input();
         //$fname="Kagawa";
         //$pname="nakajimabsdata";
         $pname=$data['pname']."bsdata";
         $res=mysqli_connect("localhost","root","","ge"); 
         $sql1="SELECT xbs FROM {$pname} order by id desc";
         $qid=mysqli_query($res,$sql1);
         $row=mysqli_fetch_array($qid,MYSQL_NUM);
         $pname=$data['pname'];
         //$pname="nakajima";
         $sql1="SELECT score FROM {$pname} order by id desc";
         $qid=mysqli_query($res,$sql1);
         $row2=mysqli_fetch_array($qid,MYSQL_NUM);
         $sql1="SELECT timeofslp FROM {$pname} order by id desc";
         $qid=mysqli_query($res,$sql1);
         $row3=mysqli_fetch_array($qid,MYSQL_NUM);
         $frist = substr( $row3[0],0,1);
         echo $row2[0]."|".$row[0]."|".$frist;    
     }

    public function createdataforbs()
	{   
		
		//dump(config('database'));
		$res=Db::connect();
		//$Model= User();
        //dump($res);
        $sql1="CREATE TABLE userinfo(
        userid int ,
        bs float   ,
        shijian char(20)  ,
        fan char(20),
        mealtm1 char(30),
        mealtm2 char(30),
        mealtm3 char(30),
        mealtm4 char(30),
        bsl float,
        bsh float,
        PRIMARY KEY(userid)
        )ENGINE = MyISAM  DEFAULT CHARSET = utf8mb4  AUTO_INCREMENT = 1;";
        $res->execute($sql1);
        //dump($list);

	}
    
    public function store_bsdata()
    {   $data = input();
        $xtime=$data['xtime'];
        //$xtime=9;
        $xwhen=$data['xwhen'];
        //$xwhen=9;
        $xbs=$data['xbs'];
        //$xbs=9;
        $nicknamesign_up=$data['username'];
        //$nicknamesign_up="Nakajima";
        $id_of_t=$nicknamesign_up."bsdata";
        $res=mysqli_connect("localhost","root","","ge"); 
        $sql1="INSERT INTO `{$id_of_t}` SET xtime='{$xtime}',xwhen='{$xwhen}',xbs='{$xbs}';";
        $qid=mysqli_query($res,$sql1);
    }

    public function store_rgdata()
    {   $data = input();
        $low=$data['low'];
        //low=9;
        $high=$data['high'];
        //$high=9;
        $nicknamesign_up=$data['username'];
        //$nicknamesign_up="Nakajima";
        $res=mysqli_connect("localhost","root","","ge"); 
        $sql1="SELECT userid FROM userinfo WHERE nicknamesign_up='{$nicknamesign_up}'";
        $qid=mysqli_query($res,$sql1);
        $row=mysqli_fetch_array($qid,MYSQL_NUM);
        $uid=$row[0];
        $res=Db::connect();
        $sql2="UPDATE userinfo SET bsl='{$low}',bsh='{$high}' WHERE userid={$uid};";
        $res=Db::connect();
        $res->execute($sql2);
    }

    public function store_mldata()
    {   
        $data = input();
        $meal1=$data['meal1'];
        //$meal1=1;
        $meal2=$data['meal2'];
        //$meal2=2;
        $meal3=$data['meal3'];
        //$meal3=3;
        $meal4=$data['meal4'];
        //$meal4=4;
        $nicknamesign_up=$data['username'];
        //$nicknamesign_up="Nakajima";
        $res=mysqli_connect("localhost","root","","ge"); 
        $sql1="SELECT userid FROM userinfo WHERE nicknamesign_up='{$nicknamesign_up}'";
        $qid=mysqli_query($res,$sql1);
        $row=mysqli_fetch_array($qid,MYSQL_NUM);
        $uid=$row[0];
        //$meal1=1;
        //$meal2=1;
        //$meal3=1;
        //$meal4=1;
        $sql2="UPDATE userinfo SET mealtm1='{$meal1}',mealtm2='{$meal2}',mealtm3='{$meal3}',mealtm4='{$meal4}' WHERE userid={$uid};";
        $res=Db::connect();
        $res->execute($sql2);
    }

    public function get_bsdata3()
    {    
         $cmd =system("python C:\Users\Administrator\Desktop\web.py");
         echo $cmd;
         echo "</br>";
         $time_of_post=$cmd[11].$cmd[12].$cmd[13].$cmd[14].$cmd[15];
         echo  $time_of_post;
         echo "</br>";
         $time_of_post2=$cmd[0];
         for($index=1;$index<19;$index++) 
        { 
          $time_of_post2=$time_of_post2.$cmd[$index]; 
         } 
         echo  $time_of_post2;
    }

    public function try2()
    {   
        //$username="AbeShinzo";
        //$sql1="UPDATE user SET username='{$username}' WHERE id=1;";
        //$res=Db::connect();
        //$res->execute($sql1);
        //session_destroy();
        //$cmd = shell_exec("python C:\Users\Lenovo\Desktop\Motion(2)\Motion\cmd.py");
        $user="Hasegawa";
        $user=$user."daily";
        $res=mysqli_connect("localhost","root","","ge"); 
        $sql1="SELECT btime FROM {$user} WHERE id=2";
        $qid=mysqli_query($res,$sql1);
        $row=mysqli_fetch_array($qid,MYSQL_NUM);
        $res=implode("",$row);
        echo $res;
    }

    public function try1()
    {    
         //$res=mysqli_connect("localhost","root","","ge"); 
         //$sql1="SELECT username FROM user WHERE id=1";
         //$qid=mysqli_query($res,$sql1);
         //$row=mysqli_fetch_array($qid,MYSQL_NUM);
         //echo $row[0];
         $nicknamesign_up="Hasegawa";
         $user=$nicknamesign_up."daily";
         $res=Db::connect();
         $sql1="CREATE TABLE `{$user}`(
         btime char(30),
         etime char(30),
         id int  AUTO_INCREMENT,
         PRIMARY KEY(id)
         )ENGINE = MyISAM  DEFAULT CHARSET = utf8mb4  AUTO_INCREMENT = 1;";
         $res->execute($sql1);
         $sql2="INSERT INTO `{$user}` SET id =1;";
         $res->execute($sql2);
         $sql3="INSERT INTO `{$user}` SET id =2;";
         $res->execute($sql3);
         //echo $_SESSION['nicknamesign_up'];
    }

    
    
     public function begin()
    {   
        date_default_timezone_set("Asia/Shanghai");
        //session_start();
        //$data = input();
        $username=$data['username'];
        //$username="Nakajima";
        $user=$username."daily";
        //$user=$username."daily";
        //$user=$data['checktime'];
        $cmd = shell_exec("python C:\Users\Administrator\Desktop\web.py");
        $time_of_post=$cmd[0].$cmd[1].$cmd[2].$cmd[3].$cmd[4];
        $time_of_post2=$cmd[6];
        for($index=7;$index<26;$index++) 
        { 
          $time_of_post2=$time_of_post2.$cmd[$index]; 
         } 
        //echo $time_of_post;
        //Session::set('timebe', $time_of_post);
        //echo Session::get('timebe');
        
        $res=Db::connect();
        $sql2="UPDATE {$user} SET btime='{$time_of_post}' WHERE id=1;";
        $sql3="UPDATE {$user} SET btime='{$time_of_post2}' WHERE id=2;";
        //$sql2="INSERT INTO 111000（bs，shijian，fan）
        //VALUES(`{$xtime}`，`{$xwhen}`，`{$xbs}`);";
        $res->execute($sql2);
        $res->execute($sql3);
        //$cmd = shell_exec("python C:\Users\Lenovo\Desktop\Motion(2)\Motion\storedata.py");

    }

    public function end()
    {   
        date_default_timezone_set("Asia/Shanghai");
        //session_start();
        $data = input();
        //$username="Nakajima";
        //$user=$username."daily";
        $username=$data['username'];
        $user=$username."daily";
        //$user=$data['checktime'];
        $cmd = shell_exec("python C:\Users\Administrator\Desktop\web.py");
        $time_of_post=$cmd[0].$cmd[1].$cmd[2].$cmd[3].$cmd[4];
        $time_of_post2=$cmd[6];
        //echo strlen($cmd);
        for($index=7;$index<26;$index++) 
        { 
          $time_of_post2=$time_of_post2.$cmd[$index]; 
         } 
        //echo $time_of_post;
        //Session::set('timebe', $time_of_post);
        //echo Session::get('timebe');
        $res=Db::connect();
        $sql2="UPDATE {$user} SET etime='{$time_of_post}' WHERE id=1;";
        $sql3="UPDATE {$user} SET etime='{$time_of_post2}' WHERE id=2;";
        //$sql2="INSERT INTO 111000（bs，shijian，fan）
        //VALUES(`{$xtime}`，`{$xwhen}`，`{$xbs}`);";
        $res->execute($sql2);
        $res->execute($sql3);
        //$cmd = shell_exec("python C:\Users\Lenovo\Desktop\Motion(2)\Motion\cmd.py");
    }

    public function showtime()
    {   
        $data = input();
        $user=$data['username'];
        //$user="Nakajima";
        $user=$user."daily";
        $res=mysqli_connect("localhost","root","","ge"); 
        $sql1="SELECT btime FROM {$user} WHERE id=1";
        $qid=mysqli_query($res,$sql1);
        $row=mysqli_fetch_array($qid,MYSQL_NUM);
        $res1=implode("",$row);
        $sql1="SELECT etime FROM {$user} WHERE id=1";
        $qid=mysqli_query($res,$sql1);
        $row=mysqli_fetch_array($qid,MYSQL_NUM);
        $res2=implode("",$row);
        //$sql2="SELECT dailydata.btime FROM dailydata;";
        //$res->execute($sql2);
        //var_dump($res);
        //$res=Db::table('dailydata')->value('btime');
        //$res2=Db::table('dailydata')->value('etime');
        echo($res1.'-'.$res2);

        //Session::destroy();
    }


    public function shichang()
    {   
        $data = input();
        $tname=$data['username'];
        //$tname="Nakajima";
        //$res=Db::connect();
        //$sql2="SELECT dailydata.btime FROM dailydata;";
        //$res->execute($sql2);
        //var_dump($res);
        //$tname="Hasegawa";
        $user=$tname."daily";
        $res=mysqli_connect("localhost","root","","ge"); 
        $sql1="SELECT btime FROM {$user} WHERE id=2";
        $qid=mysqli_query($res,$sql1);
        $row=mysqli_fetch_array($qid,MYSQL_NUM);
        $res1=implode("",$row);
        $sql1="SELECT etime FROM {$user} WHERE id=2";
        $qid=mysqli_query($res,$sql1);
        $row=mysqli_fetch_array($qid,MYSQL_NUM);
        $res2=implode("",$row);
        $a_time = strtotime($res1);
        $riqi=date('Y-m-d',$a_time);
        //echo gettype($a_time);
        $b_time = strtotime($res2);
        $interv=$b_time-$a_time;
        $fenzhong=intval(($interv%3600)/60);
        if ($fenzhong<=10) {
           $timeofslp=intval($interv/3600)."h ".intval(($interv%3600)/60)."min";
        } else {
        $timeofslp=intval($interv/3600)."h".intval(($interv%3600)/60)."min";
        }
        $shichang=intval($interv/3600)."小时".intval(($interv%3600)/60)."分钟";
        $score=intval($interv/3600)+10;
        if($score>=90){
            $score=90;
        }
        $sql2="INSERT INTO {$tname} ( timeofslp, riqi, score)
        VALUES( '{$timeofslp}', '{$riqi}','{$score}');";
        $res=Db::connect();
        $res->execute($sql2);
        echo $shichang."|".$score;
        //echo gettype($interv);
        //echo $a_time;
        //Session::destroy();
    }

     public function createdataforsleep()
    {   
        $id_of_pa="Hasegawa";
        $user=$id_of_pa."daily";
        //dump(config('database'));
        //$time_of_post=date('Y-m-d ',time());
        $res=Db::connect();
        //$Model= User();
        //dump($res);
        $sql1="CREATE TABLE `{$user}`(
        timeofslp char(20),
        riqi char(30),
        score int,
        id int  AUTO_INCREMENT,
        PRIMARY KEY(id)
        )ENGINE = MyISAM  DEFAULT CHARSET = utf8mb4  AUTO_INCREMENT = 1;";
        $res->execute($sql1);
        //dump($list);

    }

    public function getreport()
    {    $data=input();
         header("Access-Control-Allow-Origin：*");
         $report=array(' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',
            ' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ');
         session_start();
         //$tname='Nakajima';
         $res=mysqli_connect("localhost","root","","ge"); 
         //$sql1="SELECT username FROM user WHERE id=1";
         //$qid=mysqli_query($res,$sql1);
         //$row=mysqli_fetch_array($qid,MYSQL_NUM);
         //$tname=$row[0];
         $tname=$data['username'];
         $sql1="SELECT * FROM {$tname}";
         $res=Db::connect();
         $res->execute($sql1);
         $res=mysqli_connect("localhost","root","","ge"); 
         mysqli_query ($res,"set character_set_connection =utf-8" );
         $qid=mysqli_query($res,$sql1);
         $num=mysqli_num_rows($qid);
         if ($num>"60") {
              $num=60;
         }
         for ($i=0; $i<$num; $i++)
         {      
                
                $row=mysqli_fetch_array($qid,MYSQL_NUM);
                for ($j=0; $j<3; $j++)
                {//echo $row['timeofslp'];
                $report[3*$i+$j]=$row[$j];
            }
         }
         mysqli_close($res);
         for ($i=0; $i<60; $i++)
         {echo $report[$i];}
    }

     public function regs()
    {    
         $data = input();
         $nicknamesign_up=$data['nicknamesign_up'];
         $yourdoctor=$data['yourdoctor'];
         $emailsign_up=$data['emailsign_up'];
         $passwordsign_up=$data['passwordsign_up'];
         //$nicknamesign_up="AbeShinzo";
         //$usernamesign_up="abe";
         //$emailsign_up="abe";
         //$passwordsign_up="abe";
         //session_destroy();
         $res=mysqli_connect("localhost","root","","ge"); 

         $sql="select * from userinfo where nicknamesign_up='{$nicknamesign_up}'";
         $check_query = mysqli_query($res,$sql);
         if(mysqli_num_rows($check_query)){
           echo "1";
           exit;
          }

         $sql="select * from doctorinfo where doctorid='{$yourdoctor}'";
         $check_query = mysqli_query($res,$sql);
         if(!(mysqli_num_rows($check_query))){
           //echo "doctor not exist";
           echo "5";
           exit;
          }


         $sql1="INSERT INTO userinfo SET nicknamesign_up ='{$nicknamesign_up}',yourdoctor ='{$yourdoctor}',emailsign_up = '{$emailsign_up}' ,passwordsign_up = '{$passwordsign_up}';";
         $res=Db::connect();
         $res->execute($sql1);
         $res=Db::connect();
         $sql1="CREATE TABLE `{$nicknamesign_up}`(
         timeofslp char(20),
         riqi char(30),
         score int,
         id int  AUTO_INCREMENT,
         PRIMARY KEY(id)
         )ENGINE = MyISAM  DEFAULT CHARSET = utf8mb4  AUTO_INCREMENT = 1;";
         $res->execute($sql1);
         $user=$nicknamesign_up."daily";

         $res=Db::connect();
         $sql5="CREATE TABLE `{$user}`(
         btime char(30),
         etime char(30),
         id int  AUTO_INCREMENT,
         PRIMARY KEY(id)
         )ENGINE = MyISAM  DEFAULT CHARSET = utf8mb4  AUTO_INCREMENT = 1;";
         $res->execute($sql5);
         $sql2="INSERT INTO `{$user}` SET id =1;";
         $res->execute($sql2);
         $sql3="INSERT INTO `{$user}` SET id =2;";
         $res->execute($sql3);

         $bsdata=$nicknamesign_up."bsdata";
         $sql6="CREATE TABLE `{$bsdata}`(
         xtime char(30),
         xwhen char(30),
         xbs char(30),
         id int  AUTO_INCREMENT,
         PRIMARY KEY(id)
         )ENGINE = MyISAM  DEFAULT CHARSET = utf8mb4  AUTO_INCREMENT = 1;";
         $res->execute($sql6);

         echo "You have create your patient account!Please login!";
         //$Model= User();
         //dump($res);

    }

    public function regs2()
    {    
         $data = input();
         $nicknamesign_up=$data['nicknamesign_up'];
         $doctorid=$data['doctorid'];
         $emailsign_up=$data['emailsign_up'];
         $passwordsign_up=$data['passwordsign_up'];
         //$nicknamesign_up="AbeShinzo";
         //$usernamesign_up="abe";
         //$emailsign_up="abe";
         //$passwordsign_up="abe";
         //session_destroy();
         $res=mysqli_connect("localhost","root","","ge"); 
         $sql="select * from doctorinfo where doctorid='{$doctorid}'";
         $check_query = mysqli_query($res,$sql);
         if(mysqli_num_rows($check_query)){
           echo "id already exist!";
           exit;
          }
         $sql1="INSERT INTO doctorinfo SET nicknamesign_up ='{$nicknamesign_up}',doctorid ='{$doctorid}',emailsign_up = '{$emailsign_up}' ,passwordsign_up = '{$passwordsign_up}';";
         //dump(config('database'));
         //$time_of_post=date('Y-m-d ',time());
         //$Model= User();
         //dump($res);
         //dump(config('database'));
         $res=Db::connect();
         $res->execute($sql1);
         
         echo "You have create your doctor account!Please login!";
         //$Model= User();
         //dump($res);

    }
    
    public function regs3()
    {    
         $data = input();
         $nicknamesign_up = $data['nicknamesign_up'];
         $usernamesign_up = $data['usernamesign_up'];
         $relationship = $data['relationship'];
         $familymemb = $data['familymemb'];
         $emailsign_up = $data['emailsign_up'];
         $passwordsign_up = $data['passwordsign_up'];

         

         $res=mysqli_connect("localhost","root","","ge"); 
         $sql="select * from familymembinfo where f_nicknamesign_up='{$nicknamesign_up}'";
         $check_query = mysqli_query($res,$sql);
         if(mysqli_num_rows($check_query)){
           echo "1";
           exit;
          }

         $sql="select * from userinfo where nicknamesign_up='{$familymemb}'";
         $check_query = mysqli_query($res,$sql);
         if(!(mysqli_num_rows($check_query))){
           //echo "doctor not exist";
           echo "5";
           exit;
          }

         $sql1="INSERT INTO familymembinfo SET f_nicknamesign_up ='{$nicknamesign_up}',f_usernamesign_up ='{$usernamesign_up}',relationship = '{$relationship}' ,familymemb = '{$familymemb}' ,f_emailsign_up = '{$emailsign_up}' ,f_passwordsign_up = '{$passwordsign_up}';";
         //dump(config('database'));
         //$time_of_post=date('Y-m-d ',time());
         //$Model= User();
         //dump($res);
         //dump(config('database'));
         $res=Db::connect();
         $res->execute($sql1);
         
         echo "You have create your doctor account!Please login!";
         //$Model= User();
         //dump($res);

    }

    public function login()
    {    
         $data = input();
         $username=$data['username'];
         $password=$data['password'];
         //$username="Yamamoto";
         //$password="123";
         $res=mysqli_connect("localhost","root","","ge"); 
         $whoyouare="0";

         $sql="select * from userinfo where nicknamesign_up='{$username}';";
         $check_query = mysqli_query($res,$sql);
         if(mysqli_num_rows($check_query)){
           $whoyouare="10";
          }

          $sql="select * from doctorinfo where doctorid='{$username}';";
         $check_query = mysqli_query($res,$sql);
         if(mysqli_num_rows($check_query)){
           $whoyouare="20";
          }

          $sql="select * from familymembinfo where f_nicknamesign_up='{$username}';";
         $check_query = mysqli_query($res,$sql);
         if(mysqli_num_rows($check_query)){
           $whoyouare="30";
          }
         if($whoyouare=="0"){
            echo 1;
            exit;
          }

         if($whoyouare=="10"){
         $sql="select passwordsign_up from userinfo where nicknamesign_up='{$username}'";
         }

         if($whoyouare=="20"){
         $sql="select passwordsign_up from doctorinfo where doctorid='{$username}'";
         }

         if($whoyouare=="30"){
         $sql="select f_passwordsign_up from familymembinfo where f_nicknamesign_up='{$username}'";
         }

         $check_query = mysqli_query($res,$sql);
         $row=mysqli_fetch_array($check_query,MYSQL_NUM);
         if(!($password==implode("",$row))){
           echo 2;
           exit;
          }
          if($whoyouare=="10"){
         echo 5;
         }

         if($whoyouare=="20"){
         echo 6;
         }

         if($whoyouare=="30"){
         echo 7;
         }
    }
    
    //画图
    public function chartforp()
    {    
        $res=mysqli_connect("localhost","root","","ge"); 
         $data=input();
         $un=$data['pna'];
         //$un="Nakajima";
         $sql1="SELECT score FROM {$un} order by id desc limit 7;";
         $qid=mysqli_query($res,$sql1);
         $score1=mysqli_fetch_array($qid,MYSQL_NUM);
         $score2=mysqli_fetch_array($qid,MYSQL_NUM);
         $score3=mysqli_fetch_array($qid,MYSQL_NUM);
         $score4=mysqli_fetch_array($qid,MYSQL_NUM);
         $score5=mysqli_fetch_array($qid,MYSQL_NUM);
         $score6=mysqli_fetch_array($qid,MYSQL_NUM);
         $score7=mysqli_fetch_array($qid,MYSQL_NUM);
         
         $un=$un."bsdata";
         $sql1="SELECT xbs FROM {$un} order by id desc limit 7;";
         $qid=mysqli_query($res,$sql1);
         $bs1=mysqli_fetch_array($qid,MYSQL_NUM);
         $bs2=mysqli_fetch_array($qid,MYSQL_NUM);
         $bs3=mysqli_fetch_array($qid,MYSQL_NUM);
         $bs4=mysqli_fetch_array($qid,MYSQL_NUM);
         $bs5=mysqli_fetch_array($qid,MYSQL_NUM);
         $bs6=mysqli_fetch_array($qid,MYSQL_NUM);
         $bs7=mysqli_fetch_array($qid,MYSQL_NUM);
         echo $score1[0]."|".$score2[0]."|".$score3[0]."|".$score4[0]."|".$score5[0]."|".$score6[0]."|".$score7[0]."|".$bs1[0]."|".$bs2[0]."|".$bs3[0]."|".$bs4[0]."|".$bs5[0]."|".$bs6[0]."|".$bs7[0];
    }

    public function showpatient()
    {   $data=input();
        $un=$data['un'];
        //$un="656356768";
        $res=mysqli_connect("localhost","root","","ge"); 
        $sql1="SELECT nicknamesign_up FROM userinfo WHERE yourdoctor={$un}";
        $qid=mysqli_query($res,$sql1);
        $name1=mysqli_fetch_array($qid,MYSQL_NUM);
        $name2=mysqli_fetch_array($qid,MYSQL_NUM);
        $name3=mysqli_fetch_array($qid,MYSQL_NUM);
        $name4=mysqli_fetch_array($qid,MYSQL_NUM);
        $name5=mysqli_fetch_array($qid,MYSQL_NUM);


        $sql1="SELECT score FROM {$name1[0]} where id=(select max(id) from {$name1[0]})";
        $qid=mysqli_query($res,$sql1);
        $score1=mysqli_fetch_array($qid,MYSQL_NUM);
        $forbsdata=$name1[0]."bsdata";
        $sql1="SELECT xbs FROM {$forbsdata} where id=(select max(id) from {$forbsdata})";
        $qid=mysqli_query($res,$sql1);
        $bs1=mysqli_fetch_array($qid,MYSQL_NUM);
        $sql1="SELECT gender FROM userinfo where nicknamesign_up='{$name1[0]}'";
        $qid=mysqli_query($res,$sql1);
        $gend1=mysqli_fetch_array($qid,MYSQL_NUM);
        $sql1="SELECT emailsign_up FROM userinfo where nicknamesign_up='{$name1[0]}'";
        $qid=mysqli_query($res,$sql1);
        $num1=mysqli_fetch_array($qid,MYSQL_NUM);
        $sql1="SELECT age FROM userinfo where nicknamesign_up='{$name1[0]}'";
        $qid=mysqli_query($res,$sql1);
        $age1=mysqli_fetch_array($qid,MYSQL_NUM);


        $sql1="SELECT score FROM {$name2[0]} where id=(select max(id) from {$name2[0]})";
        $qid=mysqli_query($res,$sql1);
        $score2=mysqli_fetch_array($qid,MYSQL_NUM);
        $forbsdata=$name2[0]."bsdata";
        $sql1="SELECT xbs FROM {$forbsdata} where id=(select max(id) from {$forbsdata})";
        $qid=mysqli_query($res,$sql1);
        $bs2=mysqli_fetch_array($qid,MYSQL_NUM);
        $sql1="SELECT gender FROM userinfo where nicknamesign_up='{$name2[0]}'";
        $qid=mysqli_query($res,$sql1);
        $gend2=mysqli_fetch_array($qid,MYSQL_NUM);
        $sql1="SELECT emailsign_up FROM userinfo where nicknamesign_up='{$name2[0]}'";
        $qid=mysqli_query($res,$sql1);
        $num2=mysqli_fetch_array($qid,MYSQL_NUM);
        $sql1="SELECT age FROM userinfo where nicknamesign_up='{$name2[0]}'";
        $qid=mysqli_query($res,$sql1);
        $age2=mysqli_fetch_array($qid,MYSQL_NUM);


        $sql1="SELECT score FROM {$name3[0]} where id=(select max(id) from {$name3[0]})";
        $qid=mysqli_query($res,$sql1);
        $score3=mysqli_fetch_array($qid,MYSQL_NUM);
        $forbsdata=$name3[0]."bsdata";
        $sql1="SELECT xbs FROM {$forbsdata} where id=(select max(id) from {$forbsdata})";
        $qid=mysqli_query($res,$sql1);
        $bs3=mysqli_fetch_array($qid,MYSQL_NUM);
        $sql1="SELECT gender FROM userinfo where nicknamesign_up='{$name3[0]}'";
        $qid=mysqli_query($res,$sql1);
        $gend3=mysqli_fetch_array($qid,MYSQL_NUM);
        $sql1="SELECT emailsign_up FROM userinfo where nicknamesign_up='{$name3[0]}'";
        $qid=mysqli_query($res,$sql1);
        $num3=mysqli_fetch_array($qid,MYSQL_NUM);
        $sql1="SELECT age FROM userinfo where nicknamesign_up='{$name3[0]}'";
        $qid=mysqli_query($res,$sql1);
        $age3=mysqli_fetch_array($qid,MYSQL_NUM);


        $sql1="SELECT score FROM {$name4[0]} where id=(select max(id) from {$name4[0]})";
        $qid=mysqli_query($res,$sql1);
        $score4=mysqli_fetch_array($qid,MYSQL_NUM);
        $forbsdata=$name4[0]."bsdata";
        $sql1="SELECT xbs FROM {$forbsdata} where id=(select max(id) from {$forbsdata})";
        $qid=mysqli_query($res,$sql1);
        $bs4=mysqli_fetch_array($qid,MYSQL_NUM);
        $sql1="SELECT gender FROM userinfo where nicknamesign_up='{$name4[0]}'";
        $qid=mysqli_query($res,$sql1);
        $gend4=mysqli_fetch_array($qid,MYSQL_NUM);
        $sql1="SELECT emailsign_up FROM userinfo where nicknamesign_up='{$name4[0]}'";
        $qid=mysqli_query($res,$sql1);
        $num4=mysqli_fetch_array($qid,MYSQL_NUM);
        $sql1="SELECT age FROM userinfo where nicknamesign_up='{$name4[0]}'";
        $qid=mysqli_query($res,$sql1);
        $age4=mysqli_fetch_array($qid,MYSQL_NUM);


        $sql1="SELECT score FROM {$name5[0]} where id=(select max(id) from {$name5[0]})";
        $qid=mysqli_query($res,$sql1);
        $score5=mysqli_fetch_array($qid,MYSQL_NUM);
        $forbsdata=$name5[0]."bsdata";
        $sql1="SELECT xbs FROM {$forbsdata} where id=(select max(id) from {$forbsdata})";
        $qid=mysqli_query($res,$sql1);
        $bs5=mysqli_fetch_array($qid,MYSQL_NUM);
        $sql1="SELECT gender FROM userinfo where nicknamesign_up='{$name5[0]}'";
        $qid=mysqli_query($res,$sql1);
        $gend5=mysqli_fetch_array($qid,MYSQL_NUM);
        $sql1="SELECT emailsign_up FROM userinfo where nicknamesign_up='{$name5[0]}'";
        $qid=mysqli_query($res,$sql1);
        $num5=mysqli_fetch_array($qid,MYSQL_NUM);
        $sql1="SELECT age FROM userinfo where nicknamesign_up='{$name5[0]}'";
        $qid=mysqli_query($res,$sql1);
        $age5=mysqli_fetch_array($qid,MYSQL_NUM);
        echo $name1[0]."|".$score1[0]."|".$bs1[0]."|".$name2[0]."|".$score2[0]."|".$bs2[0]."|".$name3[0]."|".$score3[0]."|".$bs3[0]."|".$name4[0]."|".$score4[0]."|".$bs4[0]."|".$name5[0]."|".$score5[0]."|".$bs5[0]."|".$gend1[0]."|".$num1[0]."|".$age1[0]."|".$gend2[0]."|".$num2[0]."|".$age2[0]."|".$gend3[0]."|".$num3[0]."|".$age3[0]."|".$gend4[0]."|".$num4[0]."|".$age4[0]."|".$gend5[0]."|".$num5[0]."|".$age5[0];
    }
    
    //可以不要的
    public function show_p_name()
    {   
        $data=input();
        $doctorid="656356768";
        $res=mysqli_connect("localhost","root","","ge"); 
        $sql1="SELECT nicknamesign_up FROM userinfo WHERE yourdoctor='{$doctorid}'";
        $qid=mysqli_query($res,$sql1);
        $row=mysqli_fetch_array($qid,MYSQL_NUM);
        $row2=mysqli_fetch_array($qid,MYSQL_NUM);
        $row3=mysqli_fetch_array($qid,MYSQL_NUM);
        $row4=mysqli_fetch_array($qid,MYSQL_NUM);
        $row5=mysqli_fetch_array($qid,MYSQL_NUM);
        echo $row[0].'|'.$row2[0].'|'.$row3[0].'|'.$row4[0].'|'.$row5[0];
    }

    public function show_p_info()
    {   
        $data=input();
        $uname=$data['un'];
        //$uname="Nakajima";
        $res=mysqli_connect("localhost","root","","ge"); 
        $sql1="SELECT nicknamesign_up FROM userinfo WHERE nicknamesign_up='{$uname}'";
        $qid=mysqli_query($res,$sql1);
        $row=mysqli_fetch_array($qid,MYSQL_NUM);

        $sql1="SELECT emailsign_up FROM userinfo WHERE nicknamesign_up='{$uname}'";
        $qid=mysqli_query($res,$sql1);
        $row2=mysqli_fetch_array($qid,MYSQL_NUM);

        $sql1="SELECT gender FROM userinfo WHERE nicknamesign_up='{$uname}'";
        $qid=mysqli_query($res,$sql1);
        $row3=mysqli_fetch_array($qid,MYSQL_NUM);

        $sql1="SELECT yourdoctor FROM userinfo WHERE nicknamesign_up='{$uname}'";
        $qid=mysqli_query($res,$sql1);
        $row4=mysqli_fetch_array($qid,MYSQL_NUM);

        $sql1="SELECT nicknamesign_up FROM doctorinfo WHERE doctorid='{$row4[0]}'";
        $qid=mysqli_query($res,$sql1);
        $row5=mysqli_fetch_array($qid,MYSQL_NUM);

        $sql1="SELECT score FROM {$uname} where id=(select max(id) from {$uname})";
        $qid=mysqli_query($res,$sql1);
        $score=mysqli_fetch_array($qid,MYSQL_NUM);
        $forbsdata=$uname."bsdata";
        $sql1="SELECT xbs FROM {$forbsdata} where id=(select max(id) from {$forbsdata})";
        $qid=mysqli_query($res,$sql1);
        $bs=mysqli_fetch_array($qid,MYSQL_NUM);
        $sql1="SELECT timeofslp FROM {$uname} order by id desc";
        $qid=mysqli_query($res,$sql1);
        $row7=mysqli_fetch_array($qid,MYSQL_NUM);
        $frist = substr( $row7[0],0,1);
        echo $row[0].'|'.$row2[0].'|'.$row3[0].'|'.$row5[0].'|'.$score[0].'|'.$bs[0].'|'.$frist[0];
    }

    public function show_d_info()
    {   
        $data=input();
        $uname=$data['un'];
        //$uname="656356768";
        $res=mysqli_connect("localhost","root","","ge"); 
        $sql1="SELECT nicknamesign_up FROM doctorinfo WHERE doctorid='{$uname}'";
        $qid=mysqli_query($res,$sql1);
        $row=mysqli_fetch_array($qid,MYSQL_NUM);
        $sql1="SELECT emailsign_up FROM doctorinfo WHERE doctorid='{$uname}'";
        $qid=mysqli_query($res,$sql1);
        $row2=mysqli_fetch_array($qid,MYSQL_NUM);
        $sql1="SELECT doctorid FROM doctorinfo WHERE doctorid='{$uname}'";
        $qid=mysqli_query($res,$sql1);
        $row3=mysqli_fetch_array($qid,MYSQL_NUM);
        echo $row[0].'|'.$row2[0].'|'.$row3[0];
    }

    public function f_show_f_info()
    {   
        $data=input();
        $uname=$data['un'];
        //$uname="Nakajima";
        $res=mysqli_connect("localhost","root","","ge"); 
        $sql1="SELECT f_nicknamesign_up FROM familymembinfo WHERE familymemb='{$uname}'";
        $qid=mysqli_query($res,$sql1);
        $row=mysqli_fetch_array($qid,MYSQL_NUM);

        $uname=$row[0];
        //$uname="Kagawa";
        $res=mysqli_connect("localhost","root","","ge"); 
        $sql1="SELECT f_nicknamesign_up FROM familymembinfo WHERE f_nicknamesign_up='{$uname}'";
        $qid=mysqli_query($res,$sql1);
        $row=mysqli_fetch_array($qid,MYSQL_NUM);
        $sql1="SELECT f_emailsign_up FROM familymembinfo WHERE f_nicknamesign_up='{$uname}'";
        $qid=mysqli_query($res,$sql1);
        $row2=mysqli_fetch_array($qid,MYSQL_NUM);
        $sql1="SELECT relationship FROM familymembinfo WHERE f_nicknamesign_up='{$uname}'";
        $qid=mysqli_query($res,$sql1);
        $row3=mysqli_fetch_array($qid,MYSQL_NUM);
        echo $row[0].'|'.$row2[0].'|'.$row3[0];
    }

    public function show_f_info()
    {   
        $data=input();
        $uname=$data['un'];
        
        //$uname="Kagawa";
        $res=mysqli_connect("localhost","root","","ge"); 
        $sql1="SELECT f_nicknamesign_up FROM familymembinfo WHERE f_nicknamesign_up='{$uname}'";
        $qid=mysqli_query($res,$sql1);
        $row=mysqli_fetch_array($qid,MYSQL_NUM);
        $sql1="SELECT f_emailsign_up FROM familymembinfo WHERE f_nicknamesign_up='{$uname}'";
        $qid=mysqli_query($res,$sql1);
        $row2=mysqli_fetch_array($qid,MYSQL_NUM);
        $sql1="SELECT relationship FROM familymembinfo WHERE f_nicknamesign_up='{$uname}'";
        $qid=mysqli_query($res,$sql1);
        $row3=mysqli_fetch_array($qid,MYSQL_NUM);
        echo $row[0].'|'.$row2[0].'|'.$row3[0];
    }
}
