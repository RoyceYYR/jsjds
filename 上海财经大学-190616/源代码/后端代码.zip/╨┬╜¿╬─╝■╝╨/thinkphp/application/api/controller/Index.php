<?php
namespace app\api\controller;
use think\Controller;
use app\api\model\User;
/**
 * 
 */
class Index extends Controller
{
	public function index()
	{
		$data1 =$_POST['username'];
		User::create([
         	"username" => $data1,
         	"password" => "123"
         ]);
		//Session("username",$data["username"]);
	}
}