import datetime
#获取html页面传递过来的数据值
now_time = datetime.datetime.now().strftime('%H:%M')
now_time2= datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
#打印输出
print (now_time)
print (now_time2)