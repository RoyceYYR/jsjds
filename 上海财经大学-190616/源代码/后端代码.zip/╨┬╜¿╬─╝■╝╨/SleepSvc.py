# from fallDataPre import Xtrain,Xtest,ytrain,ytest
from sklearn.svm import SVC
# print(type(Xtrain))
import pandas as pd

Xtrain = pd.read_csv('C:/Users/Administrator/Desktop/sxtrain.csv',encoding = "utf-8")
col_x = ['pitch','roll','yaw']
col_y =['Label']
Xtrain = pd.DataFrame(Xtrain,columns = col_x)
ytrain = pd.read_csv('C:/Users/Administrator/Desktop/sytrain.csv',encoding = "utf-8")
ytrain = pd.DataFrame(ytrain,columns = col_y)
Xtest = pd.read_csv('C:/Users/Administrator/Desktop/sxtest.csv',encoding = "utf-8")
Xtest = pd.DataFrame(Xtest,columns = col_x)
cla = SVC(C=1.0)
cla.fit(Xtrain,ytrain.astype('int'))
y_pred = cla.predict(Xtest)
print(y_pred)
import time
start = time.clock()
end = time.clock()
print("read: %f s" % (end - start))